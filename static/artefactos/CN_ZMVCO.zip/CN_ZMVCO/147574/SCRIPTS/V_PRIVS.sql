set serveroutput on size 10000
set verify off
set pages 0
set feedback off
spool TE_TGRGI.lst
select distinct 'pause DEBE estar conectado con Usuario VU_SFI' || chr(10) || 'ROLL' || chr(10) || 'EXIT'
from dual
where user <> 'VU_SFI'
/
spool off
start TE_TGRGI.lst
set pages 200

PROMPT
PROMPT Crea Sinonimo y da privilegios a Sfi_consulta y Sfi_actualiza
PROMPT
PROMPT

PROMPT
PROMPT Borrando tabla temporal ...
prompt

drop table amt_obj_privs;

PROMPT
PROMPT Creando tabla temporal ...
prompt

create table amt_obj_privs (
  amop_Orden  number, 
  amop_Texto  varchar2(200)
  )
storage ( initial 100k next 100k  pctincrease 0 )
/


SPOOL PRIVOBJ.lst

Declare
  --
  cursor c_obj is
  select object_name, object_Type
    from user_objects
   where object_Type not in ('TRIGGER', 'INDEX', 'PACKAGE BODY')
     and object_name not like ('BIN$%')
	 and object_name not like ('SYS_%')
	 and object_name not in (select table_name from all_tab_privs where grantee = 'SFI_CONSULTA');
  --
  c_Cont number := 0;
  --
BEGIN
  --
  for i in c_obj loop
    --
    c_Cont := c_Cont + 1;
    --
    insert into amt_obj_privs values ( c_Cont, 'DROP PUBLIC SYNONYM ' || i.object_name || ';' );
    c_Cont := c_Cont + 1;
    insert into amt_obj_privs values ( c_Cont, 'CREATE PUBLIC SYNONYM ' || i.object_name || ' FOR vu_sfi.' || i.object_name || ';');
    --
    IF ( i.object_type IN ( 'PROCEDURE', 'FUNCTION', 'PACKAGE', 'TYPE' ) ) THEN
      --
      c_Cont := c_Cont + 1;
      insert into amt_obj_privs values ( c_Cont, 'GRANT EXECUTE ON '|| i.object_name || ' TO  sfi_actualiza;');
      c_Cont := c_Cont + 1;
      insert into amt_obj_privs values ( c_Cont, 'GRANT EXECUTE ON '|| i.object_name || ' TO  sfi_consulta;');
      --
    ELSIF ( i.object_type IN ( 'VIEW', 'SEQUENCE' ) ) THEN
      --
      c_Cont := c_Cont + 1;
      insert into amt_obj_privs values ( c_Cont, 'GRANT SELECT ON ' || i.object_name || ' TO  sfi_actualiza;');
      c_Cont := c_Cont + 1;
      insert into amt_obj_privs values ( c_Cont, 'GRANT SELECT ON ' || i.object_name || ' TO  sfi_consulta;');
      --
    ELSE
      --
      c_Cont := c_Cont + 1;
      insert into amt_obj_privs values ( c_Cont, 'GRANT SELECT, INSERT, UPDATE, DELETE ON ' || i.object_name || ' TO  sfi_actualiza;');
      c_Cont := c_Cont + 1;
      insert into amt_obj_privs values ( c_Cont, 'GRANT SELECT  ON ' || i.object_name || ' TO  sfi_consulta;');
      --
    END IF;
    -- 
  end loop c_obj;
  -- 
END;
/

set pages    0

spool OBJ_PRIVS.lst

select amop_Texto
  from amt_obj_privs
 order by amop_Orden;

SPOOL OFF

set pages 200

PROMPT
PROMPT Otorgando permisos a los roles de SIFI...
prompt
star OBJ_PRIVS.lst
set feedback on
