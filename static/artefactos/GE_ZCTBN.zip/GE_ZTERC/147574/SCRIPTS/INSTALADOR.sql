set serveroutput on size 10000
set linesize 500
set verify on
set define '&'
@@VALIDADOR_INICIAL.sql
truncate table SF_TERRO;
spool Salida_147574.log;
prompt ***************************************** SIFI ITERACION 4.0.0 ****************************************
prompt *****************************************  NOTA IMPORTANTE *********************************************
prompt *                                                                                                      *
prompt *  POR FAVOR ENVIAR EL LOG DE EJECUCION DE ESTE SCRIPT (.log) PARA EFECTOS DE VERIFICACION DEL CAMBIO  *
prompt *                               EN LA INCIDENCIA CORRESPONDIENTE                                       *
prompt *                                                                                                      *
prompt *                                      ITC CONSULTORES SAS                                             *
prompt *                                    Soluciones Inteligentes                                           *
prompt *                                                                                                      *
prompt ********************************************************************************************************
select name base_datos from v$database;
select  to_char(sysdate,'dd/mm/yyyy-HH24:MI:ss') fecha, username, machine, terminal, program from v$session s
where s.audsid = userenv('sessionid');
define Indices = ts_isfi
define Datos = ts_dsfi
-- TABLAS
-- ALTERS
--------------------------------------------------------------
--01_columns
--------------------------------------------------------------

--------------------------------------------------------------
--02_primary_key
--------------------------------------------------------------

--------------------------------------------------------------
--03_constraint
--------------------------------------------------------------

--------------------------------------------------------------
--04_comentarios
--------------------------------------------------------------

--------------------------------------------------------------
--05_indices
--------------------------------------------------------------
-- SECUENCIAS
-- TIPOS
-- PAQUETES
@@GE_QINFA.sql
-- VISTAS
-- FUNCIONES
-- TRIGGERS
-- JOBS
-- DATOS
-------------------------------------
-- @@VERSIONAMIENTO.sql
@@VALIDADOR.sql
COMMIT;
SPOOL OFF;
@@V_PRIVS.sql
set feedback on
set pages 200
prompt *************************************  NOTA IMPORTANTE!!!!  ********************************************
prompt *                                                                                                      *
prompt *  POR FAVOR ENVIAR EL LOG DE EJECUCION DE ESTE SCRIPT (.log) PARA EFECTOS DE VERIFICACION DEL CAMBIO  *
prompt *                               EN LA INCIDENCIA CORRESPONDIENTE                                       *
prompt *                                                                                                      *
prompt *                                      ITC CONSULTORES SAS                                             *
prompt *                                    Soluciones Inteligentes                                           *
prompt *                                                                                                      *
prompt ********************************************************************************************************