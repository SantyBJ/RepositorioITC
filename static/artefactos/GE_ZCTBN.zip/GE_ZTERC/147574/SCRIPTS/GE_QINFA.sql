prompt
prompt PACKAGE: GE_QINFA
prompt

CREATE OR REPLACE PACKAGE GE_QINFA as
  --
  -- #VERSION:0000001048
  --
  -- Procedimientos y Funciones para Procesamiento de Interfases
  --
  -- Almoto - 18 noviembre 2004 - Solicitud 5213
  -- EJ2H   - 22 diciembre 2005 - Solicitud 5584
  --          . Se incluye el parametro de requerimiento
  -- IRA    - 22/01/2007 - Solicitud 1049.
  --					. En Procedure "Validar" se cambia "r_Ci   ge_vcias%RowType;" por  "r_Ci   c_Cias%RowType;"
  --
  -- COMO058  jcvargas  .Se crea el procedimiento Valida_Fpag.
  --                    .Se modifica el procedimiento Validar para agregar el llamado a la procedimiento Valida_Fpag
  --                    .Se modifica el procedimiento Actualiza_Inar
  --                    .Se modifica el procedimiento Car_Cxp
  --                    .Se modifica el procedimiento Car_Cxp_PgPr
  --                    .Se modifica el procedimiento Car_Tes
  --                    .Se modifica el procedimiento Car_Tes_No_Neto
  --                    .Se modifica el procedimiento Car_Tes_Neto
  --                    .Se modifica el procedimiento CAR_CON_TES
  --
  --
  -- HISTORIAL DE CAMBIOS
  --
  -- VERSION        GAP      SOLICITUD   FECHA        REALIZO      COMENTARIO
  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  -- 109973                  9973        18/11/2011   japoveda     . Se agrega en el procedimiento que crea la contabilidad la validaci�n de
  --                                                                 comprobante descudrado
  -- 65001          004      COMO058     29/12/2011   afayala      . Se crean los Procedure: Valida_Factura y Valida_MonedaMy
  --                                                               . Se modifican los Procedure : Validar, Actualiza_Inar, Car_Cxp, CAR_CON_TES, CAR_TES_NETO,
  --                                                                                              Car_Tes_No_Neto, Car_Tes, Car_Cxp_PgPr y Car_CON
  -- 1011740                 11740       24/01/2012   ymoreno      . Se ajusta procedimiento Valida_Codigos para que actualice el registro con error en caso
  --                                                                 de no encontrar el codigo parametrizado.
  -- 1011986        17       11986       31/01/2012   dfgarzon     . Se integra de la versi�n de Coldex.
  -- 1012546        -        12546       22/02/2012   dfgarzon     . Se modifica el procedimiento "Car_Cxp".
  -- 1012552        -        12552       28/02/2012   dfgarzon     . Se modifica el procedimiento "valida_fpag" para que se pueda procesar registros con la
  --                                                                 forma de pago de traslados 'TR'.
  -- 1012484        -        12484       01/03/2012   ovcaceres    . Se adiciona la validaci�n de ica.
  -- 1012775        -        12775       07/03/2012   dfgarzon     . Se modifica el procedimiento "Validar" para adicionar el llamado al procedimiento
  --                                                                 "Inicializa_Estado" para que limpie los mensajes de error cada vez que se valida la interfase.
  -- 1012776        -        12776       07/03/2012   dfgarzon     . Se modifica el procedimiento CAR_ORPV para dejar el valor de la variable anterior "i.intm_tpliq"
  --                                                                 porque se estaban generando errores con el �ndice CP_IORPV_ORPA_UNI.
  -- 1012484        -        12484       13/03/2012   ymoreno      . Se ajusta procedimiento Car_Con, se cambia intm_aica de c_tpco_cxp por c_contab_cxp
  -- 1012484        -        12484       14/03/2012   ovcaceres    . Se ajusta procedimiento Car_Con eliminando los campos intm_ciud,  intm_aica en el cursor c_tpco_cxp
  -- 1012992                 12992       14/03/2012   maarbelaez   . se modifica el procedimiento: [ VERIFICA_CIERRES ]
  -- 1012954        -        12954       15/03/2012   ovcaceres    . Se ajusta procedimiento Car_Ppto,  mostrando error de duplicidad
  -- 1012993        -        12993       15/03/2012   ymoreno      . Se asjuta procedimiento Car_Con ajustando el cursor c_contab para manejo de agrupamiento
  -- 1012776        -        12776       22/03/2012   ovcaceres    . Se ajusta procedimiento CAR_CON_TRB, para cambiar el tipo de liquidaci�n del IVA.
  -- 1012484        -        12484       26/03/2012   ovcaceres    . Se ajusta procedimiento Car_Con, para obteber el valor bruto.  Se ajusta procedimiento CAR_CON_TRB para almacenar el valor bruto
  -- 1012484        -        12484       28/03/2012   ovcaceres    . Se ajusta procedimiento valida_aica.   Se adicionan condiciones para el error reportado.
  -- 1000           -        13298       10/04/2012   dfgarzon     . Se inactiva condici�n en el procedimiento CAR_CON_TRB porque estaban quedando los descuentos (D) con el valor (A).
  -- 1001           -        13335       11/04/2012   dfgarzon     . Se modifica el procedimiento "Deshace_INFA" porque no estaba borrando los datos de la tabla "Sc_tInPpto".
  -- 1002           -        13291       23/04/2012   dfgarzon     . Se modifica el procedimiento CONFIRMA_INFA para traer el nro. de requerimiento correspondiente a la interfase.
  --                                                               . Se crea el procedimiento "Actualiza_Inad_inrq" y la funci�n "trae_inad_inrq".
  -- 1003           -        13509       23/04/2012   dfgarzon     . Se crea el cursor c_orpv2 en el procedimiento CAR_CON_TRB y se adiciona condici�n para los
  --                                                                 conceptos de tipo 'RF'.
  -- 1004           -        13712       24/04/2012   dfgarzon     . Se colocan en comentarios varios comits porque al procesar la interfase y si habian errores
  --                                                                 entonces quedaban algunos registros guardados generando inconsistencias en la informaci�n.
  -- 1005           SIOC     COMO033     24/04/2012   ovcaceres    . Se modifican los procedimiento Car_Con, CAR_CXP_PGPR, CAR_ORPV, CAR_PPTO_CXP y Car_Cxp para agrupar y generar Orpas y contabilidad por prefijo y documento
  -- 1006           GAP5     1013809     24/04/2012   ymoreno      . Se ajusta procedimiento Crea_Reserva
  -- 1007           GAP5     1013896     27/04/2012   dcgarces     . Se cambia v_fuente estaba almacenando 'E' y debeia ser 'P' de plan.
  -- 1008           -        -           08/05/2012   ovcaceres    . Integraci�n GAP 5 y SIOC.
  -- 1009           -        14009       09/05/2012   ovcaceres    . Se ajusta procedimiento Car_Con para determinar la fecha dependiendo tiene documento asociado
  -- 1010                    14029       09/05/2012   lhernandez   . Se ajusta procedimiento Car_Con para que el detalle tome la misma fecha del encabezado
  -- 1011                    14029       10/05/2012   lhernandez   . Se ajustan los procedimientos CAR_CON_TES, Car_Tes y Car_Con para determinar la fecha
  -- 1012           -        14217       16/05/2012   dfgarzon     . Se modifica el procedimiento CAR_ORPV para adicionar una condici�n porque se estaba 
  --                                                                 almacenando mal la cuenta contable en el comprobante contable del pago.
  -- 1013           -        14217       18/05/2012   dfgarzon     . Se modifica el procedimiento "Car_Cxp" para guardar la cuenta contable que viene
  --                                                                 parametrizada en la interfase y despu�s ser utilizada en el comprobante contable del pago.
  -- 1014           -        14168       15/05/2012   ovcaceres    . Se ajusta procedimiento CAR_CON_TES para almacenar la fecha de documento.
  -- 1015           -        13369       23/05/2012   dfgarzon     . Se ajusta condici�n en el cursor "c_orpv2" y el valor absoluto en la inserci�n en la tabla
  --                                                                 "ge_tacre" del procedimiento CAR_CON_TRB.
  -- 1016           -        14471       22/05/2012   ovcaceres    . Se ajusta procediumiento car_con, se almacena el n�mero de documento la cabeza de comprobante.
  -- 1017           -        14217       28/05/2012   dfgarzon     . Se adiciona manejo de la excepci�n "no_data_found" en el procedimiento "Car_Cxp" para que
  --                                                                 limpie la variable "v_orpa_Mayo_Pasivo" en caso de que no se encuentren los datos seleccionados.
  -- 1018           -        14427       03/06/2012   dfgarzon     . Se modifica el procedimiento CAR_CON_TRB para que discrimine correctamente todos los conceptos
  --                                                                 de impuestos de la orden de pago.
  -- 1019           -        14628       04/06/2012   dfgarzon     . Se modifica el procedimiento "Car_Cxp" para que tome correctamente la cuenta contable que viene
  --                                                                 parametrizada en la interfase y despu�s ser utilizada en el comprobante contable del pago.
  -- 1020           -        15299       21/06/2012   dcgarces     . Se agrega condici�n de fecha en el procedimiento Car_Con.
  -- 1021           -        15330       28/06/2012   ovcaceres    . Se adiciona seguimiento en procedimiento Car_Con
  -- 1022           -        15473       09/07/2012   ovcaceres    . Se ajusta procedimiento Car_Cxp, se adiciona filtro en cursor de moneda extranjera.
  -- 1023           -        15472       10/07/2012   ovcaceres    . Se ajusta procedimiento CAR_CON_TRB, para mostrar mensaje de error cuando la base retefuente llega nula.
  -- 1024           -        15330       12/07/2012   ovcaceres    . Se ajusta procedimiento CAR_CON_TRB para buscar retefuente s�lo para los conceptos tipo descuento.
  -- 1025           -        13298       17/07/2012   lhernandez   . Se ajusta procedimiento Car_Cxp_PgPr, se tiene en cuenta su el valor neto llega en cero para en c�lculo de porcentaje de pago parcial
  -- 1026           -        16266       19/07/2012   dfgarzon     . Se integra el incidente 15673 - 03/07/2012 - dcgarces . Se ajusta procedimiento Car_Cxp_PgPr asignandole tama�o a la variable v_porc.
  -- 1027           -        16230       23/07/2012   dfgarzon     . Se modifica el procedimiento VALIDA_FPAG.
  -- 1028           -        16266       23/07/2012   dfgarzon     . Se modifican los procedimientos "Actualiza_Inar", "CAR_CON_TRB" y "CAR_ORPV".
  --                                                               . Se adiciona un nuevo campo para asociar el concepto base y asi no asociar la retenci�n por el valor de la base.
  --                                                               . Este ajuste se necesitaba para poder soportar interfases de n�mina con retenciones.
  -- 1029           -        16491       27/07/2012   dfgarzon     . Se modifican los procedimientos CAR_CON_TRB y CAR_ORPV porque en algunos casos el IVA no lo mostraba en la consulta de impuestos.
  -- 1030           -     Integracion    24/08/2012   jcrubiano    . Se Integra la version 1008 del branch V_7_0_RB1_PARCHES
  --                         16098       18/07/2012   lhernandez   . Se ajusta el procedimiento Actualiza_Inar para que el valor de la variable INTM_MAYO_P sea tomado del archivo
  -- 1031           -        18297       07/11/2012   ovcaceres    . Se ajusta el procedimiento Crea_Reserva, se cambia el tipo de dato del par�metro de forma de pago
  -- 1032           -        22059       04/03/2013   lhernandez   . Se ajusta el procedimiento Car_Con agregando actualizacion a la tabla cp_torpa con el numero de comprobante
  -- 1033           -        22031       07/03/2013   lhernandez   . Se ajusta el procedimiento Procesa_Infa para que realice presupuesto siempre y cuando la interfaz este marcada con presupuesto.
  -- 1034           -        23612       22/04/2013   dcgarces     . Se realiza ajuste en update del procedimiento car_con, para tener en cuenta el numero de la interfaz.
  -- 1035           -        24018       29/04/2013   Maaguilera   . Se ajusta cursor c_orpv contenido en el procedimiento Crea_Reserva adicionando condicion para que no se tengan en cuenta las ordenes de pago con dere_clase 'IT'.     
  -- 1036           -        23429       03/05/2013   lhernandez   . Se comenta cambio realizado en version 1032 (sol. 22059)
  -- 1037           -        32447       07/02/2014   fagarcia     . Se modifica procedimiento Procesa_Infa, cursor c_ppto, para que mire si existe en la tabla pp_tctrl, y de esta forma saber si maneja o no ppto.
  -- ------------------------------------------Inicio integraci�n RFC_19469 Vs. 1038  25/03/2014 Jcmartinez-----------------------------------------------------------------------------------------------------
	-- 1038        RFC_19469     --        20/02/2014   Jcrodriguez  . Se modifican los procesimientos ACTUALIZA_INAD_FIN insertando en la tabla de historicos de interfaces.
	-- ------------------------------------------Fin integraci�n RFC_19469 Vs. 1038  25/03/2014 Jcmartinez-----------------------------------------------------------------------------------------------------
	-- 1038        RFC_19469     --        25/03/2014   Jcmartinez   . Se realiza integraci�n RFC_19469 Vs. 1038
  -- 1039        rfc_39471     --        15/11/2014   SMCALDERON   . Se valida que si la forma de pago no esta parametrizada en el formato, no sea obligatoria
  -- 1040         42393                  05/01/2015   smcalderon   . Se ordena cursor c_temp, para que traiga primero las apropiaciones 
  -- 1041                    46631       19/06/2015   jarodriguez  . En el procedimiento Car_Cxp se agrega filtro por forma de pago.
  -- 1042                    53954       08/06/2016   rbermudez    . Se modifica el procedimiento Valida_Bancos ajustando la variable local Estado a 6 en su longitud, para evitar una exception 
  -- 1043                    56184       07/09/2016   rbermudez    . Se ajusta v_valbruto, v_valdesc, v_valreint de procedimiento CxP para que calcule correctamente el valor neto de la Orpa.
  -- 1044        RFC-62904               06/04/2018   Pablo Porras . Se crea VALIDA_CUENTA_BANCO_DESTINO. Se llama en VALIDAR.
  --                                                               . En ACTUALIZA_INAR se adicionan intm_cuenta_destino y intm_banc_destino
  --                                                               . En CAR_CON_TES se manejan intm_cuenta_destino y intm_banc_destino asi como el beneficiario del pago
  --                                                                    y las variables mvte_abon_cta y mvte_abon_banc
  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  -- ========= ============= ============ =========== ============== ============================================================================================================================================
  -- 1045                     81805       02/03/2020   lmesa         * Creacion de los procedimientos Valida_Archivo_Teso y Procesa_Archivo_Teso para la validaci�n y procesamiento de los cargue realizados atravez
  --                          (R8IFSC-13)              Cidenet         de la interfaz FINANSOFT.
  --                                                                 * Creaci�n de las funciones Cias_Mayor y Cias_Menor que devuelven el primer y ultimo codigo de empresa en la consulta a la vista iw_vhecg.
  --                                                                 * Se agregan los estados VE y PE como estados permitidos en el borrado  en el procedimiento Borra_Archivo.
  -- ========= ============= ============ =========== ============== ============================================================================================================================================
  -- 1046                     112746       31/05/2023 lvgomez         * Creaci�n de los procedimientos: Genera_Mvif, Car_mvif y valida_tpmv
  --                                                  Kilonova        * Se ajusta el procedimiento deshace_infa.
  --                          127008       23/08/2023 ggonzalezs      * Se ajusta procedimiento valida_tpmv. Se eliminan validaciones si existen o no parametrizaci�n en la tabla te_Tcomcia
  -- ========= ============= ============ =========== ============== ============================================================================================================================================
  -- 1047                     143451       17/05/2025 AATEHERAN       * Se ajusta procedimiento Car_Mvif en el cursor c_mvte para eliminar el distinct
  --
  -- ========= ============= ============ =========== ============== ============================================================================================================================================
  -- 1048      Soporte       147574       03/10/2025  sbejarano      . Se modifica el proceso DESHACE_INFA, recuperando el campo mvif_cias del cursor c_tmtif, se crea el cursor c_cias_fond para recuperar el
  --           POST-VENTA                                              fondo al cual esta asociada la empresa, y se modifica logica de borrado de las tablas sf_tmvif para que filtre por numero de movimiento 
  --                                                                   y fondo, y de la tabla ge_tmtif para que filtre por numero de movimiento y empresa.
  -- ========= ============= ============ =========== ============== ============================================================================================================================================
  Procedure Procesa_Infa1 ( p_Infa           varchar2,
                           p_inrq           integer,
                           p_Periodo        integer,
                           p_Numero         varchar2,
                           p_Fecha          date,
                           p_Usua_Gene      varchar2,
                           p_Agr_CXP        varchar2,
                           p_Proc           varchar2,
                           p_py_EtPy        integer,
                           p_py_Proy        varchar2,
                           p_py_EnAp        integer    );
  ---------------------------------------------------------------------------------------------------------
  Procedure Procesa_Infa ( p_Infa           varchar2,
                           p_inrq           integer,
                           p_Periodo        integer,
                           p_Numero         varchar2,
                           p_Fecha          date,
                           p_Usua_Gene      varchar2,
                           p_Agr_CXP        varchar2,
                           p_Proc           varchar2,
                           p_py_EtPy        integer,
                           p_py_Proy        varchar2,
                           p_py_EnAp        integer    );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure ACTUALIZA_INAD_INI ( p_Numero         varchar2 );
    --  1.  EJ2H  15-DEC-2005 -- Soli 5584
    --      . Sobrecarga del m�todo ACTUALIZA_INAD_INI
    --      . Este metodo actualiza la tabla GE_TINAD
    --      . Cambio en el n�mero de parametros de entrada para el criterio de actualizaci�n
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------

  procedure ACTUALIZA_INAD_INI ( p_Infa           varchar2,
                                 p_Numero         varchar2 );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure ACTUALIZA_INAD_FIN ( p_Periodo        integer,
                                 p_Numero         varchar2,
                                 p_Accion         varchar2,
                                 p_Fecha          date,
                                 p_Usua           varchar2 );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------

  procedure ACTUALIZA_INAD_FIN ( p_Infa           varchar2,
                                 p_Periodo        integer,
                                 p_Numero         varchar2,
                                 p_Accion         varchar2,
                                 p_Fecha          date,
                                 p_Usua           varchar2 );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  --  1. EJ2H 20-DIC-2005 Soli 5584
  --     Este metodo se adiciona un parametro nuevo que es el requerimiento INRQ
  --
  procedure ACTUALIZA_INAR ( p_Infa           varchar2,
                             p_inrq           integer,    -- Soli 5584
                             p_Periodo        integer,
                             p_Numero         varchar2   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  --  Este metodo borra la tabla GE_TINADMIN y GE_TINARCH
  --
  procedure BORRA_ARCHIVO ( p_Infa           varchar2,
                            p_Periodo        integer,
                            p_Numero         varchar2   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  --  Soli 5584 . Sobrecarga del m�todo BORRA_ARCHIVO
  --  Soli 5584 . Este metodo borra la tabla GE_TINAD y GE_TINARCH
  --  Soli 5584 . Cambio en el numero de parametros de entrada como criterio de borrado
  --  Soli 5584 . Los estados permitidos de borrado en GE_TINAD son ('DT','CA','CF')
  procedure BORRA_ARCHIVO ( p_Infa           varchar2,
                            p_Numero         varchar2   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  --  Soli 5584 . Sobrecarga del m�todo BORRA_ARCHIVO
  --  Soli 5584 . Este metodo borra la tabla GE_TINAD y GE_TINARCH
  --  Soli 5584 . Cambio en el numero de parametros de entrada como criterio de borrado
  --  Soli 5584 . Los estados permitidos de borrado en GE_TINAD son ('DT','CA','CF')
  procedure Borra_Archivo ( p_Numero         varchar2   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_CON ( p_Infa             varchar2,
                      p_inrq             integer,
                      p_Periodo          integer,
                      p_Numero           varchar2,
                      p_Cias             integer,
                      p_Fecha            date,
                      p_Usua_Gene          varchar2,
                      p_Agr_CXP          varchar2,
                      p_py_EtPy          integer,
                      p_py_Proy          varchar2,
                      p_py_EnAp          integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_CON_TES ( p_Infa             varchar2,
                          p_inrq             integer,
                          p_Periodo          integer,
                          p_Numero           varchar2,
                          p_Cias             integer,
                          p_Fecha            date,
                          p_Usua_Gene        varchar2,
                          p_Agr_CXP          varchar2,
                          p_py_EtPy          integer,
                          p_py_Proy          varchar2,
                          p_py_EnAp          integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_CON_TRB ( p_cias          integer,
                          p_tpco          integer,
                          p_nrocom        integer,
                          p_Periodo       integer,
                          p_rengln        integer,
                          p_auxi          integer,
                          p_rete          varchar2,
                          p_valor         number,
                          p_vigorpa       integer,
                          p_orpa          integer,
                          p_ciud          integer,
                          p_aica          integer,
                          p_fecha         date,
                          p_tpliq         varchar2,
                          p_etct          integer,
                          p_base          number   default null,       -- 1012484.  ovcaceres.  02/03/2012
                          p_valbruto      number   default null        -- 1012484.  ovcaceres.  02/03/2012
                        );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_CXP ( p_Infa             varchar2,
                      p_Periodo          integer,
                      p_Numero           varchar2,
                      p_Cias             integer,
                      p_Fecha            date,
                      p_Usua_Gene        varchar2,
                      p_Agr_CXP          varchar2,
                      p_py_EtPy          integer,
                      p_py_Proy          varchar2,
                      p_py_EnAp          integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_CXP_PGPR( p_Infa             varchar2,
                          p_Periodo          integer,
                          p_Numero           varchar2,
                          p_Cias             integer,
                          p_Fecha            date,
                          p_Usua_Gene        varchar2,
                          p_VigOrpa          integer,
                          p_Orpa             integer,
                          p_VrNeto           number,
                          p_pref             varchar2   default null,          -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
                          p_nrodoc           varchar2   default null           -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
                             );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_ORPV ( p_Infa             varchar2,
                       p_Periodo          integer,
                       p_Numero           varchar2,
                       p_cias             integer,
                       p_Fecha            date,
                       p_Usua_Gene        varchar2,
                       p_Vigorpa          integer,
                       p_Orpa             integer,
                       p_auxi             integer,
                       p_tpmv             integer,
                       p_ValBruto         number,
                       p_ValNeto          number,
                       p_rengln           integer,
                       p_Agr_CXP          varchar2,
                       p_pref             varchar2,             -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
                       p_nrodoc           varchar2              -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
                         );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_TES ( p_Infa             varchar2,
                      p_inrq             integer,
                      p_Periodo          integer,
                      p_Numero           varchar2,
                      p_cias             integer,
                      p_Fecha            date,
                      p_Usua_Gene        varchar2,
                      p_py_EtPy          integer,
                      p_py_Proy          varchar2,
                      p_py_EnAp          integer     );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_PPTO ( p_Infa             varchar2,
                       p_Periodo          integer,
                       p_Numero           varchar2,
                       p_Cias             integer,
                       p_Fecha            date,
                       p_Usua_Gene        varchar2,
                       p_py_EtPy          integer,
                       p_py_Proy          varchar2,
                       p_py_EnAp          integer     );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_PPTO_2 ( p_Infa             varchar2,
                         p_Periodo          integer,
                         p_Numero           varchar2,
                         p_Cias             integer,
                         p_Fecha            date,
                         p_Usua_Gene        varchar2,
                         p_py_EtPy          integer,
                         p_py_Proy          varchar2,
                         p_py_EnAp          integer     );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_PPTO_CXP ( p_Infa             varchar2,
                           p_Periodo          integer,
                           p_Numero           varchar2,
                           p_Cias             integer,
                           p_Fecha            date,
                           p_Usua_Gene        varchar2,
                           p_VigOrPa          integer,
                           p_OrPa             integer,
                           p_Cxp_Tpmv         integer,
                           p_Cxp_Auxi         integer,
                           p_Valor            number,
                           p_pref             varchar2   default null,          -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
                           p_nrodoc           varchar2   default null           -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
                               );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_PPTO_TESOR ( p_Infa             varchar2,
                             p_Periodo          integer,
                             p_Numero           varchar2,
                             p_cias             integer,
                             p_Fecha            date,
                             p_Usua_Gene        varchar2    );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_TES_NETO ( p_Infa              varchar2,
                           p_Periodo           integer,
                           p_Numero            varchar2,
                           p_cias              integer,
                           p_Fecha             date,
                           p_Usua_Gene         varchar2,
                           p_tpco              integer,
                           p_tpcoe             integer,
                           p_nrocom            integer,
                           p_auxi_Agr          integer,
                           p_cias_etct         integer,
                           p_rengln     in out integer,
                           p_rengln_tmp in out integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure CAR_TES_NO_NETO ( p_Infa              varchar2,
                              p_Periodo           integer,
                              p_Numero            varchar2,
                              p_cias              integer,
                              p_Fecha             date,
                              p_Usua_Gene         varchar2,
                              p_tpco              integer,
                              p_tpcoe             integer,
                              p_nrocom            integer,
                              p_auxi_Agr          integer,
                              p_etct              integer,
                              p_rengln     in out integer,
                              p_rengln_tmp in out integer );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure DESHACE_INFA ( p_Infa       varchar2,
                           p_Periodo    integer,
                           p_Numero     varchar2,
                           p_Usua_Gene    varchar2   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure INICIALIZA_ESTADO ( p_Infa           varchar2,
                                p_Periodo        integer,
                                p_Numero         varchar2,
                                p_Cias           integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure MAYO_PIDE_AREA_CECO( p_Etct            integer,
                                 p_Mayo            varchar2,
                                 p_Pide_Area  out  varchar2,
                                 p_Pide_CeCo  out  varchar2   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure NRO_DOC_PPTO ( p_Infa           varchar2,
                           p_Periodo        integer,
                           p_Numero         varchar2,
                           p_Cias           integer,
                           p_tpdo           varchar2,
                           p_tpnr           varchar2,
                           p_nrodoc  out    varchar2,
                           p_Acta    out    integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure GEN_NRODOC_PPTO ( p_Infa           varchar2,
                              p_Periodo        integer,
                              p_Numero         varchar2,
                              p_Cias           integer,
                              p_Vigencia       integer,
                              p_TpDo           varchar2,
                              p_NroDoc    out  varchar2,
                              p_Acta      out  integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  function TRAE_MAYO_PASIVO_NETO ( p_Cias     integer,
                                   p_Infa     varchar2,
                                   p_Periodo  integer,
                                   p_Numero   varchar2 ) RETURN VARCHAR2;
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure TRAE_CPTO_SUCE( p_Infa                varchar2,
                            p_inco                varchar2,
                            p_Inco_Base_Suce  out varchar2  );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure Trae_Dat_Cia( p_cias  in   integer,
                          p_inrq  in   integer,
                          p_nivel out  varchar2,
                          p_etct  out  integer,
                          p_etcf  out  integer  );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure TRAE_TE_TPMV ( p_TpMv    in   integer,
                           p_Natu    out  varchar2,
                           p_pp_TpMv out  varchar2 );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  --  Soli 5584 . Sobrecarga del m�todo VALIDAR
  --  Soli 5584 . Cambio en el numero de parametros de entrada como criterio de borrado
  --  Soli 5584 . Los estados permitidos de borrado en GE_TINAD son ('DT','CA','CF')

  Procedure Validar ( p_Infa           varchar2,
                      p_inrq           integer,
                      p_Periodo        integer,
                      p_Numero         varchar2,
                      p_Opcion     out varchar2,
                      p_Msg        out varchar2  );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  Procedure Valida_Ge_Tcias (
                             p_Infa           varchar2,
                             p_inrq           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_Cias           integer,
                             p_Opcion     out varchar2,
                             p_Msg        out varchar2,
                             p_senal      out number
                            );
    --
    -- Observaciones:
    -- 1. EJ2H- 17-ENE-2006 - Solicitud 5584
    --    . Se valida que la empresa exista
    --
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  Procedure Valida_Te_Tctrl (
                             p_Infa           varchar2,
                             p_inrq           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_Cias           integer
                            );
    --
    -- Observaciones:
    -- 1. EJ2H- 17-ENE-2006 - Solicitud 5584
    --    . Se valida que la empresa exista en tesoreria si la parametrizaci�n de interfases GE_TINPA
    --      maneja TpMV de Tesoreia INPA_TESOR_TPMV
    --
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  Procedure Valida_Cp_Tctrl (
                             p_Infa           varchar2,
                             p_inrq           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_Cias           integer
                            );
    --
    -- Observaciones:
    -- 1. EJ2H- 17-ENE-2006 - Solicitud 5584
    --    . Se valida que la empresa exista en Cuentas por pagar si la parametrizaci�n de interfases GE_TINPA
    --      maneja TpMV de CXP INPA_CXP_TPMV
    --
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  Procedure Valida_Pp_Tctrl (
                             p_Infa           varchar2,
                             p_inrq           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_Cias           integer
                            );
    --
    -- Observaciones:
    -- 1. EJ2H- 17-ENE-2006 - Solicitud 5584
    --    . Se valida que la empresa exista en Presupuesto si la parametrizaci�n de interfases GE_TINPA
    --      maneja TpMV de PPTO INPA_PPTO_TPMV
    --
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------

  procedure VALIDA_AREA ( p_Infa           varchar2,
                          p_inrq           integer,
                          p_Cias           integer,
                          p_Periodo        integer,
                          p_Numero         varchar2,
                          p_EtAr           integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure VALIDA_BANCOS ( p_Infa           varchar2,
                            p_inrq           integer,
                            p_Cias           integer,
                            p_Periodo        integer,
                            p_Numero         varchar2   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure VALIDA_CECO ( p_Infa           varchar2,
                          p_inrq           integer,
                          p_Cias           integer,
                          p_Periodo        integer,
                          p_Numero         varchar2,
                          p_EtCo           integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE VALIDA_CHEQUES ( p_Infa           varchar2,
                             p_Cias           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_Opcion     out varchar2,
                             p_Msg        out varchar2  );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE VALIDA_CODIGOS ( p_Infa           varchar2,
                             p_inrq           integer,
                             p_Cias           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_Opcion     out varchar2,
                             p_Msg        out varchar2  );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure VALIDA_FECHA_PERIODO ( p_Infa           varchar2,
                                   p_Cias           integer,
                                   p_Periodo        integer,
                                   p_Numero         varchar2   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure VALIDA_IMPU ( p_Infa           varchar2,
                          p_Cias           integer,
                          p_Periodo        integer,
                          p_Numero         varchar2,
                          p_EtPp           integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure VALIDA_MAYO ( p_Infa           varchar2,
                          p_Cias           integer,
                          p_Periodo        integer,
                          p_Numero         varchar2,
                          p_EtCt           integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE VALIDA_NCUENTA ( p_Infa           varchar2,
                             p_Cias           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure VALIDA_RECURSO ( p_Infa           varchar2,
                             p_Cias           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_EtRe           integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure VALIDA_TERCEROS ( p_Infa           varchar2,
                              p_Cias           integer,
                              p_Periodo        integer,
                              p_Numero         varchar2 );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure VERIFICA_TPCO ( p_Infa           varchar2,
                            p_inrq           integer,
                            p_Cias           integer,
                            p_Opcion     out varchar2,
                            p_Msg        out varchar2  );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure VERIFICA_CIERRES ( p_Infa           varchar2,
                               p_inrq           integer,
                               p_Periodo        integer,
                               p_Numero         varchar2,
                               p_Fech_Proc      date,
                               p_Opcion     out varchar2,
                               p_Msg        out varchar2  );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure VALIDA_CPTO_SUCESOR ( p_Infa          varchar2,
                                  p_inrq          integer,
                                  p_Cias          integer,
                                  p_Periodo       integer,
                                  p_Numero        varchar2  );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  procedure VERIFICA_ERRADOS ( p_Infa          varchar2,
                               p_Periodo       integer,
                               p_Numero        varchar2,
                               p_Consulta  out varchar2,
                               p_Msg       out varchar2  );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  function Car_a_Fecha ( p_Fecha  varchar2 ) return date;
  ---------------------------------------------------------------------------------------------------------
  --  1.  EJ2H  15-DEC-2005 -- Soli 5584
  --      . Sobrecarga del m�todo CONFIRMA_INFA
  --      . Este metodo actualiza la tabla GE_TINAD
  --      . Cambio en el n�mero de parametros de entrada para el criterio de confirmaci�n
  procedure CONFIRMA_INFA ( p_Infa           varchar2,
                            p_Periodo        integer,
                            p_Numero         varchar2,
                            p_Usuario        varchar2    ) ;
  ---------------------------------------------------------------------------------------------------------
  procedure CONFIRMA_INFA ( p_Infa           varchar2,
                            p_inrq           integer,
                            p_Cias           integer,
                            p_Periodo        integer,
                            p_Numero         varchar2,
                            p_Usuario        varchar2    );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  FUNCTION Limpia_Sentencia ( p_Sentencia varchar2 ) return varchar2;
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE INS_TMP_NROCOM ( p_Cursor     integer,
                             p_Sentencia  varchar2,
                             p_Cias       integer,
                             p_TpCo       integer,
                             p_NroCom     integer,
                             p_FecMov     integer  );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE INS_TMP_ORPA   ( p_Cursor     integer,
                             p_Sentencia  varchar2,
                             p_Cias       integer,
                             p_VigOrPa    integer,
                             p_OrPa       integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE UPD_MVTE_PGPR ( p_Cursor     integer,
                            p_Sentencia  varchar2,
                            p_Cias       integer,
                            p_VigOrPa    integer,
                            p_OrPa       integer  );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE UPD_TMP_NROCOM ( p_Cursor     integer,
                             p_Sentencia  varchar2,
                             p_NroCom     integer,
                             p_TpCo_Gen   integer,
                             p_TpCo_Esp   integer  default null );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE UPD_TMP_ORPA ( p_Cursor     integer,
                           p_Sentencia  varchar2,
                           p_OrPa       integer   );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE EJECUTA_SENTENCIA ( p_Sentencia  varchar2 );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  /*
  * Valida las formas de pago asociado al cargue de intertfases
  *
  * @solicitud COMO058
  * @autor jcvargas
  *
  */

  PROCEDURE VALIDA_FPAG ( p_Infa	in varchar2,
                          p_Cias	in integer,
                          p_Periodo	in integer,
                          p_Numero	in varchar2 );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  /* 109973
  * Valida que los Comprobantes Contables no se Encuentren Descuadrados
  *
  * @p_cias      Empresa que Genera el Comprobante
  * @p_TpCo      Tipo de comprobante
  * @p_NroCom    Numero de comprobante
  * @p_Periodo   Periodo contable AAAAMM
  * @p_proceso   Proceso que realiza la Contabilidad
  * @p_Infa      Tipo de Interfase
  * @p_Numero    Archivo
  * @p_Usua_Gene Usuario
  *
  */
  FUNCTION val_cuadre_comp ( p_cias      in  sc_tctco.ctco_cias%type,
                             p_TpCo      in  sc_tctco.ctco_tpco%type,
                             p_NroCom    in  sc_tctco.ctco_nrocom%type,
                             p_Periodo   in  sc_tctco.ctco_fecmov%type,
                             p_proceso   in  varchar2,
                             p_Infa      varchar2,
                             p_Numero    varchar2,
                             p_Usua_Gene varchar2
                            ) return varchar2 ;
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  /* COMO058
  *
  * Valida las facturas repetidas en el cargue de intertfases
  *
  * @p_Infa      Codigo de interfase
  * @p_Cias      Codigo de empresa.
  * @p_Periodo   Periodo de interfase.
  * @p_Numero    Numero de cargue.
  *
  */
  PROCEDURE Valida_Factura ( p_Infa	   in varchar2,
                             p_Cias	   in integer,
                             p_Periodo in integer,
                             p_Numero	 in varchar2 );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  /* COMO058
  *
  * Valida valor moneda extranjera asociado al cargue de intertfases
  *
  * @p_Infa      Codigo de interfase
  * @p_inrq      Numero de requerimiento de interfase
  * @p_Cias      Codigo de empresa.
  * @p_Periodo   Periodo de interfase.
  * @p_Numero    Numero de cargue.
  *
  */
  PROCEDURE Valida_MonedaMy( p_Infa	   in varchar2,
                             p_inrq    in integer,
                             p_Cias	   in integer,
                             p_Periodo in integer,
                             p_Numero	 in varchar2 );
  --  inicio 1012484.  ovcaceres.  01/03/2012
  PROCEDURE Valida_Aica( p_Infa	   in varchar2,
                             p_inrq    in integer,
                             p_Cias	   in integer,
                             p_Periodo in integer,
                             p_Numero	 in varchar2 );
  --
  PROCEDURE Valida_Impuestos( p_Infa	   in varchar2,
                             p_inrq    in integer,
                             p_Cias	   in integer,
                             p_Periodo in integer,
                             p_Numero	 in varchar2 );
  --  fin 1012484.  ovcaceres.  01/03/2012
  ---------------------------------------------------------------------------------------------------------
  /*
  * Actualiza_Inad_inrq   Actualiza el nro. de requerimiento en la tabla GE_TINAD.
  *
  * @p_Numero             N�mero de cargue de interfase.
  * @p_inrq               N�mero de requerimiento de interfase
  *
  */  
  procedure Actualiza_Inad_inrq ( p_Numero varchar2,
                                  p_inrq   number );
  ---------------------------------------------------------------------------------------------------------
  /*
  * trae_inad_inrq        Retorna el nro. de requerimiento de la tabla GE_TINAD.
  *
  * @p_Infa               Codigo de interfase
  * @p_Numero             N�mero de cargue de interfase.
  *
  */   
  function trae_inad_inrq( p_Infa      varchar2,
                           p_Numero    varchar2) return number;
  ---------------------------------------------------------------------------------------------------------
  -- Ini COMO034 ymoreno
  PROCEDURE Crea_Reserva   (p_Cias       number, 
				  									p_VigOrPa    number,										
				  									p_OrPa       number,										
				  									p_VNeto    	 number,
														P_fpag	     varchar2,           --  vers.1031.gap.-.18297 ovcaceres.07/11/2012
														p_auxi			 number,
														p_usuario    varchar2);
  -- Fin COMO034 ymoreno														 
  ---------------------------------------------------------------------------------------------------------
  --
  --Ini soli_1044 pmp
  --
  PROCEDURE VALIDA_CUENTA_BANCO_DESTINO (p_Infa           varchar2,
                                         p_cias           integer,
                                         p_Periodo        integer,
                                         p_Numero         varchar2   );
  --
  ---------------------------------------------------------------------------------------------------------
  --
  --Fin soli_1044 pmp
  --
  -- Ini. versi�n 1045 lmesa@cidenet.com.co
  --
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE Valida_Archivo_Teso ( p_Numarch     NUMBER
                                 ,p_Numreq      INTEGER
                                 ,p_Fecmov      INTEGER
                                 ,p_Fecdoc      DATE
                                 ,p_Fond        VARCHAR2
                                 ,p_Fec_Carg    DATE
                                 ,p_Cias        VARCHAR2
                                 ,p_Usuario     VARCHAR2
                                 ,p_lgtr        NUMBER
                                 ,p_Opcion  OUT VARCHAR2
                                 ,p_Msg     OUT VARCHAR2
                                 );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE Procesa_Archivo_Teso ( p_Numarch    NUMBER
                                 ,p_Numreq      INTEGER
                                 ,p_Fecmov      INTEGER
                                 ,p_Fecdoc      DATE
                                 ,p_Fond        VARCHAR2
                                 ,p_Fec_Carg    DATE
                                 ,p_Cias        VARCHAR2
                                 ,p_Usuario     VARCHAR2
                                 ,p_lgtr        NUMBER
                                 ,p_Opcion  OUT VARCHAR2
                                 ,p_Msg     OUT VARCHAR2
                                 );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE Procesos_PosCargue_Teso( nro_Cargue       NUMBER
                                     ,p_lgtr          NUMBER
                                     ,p_Usuario       VARCHAR2
                                     ,p_Opcion    OUT VARCHAR2
                                     ,p_cod_rspta OUT VARCHAR2
                                     ,p_rspta     OUT VARCHAR2
                                    );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  FUNCTION Cias_Mayor RETURN NUMBER;
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  FUNCTION Cias_Menor RETURN NUMBER;
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  --
  -- Ini. versi�n 1045 lmesa@cidenet.com.co
  -- ini 1046 lvgomez
  PROCEDURE Car_Mvif ( p_Periodo   INTEGER
                      ,p_Numero    VARCHAR2
                      ,p_Cias      INTEGER
                      ,p_Fecha     DATE
                      ,p_Usua_Gene VARCHAR2
                     );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE Genera_Mvif ( p_cias           INTEGER,
                          p_tpco           INTEGER,
                          p_periodo        INTEGER,
                          p_nrocom         NUMBER,
                          p_fecha          DATE,
                          p_fond           INTEGER,
                          p_valor          NUMBER,
                          p_sf_tpmv        INTEGER,
                          p_numero         INTEGER,
                          p_usuario        VARCHAR2,
                          p_cod_rpta  OUT  VARCHAR2,  
                          p_msg_rpta  OUT  VARCHAR2 
                        );
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE Valida_tpmv ( p_Infa    VARCHAR2
                         ,p_Cias    INTEGER
                         ,p_Periodo INTEGER
                         ,p_Numero  VARCHAR2
                         ,p_EtCt    INTEGER );
  -- fin 1046 lvgomez
end GE_QINFA;
/
create or replace
Package Body GE_QINFA  as
  --
  -- #VERSION:0000001048
  --
  --
  -- Procedimientos y Funciones para Procesamiento de Interfases
  --
  -- Almoto - 18 noviembre 2004 - Solicitud 5213
  -- EJ2H   - 22 diciembre 2005 - Solicitud 5584
  --          . Se incluye el parametro de requerimiento
  --
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  Procedure Procesa_Infa1 ( p_Infa           varchar2,
                           p_inrq           integer,
                           p_Periodo        integer,
                           p_Numero         varchar2,
                           p_Fecha          date,
                           p_Usua_Gene      varchar2,
                           p_Agr_CXP        varchar2,
                           p_Proc           varchar2,
                           p_py_EtPy        integer,
                           p_py_Proy        varchar2,
                           p_py_EnAp        integer    ) is
    --
    -- MODIFICACIONES
    -- 1. EJ2H 21-DEC-2005  -- Soli 5584
    --    . Se valida que la empresa pertenezca al requerimiento
    --
    v_cias_Descri   ge_tcias.cias_Descri%Type;
    --
    cursor c_inar_cias is
    select distinct inar_cias
    from   ge_tinarch
    where  inar_numero = p_numero
    order  by inar_cias;
    --
    cursor c_Cias ( pc_Cias integer ) is   -- Soli 5584
    select cias_descri                     -- Soli 5584
    from   ge_vinrq, ge_tcias              -- Soli 5584
    where  cias_cias = inrq_cias           -- Soli 5584
    and    inrq_cias = pc_Cias;            -- Soli 5584
    --
  begin
    --
    for i in c_inar_cias loop
      --
      dbms_output.put_line ('Cias='||i.inar_Cias||' Car_Ppto');
      --
      if ( p_Proc in ( 'TO','TODO', 'PPTO1' ) ) then
        Car_Ppto( p_Infa, p_Periodo, p_Numero, i.inar_Cias, p_Fecha, p_Usua_Gene, p_py_EtPy, p_py_Proy, p_py_EnAp );
      end if;
      --
      dbms_output.put_line ('Cias='||i.inar_Cias||' Car_Ppto_2');
      if ( p_Proc in ( 'TO','TODO', 'PPTO2' ) ) then
        Car_Ppto_2( p_Infa, p_Periodo, p_Numero, i.inar_Cias, p_Fecha, p_Usua_Gene, p_py_EtPy, p_py_Proy, p_py_EnAp );
      end if;
      --
      dbms_output.put_line ('Cias='||i.inar_Cias||' Car_Cxp');
      if ( p_Proc in ( 'TO','TODO', 'CXP' ) ) then
        Car_Cxp( p_Infa, p_Periodo, p_Numero, i.inar_Cias, p_Fecha, p_Usua_Gene, p_Agr_CXP, p_py_EtPy, p_py_Proy, p_py_EnAp );
      end if;
      --
      dbms_output.put_line ('Cias='||i.inar_Cias||' Car_Con');
      if ( p_Proc in ( 'TO', 'TODO', 'CONTAB' ) ) then
        Car_Con( p_Infa, p_inrq, p_Periodo, p_Numero, i.inar_Cias, p_Fecha, p_Usua_Gene, p_Agr_CXP, p_py_EtPy, p_py_Proy, p_py_EnAp );
      end if;
      --
      dbms_output.put_line ('Cias='||i.inar_Cias||' Car_Tes');
      if ( p_Proc in ( 'TO','TODO', 'TESOR' ) ) then
        Car_Tes( p_Infa, p_inrq, p_Periodo, p_Numero, i.inar_Cias, p_Fecha, p_Usua_Gene, p_py_EtPy, p_py_Proy, p_py_EnAp );
      end if;
      --
    end loop c_inar_Cias;
    --
  End Procesa_Infa1;
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------

  Procedure Procesa_Infa ( p_Infa           varchar2,
                           p_inrq           integer,
                           p_Periodo        integer,
                           p_Numero         varchar2,
                           p_Fecha          date,
                           p_Usua_Gene      varchar2,
                           p_Agr_CXP        varchar2,
                           p_Proc           varchar2,
                           p_py_EtPy        integer,
                           p_py_Proy        varchar2,
                           p_py_EnAp        integer    ) is
    --
    -- MODIFICACIONES
    -- 1. EJ2H 21-DEC-2005  -- Soli 5584
    --    . Se valida que la empresa pertenezca al requerimiento
    --
    v_cias_Descri   ge_tcias.cias_Descri%Type;
    --
    cursor c_inar_cias is
    select distinct inar_cias
    from   ge_tinarch
    where  inar_numero = p_numero
    order  by inar_cias;
    --
    -- Inicio 1033 lhernandez
    cursor c_ppto (p_cias number) is
      select /*nvl(inar_ppto,'N') 1037 fagarcia*/
	        'S' inar_ppto
      from ge_tinarch, 
	       pp_tctrl--1037 fagarcia
      where inar_cias = p_cias
      and inar_numero = p_numero
	  and inar_cias = ctrl_cias--1037 fagarcia, si la empresa existe en la tabla de control de presupuesto, es por que si maneja presupuesto.
	  ;
      r_ppto c_ppto%rowtype;
    -- Fin 1033 lhernandez
  begin
    --
    dbms_output.put_line('Almoto. Antes de c_inar_cias.  Proc='||p_Proc);
    --
	sf_pins_error('ge_qinfa.Procesa_Infa paso1');
    for i in c_inar_cias loop
    -- Inicio 1033 lhernandez
      open c_ppto (i.inar_Cias);
      fetch c_ppto into r_ppto;
	  if c_ppto%notfound then--1037 fagarcia
	    r_ppto.inar_ppto := 'N';--1037 fagarcia
	  end if;--1037 fagarcia
      close c_ppto;
    -- Fin 1033 lhernandez
      --
	  sf_pins_error('ge_qinfa.Procesa_Infa paso2 r_ppto.inar_ppto='||r_ppto.inar_ppto||' p_Proc='||p_Proc);
	    dbms_output.put_line('Almoto. c_inar_cias.  inar_Cias='||i.inar_Cias);
	    --
      -- if ( p_Proc in ( 'TO','TODO', 'PPTO1' ) ) then --Antes de 1033 lhernandez
      if (( p_Proc in ( 'TO','TODO', 'PPTO1' ) ) and (r_ppto.inar_ppto <> 'N')) then --1033 lhernandez
        Car_Ppto( p_Infa, p_Periodo, p_Numero, i.inar_Cias, p_Fecha, p_Usua_Gene, p_py_EtPy, p_py_Proy, p_py_EnAp );
      end if;
      --
      --if ( p_Proc in ( 'TO','TODO', 'PPTO2' ) ) then --Antes de 1033 lhernandez
      if (( p_Proc in ( 'TO','TODO', 'PPTO2' )) and (r_ppto.inar_ppto <> 'N')) then --Antes de 1033 lhernandez
        Car_Ppto_2( p_Infa, p_Periodo, p_Numero, i.inar_Cias, p_Fecha, p_Usua_Gene, p_py_EtPy, p_py_Proy, p_py_EnAp );
      end if;
      --
      if ( p_Proc in ( 'TO','TODO', 'CXP' ) ) then
        Car_Cxp( p_Infa, p_Periodo, p_Numero, i.inar_Cias, p_Fecha, p_Usua_Gene, p_Agr_CXP, p_py_EtPy, p_py_Proy, p_py_EnAp );
      end if;
      --
      if ( p_Proc in ( 'TO', 'TODO', 'CONTAB' ) ) then
        Car_Con( p_Infa, p_inrq, p_Periodo, p_Numero, i.inar_Cias, p_Fecha, p_Usua_Gene, p_Agr_CXP, p_py_EtPy, p_py_Proy, p_py_EnAp );
      end if;
      --
      if ( p_Proc in ( 'TO','TODO', 'TESOR' ) ) then
        Car_Tes( p_Infa, p_inrq, p_Periodo, p_Numero, i.inar_Cias, p_Fecha, p_Usua_Gene, p_py_EtPy, p_py_Proy, p_py_EnAp );
        Car_Mvif(p_Periodo, p_Numero, i.inar_Cias, p_Fecha, p_Usua_Gene); -- 1046 lvgomez
      end if;
      --
    end loop c_inar_Cias;
    --
  End Procesa_Infa;
  --
  ------------------------------------------------------------------------------------------------------------------
  ------------------------------------------------------------------------------------------------------------------
  Procedure Actualiza_Inad_Ini ( p_Numero         varchar2 ) is
    --  Observaciones
    --  1.  EJ2H  15-DEC-2005 -- Soli 5584
    --      . Sobrecarga del metodo ACTUALIZA_INAD_INI
    --      . Este metodo actualiza la tabla GE_TINAD
    --      . Cambio en el numero de parametros de entrada para el criterio de actualizacion
  begin
    --
    update ge_tinad
       set inad_ult_fecha  = sysdate
     where inad_numero = p_Numero;
    --
    commit;
    --
  exception
    when others then
         raise_application_error( -20700, 'Error actualizando la fecha de accion en GE_TINAD. '||sqlerrm );
  end Actualiza_INAD_Ini;
  ------------------------------------------------------------------------------------------------------------------
  ------------------------------------------------------------------------------------------------------------------
  Procedure Actualiza_Inad_Ini ( p_Infa           varchar2,
                                 p_Numero         varchar2 ) is
  begin
    --
    update ge_tinad                    -- Soli_6304 (Se cambia GE_TINADMIN)
       set inad_ult_fecha  = sysdate
     where inad_infa   = p_Infa
       and inad_numero = p_Numero;
    --
    commit;
    --
  end Actualiza_INAD_Ini;
  ------------------------------------------------------------------------------------------------------------------
  ------------------------------------------------------------------------------------------------------------------
  Procedure Actualiza_Inad_Fin ( p_Periodo        integer,
                                 p_Numero         varchar2,
                                 p_Accion         varchar2,
                                 p_Fecha          date,
                                 p_Usua           varchar2 ) is
    --
    v_Periodo_Proc integer;    -- Soli_5213
    --
    v_Ult_Accion  ge_tinad.inad_Ult_Accion%Type;
    -- Inicio. Vs.1038  RFC_19469	Jcrodriguez   --Inicio integraci�n RFC_19469 Vs. 1038  25/03/2014 Jcmartinez
    v_inhs    ge_qinhs.ty_inhs;
    v_msg     Varchar2(300);
    v_Rpta    Varchar2(100);
    -- Fin. Vs.1038 RFC_19469	Jcrodriguez     --Fin integraci�n RFC_19469 Vs. 1038  25/03/2014 Jcmartinez
    --
  begin
    --
    if ( p_Fecha is not null ) then
      v_Periodo_Proc := to_char(p_Fecha, 'yyyymm');
    else
      v_Periodo_Proc := null;
    end if;
    --
    v_Ult_Accion := case p_Accion
                      when 'TO'     then 'PT'   -- Soli 5589
                      when 'TODO'   then 'TO'
                      when 'PPTO1'  then 'PP1'
                      when 'PPTO2'  then 'PP2'
                      when 'CXP'    then 'PC'
                      when 'CONTAB' then 'PCT'
                      when 'TESOR'  then 'PT'
                      else p_Accion
                    end;
    --
    update ge_tinad
    set    inad_ult_accion  = v_Ult_Accion,
           inad_ult_fecha   = sysdate,
           inad_ult_periodo = nvl(v_Periodo_Proc, p_Periodo),
           inad_usua        = p_Usua
    where  inad_numero = p_Numero;
    -- Inicio. Vs.1038  RFC_19469	Jcrodriguez   --Inicio integraci�n RFC_19469 Vs. 1038  25/03/2014 Jcmartinez
    v_inhs.inhs_numero := p_Numero;
    v_inhs.inhs_accion := v_Ult_Accion;
    v_inhs.inhs_usua   := p_Usua;
    --
    ge_qinhs.insertar_ge_tinhs( v_inhs, v_msg, v_Rpta );
    --
  -- Fin. Vs.1038  RFC_19469	Jcrodriguez       --Fin integraci�n RFC_19469 Vs. 1038  25/03/2014 Jcmartinez
  --
  commit;
  --
  end Actualiza_INAD_Fin;
  ---------------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------------
  procedure Actualiza_INAD_Fin ( p_Infa           varchar2,
                                 p_Periodo        integer,
                                 p_Numero         varchar2,
                                 p_Accion         varchar2,
                                 p_Fecha          date,
                                 p_Usua           varchar2 ) is
    --
    v_Periodo_Proc integer;    -- Soli_5213
    --
    v_Ult_Accion  ge_tinad.inad_Ult_Accion%Type;
    -- Inicio. Vs.1038  RFC_19469	Jcrodriguez    --Inicio integraci�n RFC_19469 Vs. 1038  25/03/2014 Jcmartinez
    v_inhs    ge_qinhs.ty_inhs;
    v_msg     Varchar2(300);
    v_Rpta    Varchar2(100);
    -- Fin. Vs.1038  RFC_19469	Jcrodriguez      --Fin integraci�n RFC_19469 Vs. 1038  25/03/2014 Jcmartinez
    --
  begin
    --
    --
    -- Ini.Soli_5213
    --
    if ( p_Fecha is not null ) then
      v_Periodo_Proc := to_char(p_Fecha, 'yyyymm');
    else
      v_Periodo_Proc := null;
    end if;
    --
    -- Fin.Soli_5213
    --
    v_Ult_Accion := case p_Accion
                      when 'TO'     then 'TO'
                      when 'TODO'   then 'TO'
                      when 'PPTO1'  then 'PP1'
                      when 'PPTO2'  then 'PP2'
                      when 'CXP'    then 'PC'
                      when 'CONTAB' then 'PCT'
                      when 'TESOR'  then 'PT'
                      else p_Accion
                    end;
    --
    update ge_tinad                                -- Soli_6304 (Se cambia GE_TINADMIN)
       set inad_ult_accion  = v_Ult_Accion,
           inad_ult_fecha   = sysdate,
           inad_ult_periodo = nvl(v_Periodo_Proc, p_Periodo),
           inad_Usua        = p_Usua
     where inad_infa   = p_Infa
       and inad_numero = p_Numero;
    -- Inicio. Vs.1038  RFC_19469	Jcrodriguez   --Inicio integraci�n RFC_19469 Vs. 1038  25/03/2014 Jcmartinez
      v_inhs.inhs_numero := p_Numero;
      v_inhs.inhs_accion := v_Ult_Accion;
      v_inhs.inhs_infa   := p_Infa;
      v_inhs.inhs_usua   := p_Usua;
      --
      ge_qinhs.insertar_ge_tinhs( v_inhs, v_msg, v_Rpta );
      --
    -- Fin. Vs.1038  RFC_19469	Jcrodriguez     --Fin integraci�n RFC_19469 Vs. 1038  25/03/2014 Jcmartinez
    --
    --
    commit;
    --
  End Actualiza_Inad_Fin;
  --
  --
  --
  procedure Actualiza_Inar ( p_Infa           varchar2,
                             p_inrq           integer,    -- Soli 5584
                             p_Periodo        integer,
                             p_Numero         varchar2   ) is
    --
    -- Almoto - 1 julio 2006 - Solicitud 5997
    -- . Nueva version que utiliza la tabla GE_TINTM.
    --
    --
    v_cias_descri ge_tcias.cias_descri%type;
    v_cont_area   ge_tarea.area_area%type;
    v_ppto_area   ge_tarea.area_area%type;
    v_impu        pp_timpu.impu_impu%type;
    v_ciud        ge_tciud.ciud_secu%type;
    v_ceco        ge_tcecos.ceco_ceco%type;
    v_mayo        ge_tmayor.mayo_mayo%type;
    v_mayo_enti   ge_tmayor.mayo_mayo%type;
    v_cntr_mayo   ge_tmayor.mayo_mayo%type;
    v_campo1      ge_tinpa.inpa_campo1%type;
    v_campo2      ge_tinpa.inpa_campo2%type;
    v_campo3      ge_tinpa.inpa_campo3%type;
    v_campo4      ge_tinpa.inpa_campo4%type;
    v_campo5      ge_tinpa.inpa_campo5%type;
    v_campo6      ge_tinpa.inpa_campo6%type;
    v_campo7      ge_tinpa.inpa_campo7%type;
    v_campo8      ge_tinpa.inpa_campo8%type;
    v_campo9      ge_tinpa.inpa_campo9%type;
    v_campo10     ge_tinpa.inpa_campo10%type;
    v_tpcta       ge_tineq.ineq_tpcta%type;
    --
    --
    cursor c_cias is
    select distinct inar_cias
      from ge_tinarch
     where inar_infa   = p_Infa
       and inar_fecmov = p_Periodo
       and inar_numero = p_Numero
     order by inar_cias;
    --
    cursor c_inpa ( pc_Cias integer ) is
    select distinct
           inpa_campo1,          inpa_campo2,         inpa_campo3,      inpa_campo4,      inpa_campo5,
           inpa_campo6,          inpa_campo7,         inpa_campo8,      inpa_campo9,      inpa_campo10,
           inpa_mayo_costo,      inpa_cont_mayo,      inpa_mayo_inver,  inpa_impu,
           inpa_tpax,            inpa_tpax_contra,    inpa_cxp_mayo,    inpa_cont_tpco,   inpa_auxi,
           inpa_cont_tpcoe,      inpa_cont_tporan,    inpa_auxi_contra, inpa_area,        inpa_tpdo,
           inpa_ppto_tpmv,       inpa_ppto_tpnr,      inpa_tpdo2,       inpa_ppto_tpmv2,  inpa_ppto_tpnr2,
           inpa_recu,            inpa_tesor_tpmv,     inpa_tesor_tpco,  inpa_tesor_tpcoe, inpa_tesor_benef_cheq,
           inpa_tpliq,           inpa_rete,           inpa_cxp_tpmv,    inpa_cxp_tpdo,    inpa_ceco,
           inpa_cxp_pgpr,        inpa_cxp_benef_pgpr, inpa_acre,        inpa_cont_trib,   inpa_cont_rete,
	         inpa_cxp_ordena_PgPr, inpa_inpa,
	         decode(tpmv_Operacion, 'T', 'S', null) te_tpmv_Tras,
           inpa_cpto_liq_base     -- inc.16266
      from ge_tinarch, ge_tinpa, te_ttpmv
     where inpa_infa     = inar_infa
       and inpa_inrq     = p_inrq
       and inpa_campo1   = inar_campo1
       and inar_numero   = p_numero
       and inar_cias     = pc_cias
       and inar_infa     = p_infa
       and tpmv_tpmv(+)  = inpa_tesor_tpmv;
    --
	CURSOR c_inpa_val ( pc_Cias INTEGER ) IS--60145
    SELECT 1
      FROM GE_TINPA
     WHERE inpa_infa     = p_infa
       AND inpa_inrq     = p_inrq
	   AND inpa_tpliq    <> 'I'
	   AND inpa_tesor_tpmv IS NOT NULL
	   ;
	--
	r_inpa   c_inpa_val%ROWTYPE;--60144
    --
    cursor c_te_tpmv ( pc_TpMv integer ) is
    select tpmv_Operacion
    from   te_ttpmv
    where  tpmv_tpmv = pc_tpmv;
    --
    v_inar_cont_Mayo  ge_tmayor.mayo_Mayo%Type;
    v_inar_Mayo       v_inar_cont_Mayo%Type;
    --
    --
    cursor c_intm is
    select nvl(max(intm_intm), 0)
      from ge_tintm;
    --
    v_intm        integer;
    --
  begin
    --
    -- Limpia la tabla temporal del procesamiento interfases
    --
    delete from ge_tintm;
    --
    --
    dbms_output.put_line('Almoto. ACTUALIZA_INAR. Antes de C_CIAS');
    --
    for i in c_cias loop
        --
        --
        dbms_output.PUT_LINE ('Almoto. ACTUALIZA_INAR. Cias  '||i.inar_cias );
        --
        begin
          select cias_descri, cias_ciud
          into   v_cias_descri, v_ciud
          from   ge_vcias
          where  cias_cias = i.inar_cias;
        exception
          when no_data_found then
            raise_application_error( -20665, 'Codigo de Empresa No Existe : ' || i.inar_Cias );
          when others then
            raise_application_error( -20666, 'Error con GE_VCIAS: ' || sqlerrm );
        end;
        --
        --dbms_output.PUT_LINE ('a c_inpa ');
        --
		Sf_Pins_Error('Ge_Qinfa '||i.inar_cias);
		--ini 60144
		OPEN c_inpa_val(i.inar_cias);
		FETCH c_inpa_val INTO r_inpa;
		/*IF c_inpa_val%FOUND THEN
   		  CLOSE c_inpa_val;
		  RAISE_APPLICATION_ERROR( -20666, 'No existe parametrizaci�n de tesorer�a para la empresa ' || i.inar_cias||', interfaz '||p_Infa );--60144
		END IF;  */        --  vers.1031.gap.-.18297 ovcaceres.07/11/2012
		CLOSE c_inpa_val;
		--fin 60144
    --sf_pins_error('p_inrq:'||p_inrq||' p_numero:'||p_numero||' i.inar_cias:'||i.inar_cias||' p_infa:'||p_infa);
        for j in c_inpa (i.inar_cias) loop
            --
            v_Campo1 := nvl(j.inpa_Campo1, '*');
            v_Campo2 := nvl(j.inpa_Campo2, '*');
            v_Campo3 := nvl(j.inpa_Campo3, '*');
            v_Campo4 := nvl(j.inpa_Campo4, '*');
            v_Campo5 := nvl(j.inpa_Campo5, '*');
            v_Campo6 := nvl(j.inpa_Campo6, '*');
            v_Campo7 := nvl(j.inpa_Campo7, '*');
            v_Campo8 := nvl(j.inpa_Campo8, '*');
            v_Campo9 := nvl(j.inpa_Campo9, '*');
            v_Campo10:= nvl(j.inpa_Campo10, '*');
            --
            --dbms_output.PUT_LINE ('v_campo1 '||v_campo1);
            --
            open c_intm;
            fetch c_intm into v_intm;
            close c_intm;
            --
            begin
              --
              insert into ge_tintm
                    ( intm_intm,                                                 intm_inpa,
                      intm_numero,                                               intm_cias,
                      intm_valor,                                                intm_fecha,
                      intm_rengln,                                               intm_descri,
                      intm_fecmov,                                               intm_impu,
                      intm_recu,                                                 intm_area,
                      intm_tpco,                                                 intm_tpcoe,
                      intm_nrocom,                                               intm_orpa,
                      intm_vigorpa,                                              intm_cxp_tpmv,
                      intm_cxp_auxi,                                             intm_inpa_cxp_mayo,
                      intm_inpa_cont_mayo,                                       intm_inpa_tpax_P,
                      intm_inpa_tpax_C,                                          intm_inpa_auxi_P,
                      intm_inpa_auxi_C,
                      intm_cxp_tpdo,                                             intm_cxp_pgpr,
                      intm_cxp_auxi_pgpr,                                        intm_cxp_ordena_pgpr,
                      intm_cxp_Bene_PgPr,                                        intm_Mayo_P,
                      intm_auxi_ter,                                             intm_auxi_aso,
                      intm_auxi_agr,                                             intm_tpliq,
                      intm_rete,                                                 intm_Mayo_C,
                      intm_cont_ceco,                                            intm_auxi_P,
                      intm_cheque,                                               intm_ncuenta,
                      intm_tporan,                                               intm_auxi_C,
                      intm_te_tpmv,                                              intm_te_tpmv_tras,
                      intm_te_tpco,                                              intm_te_tpcoe,
                      intm_te_auxi,                                              intm_te_etcf,
                      intm_te_etoe,                                              intm_te_fluj,
                      intm_te_oecj,                                              intm_te_nrocom,
                      intm_te_Bene_Cheq,                                         intm_pp_tpmv,
                      intm_pp_tpmv2,                                             intm_pp_tpdo,
                      intm_pp_tpdo2,                                             intm_pp_tpnr,
                      intm_pp_tpnr2,                                             intm_pp_nrodoc,
                      intm_pp_nrodoc2,                                           intm_pp_acta,
                      intm_pp_acta2,                                             intm_pp_area,
                      intm_inco_base_valor,                                      intm_ciud,
                      intm_inco_base,                                            intm_cont_area,
                      intm_acre,                                                 intm_auxi_terc,
                      intm_dependencia,                                          intm_pgpr,
                      intm_cont_trib,                                            intm_cont_rete,
                      intm_TpCta_Mayo,                                           /*COMO058*/intm_fmpg /*COMO058*/,
                      intm_vlrmone,                                              intm_pref,      -- COMO058
                      intm_nrodoc,                                               intm_fecdoc,    -- COMO058
                      intm_valdoc,                                                               -- COMO058
                      intm_aica,                                                 --   1012484.  ovaceres.  01/03/2012
                      intm_cpto_liq_base                                         -- inc.16266
					 ,intm_cuenta_destino                                        --soli_1044 pmp
					 ,intm_banc_destino                                          --soli_1044 pmp
                      )
               select v_intm + rownum,                                           j.inpa_inpa,
                      inar_numero,                                               inar_cias,
                      inar_valor,                                                inar_fecha,
                      inar_rengln,                                               inar_descri,
                      inar_fecmov,                                               j.inpa_impu,
                      nvl(inar_recu_Fuente, j.inpa_Recu),                        inar_area,
                      j.inpa_cont_tpco,                                          j.inpa_cont_tpcoe,
                      inar_nrocom,                                               inar_orpa,
                      inar_vigorpa,                                              j.inpa_cxp_tpmv,
                      nvl(agr.auxi_auxi, 1),                                     j.inpa_cxp_mayo,
                      j.inpa_cont_mayo,                                          j.inpa_tpax,
                      j.inpa_tpax_contra,                                        j.inpa_auxi,
                      j.inpa_auxi_Contra,
                      j.inpa_cxp_tpdo,                                           nvl(j.inpa_cxp_pgpr, 'N'),
                      inar_cxp_auxi_pgpr,                                        decode(j.inpa_TpLiq, 'N', nvl(j.inpa_cxp_Ordena_PgPr, 'NI'), null ),
                      j.inpa_cxp_Benef_PgPr,                                     j.inpa_cont_mayo, -- 1008.lhernandez
                    --j.inpa_cxp_Benef_PgPr,                                     inar_mayo,           Antes de 1008.lhernandez
                      nvl(ter.auxi_Auxi, 1),                                     nvl(aso.auxi_Auxi, 1),
                      nvl(agr.auxi_auxi, 1),                                     j.inpa_tpliq,
                      j.inpa_rete,                                               inar_cont_mayo,
                      nvl(j.inpa_ceco, nvl(inar_cont_ceco, ineq_ceco)),          inar_auxi,
                      inar_cheque,                                               inar_ncuenta,
                      j.inpa_cont_tporan,                                        inar_cont_auxi,
                      j.inpa_tesor_tpmv,                                         j.te_tpmv_tras,
                      j.inpa_tesor_tpco,                                         j.inpa_tesor_tpcoe,
                      inar_tesor_auxi,                                           inar_tesor_etcf,
                      inar_tesor_etoe,                                           inar_tesor_fluj,
                      inar_tesor_oecj,                                           inar_tesor_nrocom,
                      j.inpa_tesor_Benef_Cheq,                                   j.inpa_ppto_tpmv,
                      j.inpa_ppto_tpmv2,                                         j.inpa_tpdo,
                      j.inpa_tpdo2,                                              j.inpa_ppto_tpnr,
                      j.inpa_ppto_tpnr2,                                         inar_ppto_nrodoc,
                      inar_ppto_nrodoc2,                                         inar_ppto_acta,
                      inar_ppto_acta2,                                           nvl(j.inpa_area, nvl(ineq_area_ppto, nvl(inar_Ppto_Area, inar_Area))),
                      inar_inco_base_valor,                                      nvl(inar_ciud, v_Ciud),
                      inar_inco_base,                                            nvl(j.inpa_area, nvl(ineq_area, inar_Area)),
                      nvl(j.inpa_acre, 'N'),                                     nvl(ter.auxi_Auxi, 1),
                      inar_dependencia,                                          inar_pgpr,
                      nvl(j.inpa_cont_trib, 'N'),                                j.inpa_cont_rete,
                      decode(ineq_tpcta_area, 'K', j.inpa_mayo_costo,
                                              'G', j.inpa_cont_mayo,
                                              'I', j.inpa_mayo_inver,
                                                   j.inpa_cont_mayo  ) Mayo,     /*COMO058*/inar_fmpg,/*COMO058*/
                      inar_vlrmone,                                              inar_pref,          -- COMO058
                      inar_nrodoc,                                               inar_fecdoc,        -- COMO058
                      inar_valdoc,                                                                   -- COMO058  1012484
                      inar_aica,                                                                     --   1012484.  ovaceres.  01/03/2012
                      j.inpa_cpto_liq_base                                                           -- inc.16266
					 ,inar_cuenta_destino                                        --soli_1044 pmp
					 ,inar_banc_destino                                          --soli_1044 pmp
                 from ge_tinarch, ge_tauxil ter, ge_tauxil aso, ge_tauxil agr, ge_tineq
                where inar_infa             = p_Infa
                  and inar_fecmov           = p_Periodo
                  and inar_cias             = i.inar_Cias
                  and inar_numero           = p_Numero
                  and inar_campo1           = v_campo1
                  and nvl(inar_campo2,'*')  = v_Campo2
                  and nvl(inar_campo3,'*')  = v_Campo3
                  and nvl(inar_campo4,'*')  = v_Campo4
                  and nvl(inar_campo5,'*')  = v_Campo5
                  and nvl(inar_campo6,'*')  = v_Campo6
                  and nvl(inar_campo7,'*')  = v_Campo7
                  and nvl(inar_campo8,'*')  = v_Campo8
                  and nvl(inar_campo9,'*')  = v_Campo9
                  and nvl(inar_campo10,'*') = v_Campo10
                  and ter.auxi_Nit(+)       = inar_Tercero
                  and aso.auxi_Nit(+)       = inar_Nit_Asociado
                  and agr.auxi_Nit(+)       = inar_Nit_Agrupa
                  and ineq_infa(+)          = p_Infa
                  and ineq_inrq(+)          = p_inrq
                  and ineq_dpto(+)          = inar_Area;
              --
            end;
            --
            -- Actualiza Cuenta Mayor para la Partida Contable
            --
            update ge_tintm
               set intm_enti_Mayo_P = ( select enti_Mayo
                                          from ge_tenti
                                         where enti_Auxi = decode(intm_inpa_tpax_P, null, intm_inpa_auxi_P,
                                                                                    'N',  intm_auxi_Ter,
                                                                                    'A',  intm_auxi_aso )
                                           and nvl(enti_Status, 'A') = 'A'
                                           and enti_cias             = intm_cias
                                        )
             where intm_inpa = j.inpa_Inpa
               and intm_Cias = i.inar_Cias;
            --
            update ge_tintm
               set intm_Mayo_P = nvl(intm_Mayo_P,nvl(intm_enti_Mayo_P, nvl(intm_TpCta_Mayo, intm_inpa_cont_mayo))) --1008.lhernandez
               --set intm_Mayo_P = nvl(intm_enti_Mayo_P, nvl(intm_TpCta_Mayo, intm_inpa_cont_mayo)) --Antes de 1008.lhernandez
             where intm_inpa = j.inpa_Inpa
               and intm_Cias = i.inar_Cias;
            --
            -- Actualiza Cuenta Mayor para la Contrapartida Contable
            --
            update ge_tintm
               set intm_enti_Mayo_C = ( select enti_Mayo
                                          from ge_tenti
                                         where enti_Auxi = decode(intm_inpa_tpax_C, 'G',  1,
                                                                                    'N',  intm_auxi_Ter,
                                                                                    'A',  intm_auxi_aso )
                                           and nvl(enti_Status, 'A') = 'A'
                                           and enti_cias             = intm_cias
                                        )
             where intm_inpa = j.inpa_Inpa
               and intm_Cias = i.inar_Cias;
            --
            update ge_tintm
               set intm_Mayo_C  = nvl(intm_enti_Mayo_C, intm_inpa_cxp_Mayo)
             where intm_inpa = j.inpa_Inpa
               and intm_Cias = i.inar_Cias;
            --
            update ge_tintm
               set intm_Auxi_P  = decode(intm_inpa_TpAx_P, null, intm_inpa_Auxi_P,
                                                           'N',  intm_auxi_ter,
                                                           'A',  intm_auxi_aso )
             where intm_inpa = j.inpa_Inpa
               and intm_Cias = i.inar_Cias;
            --
            update ge_tintm
               set intm_Auxi_C  = decode(intm_inpa_TpAx_C, 'G', 1,
                                                           'N', intm_auxi_ter,
                                                           'A', intm_auxi_aso,
                                                           'C', intm_auxi_agr,
                                                           null, intm_inpa_auxi_C )
             where intm_inpa = j.inpa_Inpa
               and intm_Cias = i.inar_Cias;
            --
            update ge_tintm
               set intm_CXP_Auxi_PgPr  = decode(intm_CXP_Bene_PgPr, 'E', intm_auxi_Ter,
                                                                    'S', intm_auxi_Aso,
                                                                    'A', intm_auxi_Agr)
             where intm_inpa = j.inpa_Inpa
               and intm_Cias = i.inar_Cias;
            --
            --
        end loop c_inpa;
        --
        DBMS_OUTPUT.PUT_LINE('ALMOTO.COMMIT');
        --
    end loop c_cias;
    --
  end Actualiza_Inar;
  --
  --
  --
  procedure Borra_Archivo ( p_Infa           varchar2,
                            p_Periodo        integer,
                            p_Numero         varchar2   ) is
  begin
    --
    loop
      --
      delete ge_tinarch
      where  inar_InFa   = p_Infa
      and    InAr_FecMov = p_Periodo
      and    inar_numero = p_Numero
      and    rownum < 1000;
      --
      If ( sql%rowcount = 0 ) then
        commit;
        exit;
      End if;
      --
    end loop;
    --
    delete from ge_tinad                   -- Soli_6304
     where inad_Numero = p_Numero;
    --
    commit;
    --
  end Borra_Archivo;
  --
  --
  --
  procedure Borra_Archivo ( p_Numero         varchar2   ) is
    --  Observaciones
    --  1.  EJ2H  15-DEC-2005 -- Soli 5584
    --      . Sobrecarga del metodo BORRA_ARCHIVO
    --      . Este metodo borra la tabla GE_TINAD y GE_TINARCH
    --      . Cambio en el numero de parametros de entra como criterio de borrado
    --      . Los estados permitidos de borrado en GE_TINAD son ('DT','CA','CF')
    --
    v_inad_ult_accion ge_tinad.inad_ult_accion%type;
    --
    cursor c_ge_tinad is
    select inad_ult_accion
    from   ge_tinad
    where  inad_numero = p_numero;
    --
    v_inar integer;
    --
    cursor c_ge_tinarch is
    select count(*)
    from   ge_tinarch
    where  inar_numero = p_numero;
    --
  begin
    --
    open  c_ge_tinad;
    fetch c_ge_tinad into v_inad_ult_accion;
    if ( c_ge_tinad%notfound ) then
         v_inad_ult_accion := null;
    end if;
    close c_ge_tinad;
    --
    if    ( v_inad_ult_accion is null ) then
            null;
    elsif ( v_inad_ult_accion in ('DT','CA','CF') ) then
            --
            v_inar := 0;
            --
            open  c_ge_tinarch;
            fetch c_ge_tinarch into v_inar;
            if ( c_ge_tinarch%notfound ) then
                 v_inar := 0;
            end if;
            close c_ge_tinarch;
            --
            if ( v_inar > 0 ) then
                 begin
                   --
                   delete ge_tinarch
                   where  InAr_numero = p_numero;
                   --
                 exception
                   when others then
                        raise_application_error( -20696, 'Error borrando GE_TINARCH. '||sqlerrm );
                 end;
            end if;
            --
            begin
              --
              delete ge_tinad
              where  inad_numero = p_numero;
              --
            exception
              when others then
                   raise_application_error( -20697, 'Error borrando GE_TINAD. '||sqlerrm );
            end;
    end if;
    --
    commit;
    --
  end Borra_Archivo;
  --
  --
  --
  procedure Borra_Archivo ( p_Infa           varchar2,
                            p_Numero         varchar2   ) is
    --  Observaciones
    --  1.  EJ2H  15-DEC-2005 -- Soli 5584
    --      . Sobrecarga del metodo BORRA_ARCHIVO
    --      . Este metodo borra la tabla GE_TINAD y GE_TINARCH
    --      . Cambio en el numero de parametros de entra como criterio de borrado
    --      . Los estados permitidos de borrado en GE_TINAD son ('DT','CA','CF')
    --      . Se agregan los estados VE y PE como estados permitidos en el borrado --vr 1045 lmesa@cidenet.com.co
    --
    v_inad_ult_accion ge_tinad.inad_ult_accion%type;
    --
    cursor c_ge_tinad is
    select inad_ult_accion
    from   ge_tinad
    where  inad_infa   = p_infa
    and    inad_numero = p_numero;
    --
    v_inar integer;
    --
    cursor c_ge_tinarch is
    select count(*)
    from   ge_tinarch
    where  inar_infa   = p_infa
    and    inar_numero = p_numero;
    --
  begin
    --
    open  c_ge_tinad;
    fetch c_ge_tinad into v_inad_ult_accion;
    if ( c_ge_tinad%notfound ) then
         v_inad_ult_accion := null;
    end if;
    close c_ge_tinad;
    --
    if    ( v_inad_ult_accion is null ) then
            null;
    elsif ( v_inad_ult_accion in ('DT','CA','CF'/*1045 lmesa@cidenet.com.co*/,'VE', 'PE') ) then
            --
            v_inar := 0;
            --
            open  c_ge_tinarch;
            fetch c_ge_tinarch into v_inar;
            if ( c_ge_tinarch%notfound ) then
                 v_inar := 0;
            end if;
            close c_ge_tinarch;
            --
            if ( v_inar > 0 ) then
                 begin
                   --
                   delete ge_tinarch
                   where  inar_InFa   = p_infa
                   and    inar_numero = p_numero;
                   --
                 exception
                   when others then
                        raise_application_error( -20698, 'Error borrando GE_TINARCH. '||sqlerrm );
                 end;
            end if;
            --
            begin
              --
              delete ge_tinad
              where  inad_infa   = p_infa
              and    inad_numero = p_numero;
              --
            exception
              when others then
                   raise_application_error( -20699, 'Error borrando GE_TINAD. '||sqlerrm );
            end;
    end if;
    --
    commit;
    --
  end Borra_Archivo;
  ---------------------------------------------------------------------------------------------------------
  --                     Inician Programas para el Procesamiento de la Interfase                         --
  ---------------------------------------------------------------------------------------------------------
  --
  --
  Procedure Car_Con ( p_Infa             varchar2,
                      p_inrq             integer,
                      p_Periodo          integer,
                      p_Numero           varchar2,
                      p_Cias             integer,
                      p_Fecha            date,
                      p_Usua_Gene        varchar2,
                      p_Agr_CXP          varchar2,
                      p_py_EtPy          integer,
                      p_py_Proy          varchar2,
                      p_py_EnAp          integer   ) is
    --
    --  Modificaciones:
    --
    --  1. 24 octubre 2002 ( UCALDAS ).
    --     . Nueva variable V_ERROR y su utilizacion en el exception de cada
    --       sentencia de insercion a la tabla sc_tmvco.
    --
    --  2. Nohora Manosalva - Solicitud 5054
    --     . Modifico cursores teniendo en cuenta el parametro INFA_AGR_CXP.
    --
    --  3. Almoto - 14 abril 2004 - Solicitud 5054
    --     . Se arreglo declaracion de cursores modificados por Nohora, ya que no se contemplaba la
    --       posibilidad de que la Interfase estuviera parametrizada para que no generara Ordenes de Pago.
    --
    --  4. Almoto - 23 noviembre 2005 - Solicitud 5570
    --     . Se condiciona el procesamiento de la partida contable a que la columna INTM_MAYO_P no este nula.
    --
    v_cxp_auxi    ge_tintm.intm_cxp_auxi%type;
    v_Area        ge_tarea.area_area%type;
    v_CeCo        ge_tcecos.ceco_ceco%type;
    v_Pide_Area   Varchar2(1);
    v_Pide_CeCo   Varchar2(1);
    v_Nivel       ge_tcias.cias_nivel%type;
    v_tporan      sc_tmvco.mvco_tporan%type;
    v_descri      sc_tmvco.mvco_descri%type;
    v_tpmv        cp_ttpmv.tpmv_tpmv%type;
    v_tpmv_pas    cp_ttpmv.tpmv_tpmv%type;
    v_pasivo      cp_ttpmv.tpmv_pasivo%type;
    v_NroCom      sc_tctco.ctco_nrocom%type;
    v_FecMovG     sc_tctco.ctco_fecmovg%type;
    v_EtCt        SC_tMVCO.MVCO_ETCT%type;
    v_EtCF        ge_tcias.cias_ETCF%type;
    v_tpco        SC_tCTCO.CTCO_tpco%type;
    v_tpcoe       SC_tCTCO.CTCO_tpcoG%type;
    v_period      sc_tctco.ctco_fecmov%type;
    v_rengln      NUMBER;
    v_valor       sc_tmvco.mvco_mtoren%type;
    v_desc        sc_tmvco.mvco_mtoren%type;
    v_fecha       date;
    v_VigOrPa     number;  -- Cambio (1)
    v_OrPa        number;  -- Cambio (1)
    v_tpret       ge_tacre.acre_tpret%type;
    v_clase       ge_tacre.acre_clase%type;
    v_porc        ge_tacre.acre_porc%type;
    v_ciud        ge_tacre.acre_ciud%type;
    v_aica        ge_tacre.acre_aica%type;
    --
    v_Error       varchar2(500);              ------- Cambio(1)
    --
    v_Periodo_Proc integer;    -- Soli_5213
    --
    cursor c_tpco_cxp is
    select distinct
           intm_cxp_tpmv, intm_tpco,
           intm_tpcoe,    intm_fecha,
           intm_cxp_auxi,
           decode(p_Agr_CXP, 'S', 1, 'N', intm_OrPa) Orpa,  ---soli 5054
           intm_pref, intm_nrodoc                          -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
           /*intm_ciud,  intm_aica          -- 1012484.  ovcaceres.  02/03/2012  */
    from   ge_tintm
    where  intm_fecmov = p_Periodo
    and    intm_numero = p_Numero
    and    intm_cias   = p_cias
    and    intm_tpco     is not null
    and    intm_tpcoe    is not null
    and    intm_cxp_tpmv in ( select tpmv_tpmv
                                from cp_ttpmv
                               where tpmv_pasivo ='P');
    --
    cursor c_contab_cxp ( pc_pref   varchar2,  pc_nrodoc   varchar2 ) is           -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
    select intm_tporan,      intm_mayo_P, intm_auxi_P,    intm_fecha,      intm_mayo_C,
           intm_auxi_c,      intm_tpliq,  intm_cont_ceco, intm_descri,     intm_cont_area,
           intm_rete,        intm_acre,   intm_vigorpa,   intm_orpa,       intm_auxi_terc,
           intm_pref,        intm_nrodoc, intm_fecdoc,    sum(intm_valdoc) intm_valdoc,    -- COMO058
           sum(intm_vlrmone) intm_vlrmone,                                                 -- COMO058
           sum(intm_valor) intm_valor,
           sum(intm_inco_base_valor) intm_inco_base_valor,
           intm_ciud, intm_aica                                                                        -- 1012484 13/03/2012 ymoreno  14/03/2012 ovcaceres. se agrega ciudad
    from   ge_tintm
    where  intm_cxp_auxi = v_cxp_auxi
    and    intm_cxp_tpmv = v_tpmv    -- 13298 lhernandez
    and    intm_numero   = p_Numero
    and    intm_tpcoe    = v_tpcoe
    and    intm_fecmov   = p_Periodo
    and    intm_cias     = p_cias
    and    intm_tpco     = v_tpco
    and    nvl(intm_orpa, -1) = decode(p_Agr_CXP, 'S', nvl(intm_orpa, -1), 'N', nvl(v_Orpa, -1), -1)  --- Soli 5054  (y  Almoto - 14 abril 2004 )
    and    nvl(intm_pref, '&&' ) = nvl( pc_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
    and    nvl( intm_nrodoc, '&&' ) =  nvl( pc_nrodoc,  '&&' ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
    Group by  intm_tporan,    intm_mayo_P, intm_auxi_P,    intm_fecha,  intm_mayo_c,
              intm_auxi_c,    intm_tpliq,  intm_cont_ceco, intm_descri, intm_cont_area,
              intm_rete,      intm_acre,   intm_vigorpa,   intm_orpa,   intm_auxi_terc,
              intm_pref,      intm_nrodoc, intm_fecdoc ,                                     -- COMO058
              intm_ciud, intm_aica                                                                      -- 1012484 13/03/2012 ymoreno  14/03/2012 ovcaceres. se agrega ciudad
    Union
    Select intm_tporan,      intm_mayo_P, intm_auxi_P,    intm_fecha,       intm_mayo_c,
           intm_auxi_c,      intm_tpliq,  intm_cont_ceco, intm_descri,      intm_cont_area,
           intm_rete,        intm_acre,   intm_vigorpa,   intm_orpa,        intm_auxi_terc,
           intm_pref,        intm_nrodoc, intm_fecdoc,    sum(intm_valdoc)  intm_valdoc,    -- COMO058
           sum(intm_vlrmone) intm_vlrmone,                                                  -- COMO058
           Sum(intm_valor) intm_valor,
           Sum(intm_inco_base_valor) intm_inco_base_valor,
           intm_ciud, intm_aica                                                                        -- 1012484 13/03/2012 ymoreno    14/03/2012 ovcaceres. se agrega ciudad
    from   ge_tintm
    where  intm_fecmov   = p_Periodo
    and    intm_numero   = p_Numero
    and    intm_cias     = p_cias
    and    intm_cxp_auxi = v_cxp_auxi
    and    intm_tpcoe    = v_tpcoe
    and    intm_tpco     = v_tpco
    and    intm_tpliq    = 'N'
    and    nvl(intm_orpa, -1) = decode( p_Agr_CXP, 'S', nvl(intm_orpa, -1), 'N', nvl(v_Orpa, -1), -1 ) ---soli 5054  (y  Almoto - 14 abril 2004 )
    and    nvl(intm_pref, '&&' ) = nvl( pc_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
    and    nvl( intm_nrodoc, '&&' ) =  nvl( pc_nrodoc,  '&&' ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
    Group by intm_tporan,    intm_mayo_P, intm_auxi_P,    intm_fecha,  intm_mayo_c,
             intm_auxi_c,    intm_tpliq,  intm_cont_ceco, intm_descri, intm_cont_area,
             intm_rete,      intm_acre,   intm_vigorpa,   intm_orpa,   intm_auxi_terc,
             intm_pref,      intm_nrodoc, intm_fecdoc,                                       -- COMO058
             intm_ciud, intm_aica; 
    --    
    --
    Cursor c_tpco is
    select distinct intm_tpco, intm_tpcoe, intm_fecha, intm_pref, intm_nrodoc                          -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
    from   ge_tintm
    where  intm_fecmov = p_Periodo
    and    intm_numero = p_Numero
    and    intm_cias   = p_cias
    and    intm_tpco     is not null
    and    intm_tpcoe    is not null
    and    intm_tpliq    = 'I'
    and    intm_cxp_tpmv is null
    and    intm_te_tpmv  is null;
    --
    cursor c_contab ( pc_pref   varchar2,  pc_nrodoc   varchar2 ) is           -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
    select intm_tporan,     intm_mayo_P,             intm_auxi_P,
           intm_fecha,      intm_mayo_c,             intm_auxi_C,
           intm_tpliq,      intm_inco_base_valor,    intm_cont_trib,
           intm_cont_rete,  intm_cont_ceco,          intm_descri,
           intm_cont_area,  intm_rete,               intm_valor,
           intm_vlrmone,    intm_pref,               intm_nrodoc,                 -- COMO058
           intm_fecdoc,     intm_valdoc,             intm_ciud,       intm_aica   -- COMO058  1012484.  ovcaceres.  02/03/2012
    from   ge_tintm
    where  intm_tpco     = v_tpco
    and    intm_tpcoe    = v_tpcoe
    and    intm_fecmov   = p_Periodo
    and    intm_numero   = p_Numero
    and    intm_cias     = p_cias
    and    intm_tpliq      = 'I'
    and    intm_cxp_tpmv   is null
    and    intm_te_tpmv    is null
    --and    nvl(intm_orpa, -1) = decode( p_Agr_CXP, 'S', nvl(intm_orpa, -1), 'N', nvl(v_Orpa, -1), -1) ---soli 5054  (y  Almoto - 14 abril 2004 ) --1012993 15/03/2012 ymoreno
    and    nvl(intm_orpa, -1) = nvl(v_Orpa, -1)           --1012993 15/03/2012 ymoreno
    and    p_Agr_CXP     = 'N'                            --1012993 15/03/2012 ymoreno
    and    nvl(intm_pref, '&&' ) = nvl( pc_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
    and    nvl( intm_nrodoc, '&&' ) =  nvl( pc_nrodoc,  '&&' ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
    --      group by intm_tporan,    intm_mayo_P, intm_auxi_P,    intm_fecha,    intm_mayo_c,
    --               intm_auxi_c,    intm_tpliq,  intm_cont_trib, intm_cont_rete,
    --               intm_cont_ceco, intm_descri, intm_cont_area, intm_rete;
    --
    -- ini.1012993 15/03/2012 ymoreno
    union
    select intm_tporan,     intm_mayo_P,             intm_auxi_P,
           intm_fecha,      intm_mayo_c,             intm_auxi_C,
           intm_tpliq,      intm_inco_base_valor,    intm_cont_trib,
           intm_cont_rete,  intm_cont_ceco,          intm_descri,
           intm_cont_area,  intm_rete,               sum(intm_valor) intm_valor,
           intm_vlrmone,    intm_pref,               intm_nrodoc,            
           intm_fecdoc,     intm_valdoc,             intm_ciud,       intm_aica
    from   ge_tintm
    where  intm_tpco     = v_tpco
    and    intm_tpcoe    = v_tpcoe
    and    intm_fecmov   = p_Periodo
    and    intm_numero   = p_Numero
    and    intm_cias     = p_cias
    and    intm_tpliq      = 'I'
    and    intm_cxp_tpmv   is null
    and    intm_te_tpmv    is null
    and    p_Agr_CXP       =  'S'
    and    nvl(intm_orpa, -1) = nvl(intm_orpa, -1)
    and    nvl(intm_pref, '&&' ) = nvl( pc_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
    and    nvl( intm_nrodoc, '&&' ) =  nvl( pc_nrodoc,  '&&' ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
    group by intm_tporan,     intm_mayo_P,             intm_auxi_P,
           intm_fecha,      intm_mayo_c,             intm_auxi_C,
           intm_tpliq,      intm_inco_base_valor,    intm_cont_trib,
           intm_cont_rete,  intm_cont_ceco,          intm_descri,
           intm_cont_area,  intm_rete,               intm_vlrmone,
           intm_pref,       intm_nrodoc,             intm_fecdoc,      
           intm_valdoc,     intm_ciud,               intm_aica;
    -- fin.1012993 15/03/2012 ymoreno
    --
    -- Inicia COMO058
    cursor c_mayo (pc_etct    integer, pc_mayo    varchar2 ) is
      select mayo_reexp_mon, mayo_mone
        from ge_tmayor
       where mayo_etct = pc_etct
         and mayo_mayo = pc_mayo;
    --
    v_mone              pi_tmone.mone_mone%type;
    v_valor_orig        sc_tmvco.mvco_mtoren%type;
    v_reexp_mon         ge_tmayor. mayo_reexp_mon%type;
    v_mone_apl          number;
    -- Termina COMO058
    --
    v_valbruto      cp_torpa.orpa_valbruto%type;
    --
  BEGIN
    --
    -- Ini.Soli_5213
    --
    if ( p_Fecha is not null ) then
      v_Periodo_Proc := to_char(p_Fecha, 'yyyymm');
    else
      v_Periodo_Proc := null;
    end if;
    --
    -- Fin.Soli_5213
    --
    -- LLAMA PROCEDIMIENTO QUE CARGA TESORERIA, CUANDO NO MANEJA CXP PERO SI MANEJA TESOR.
    --
    Car_Con_Tes( p_Infa,    p_inrq, p_Periodo, p_Numero,  p_Cias, p_Fecha, p_Usua_Gene,
                 p_Agr_CXP, p_py_EtPy, p_py_Proy, p_py_EnAp );
    --
    Begin
      select tpmv_tpmv
      into   v_tpmv_pas
      from   cp_ttpmv
      where  tpmv_pasivo ='P'
      and rownum = 1;
    exception
      when no_data_found then
        raise_application_error( -20656, 'No Existe Tipo de Movimiento de CXP, que cause PASIVO.');
      when others then
        raise_application_error( -20657, 'CP_TTPMV : ' || sqlerrm );
    end;
    --
    for i in c_tpco_cxp loop
      --
      v_tpmv     := i.intm_cxp_tpmv;
      v_tpco     := i.intm_tpco;
      v_tpcoe    := i.intm_tpcoe;
      v_period   := nvl(v_Periodo_Proc,p_Periodo);
      v_cxp_auxi := i.intm_cxp_auxi;
      v_Orpa     := i.orpa;
      --
      --
      v_fecha   := nvl(p_Fecha, to_date(i.intm_fecha,'dd-mm-yyyy'));
      --  inicio vers.1009.gap.-.14029. ovcaceres.  09/05/2012
      if ( i.intm_pref||i.intm_nrodoc is not null ) then
        v_fecha   := to_date(i.intm_fecha,'dd-mm-yyyy');
      end if;
      --  fin vers.1009.gap.-.14029. ovcaceres.  09/05/2012
      --
      Trae_Dat_Cia(p_cias, p_inrq, v_Nivel, v_EtCt, v_EtCF);
      --
      Numerar_Comp(p_cias, v_TpCo, v_Period, v_NroCom, v_FecMovG);
      --
      --
      begin
        --
        Insert into sc_tctco
        (
          CTCO_CIAS,        CTCO_TPCO,     CTCO_NROCOM,
          CTCO_FECCOM,      CTCO_FECMOV,   CTCO_FECCRE,
          CTCO_USER,        CTCO_ULFMOD,   CTCO_NIVEL,
          CTCO_FECMOVG,     CTCO_TPCOG,    CTCO_NROCOMG,
          CTCO_PY_CIAS,     CTCO_PY_ETPY,  CTCO_PY_PROY,
          CTCO_PY_ENAP,
          CTCO_INAR_NUMERO, CTCO_NRODOC  -- SOLI 5584         -- vers.1005.gap.-.COMO033. ovcaceres.  04/05/2012
        )
        values
        (
         p_cias,       v_TpCo,     v_NroCom,
         v_fecha,      v_period,   sysdate,
         p_Usua_Gene,  sysdate,    v_Nivel,
         v_FecMovG,    v_tpcoe,    v_NroCom,
         p_cias,       p_py_etpy,  p_py_proy,
         p_py_enap,
         p_numero,     i.intm_pref||i.intm_nrodoc       -- Soli 5584     vers.1005.gap.-.COMO033. ovcaceres.  04/05/2012
        );
        --
      exception
        when others then
          raise_application_error( -20655, 'SC_TCTCO: TpCo=' || v_TpCo || ' NroCom='|| v_NroCom || ' : ' || sqlerrm );
      end;
      --
      -- COMMIT; -- antes de 13712
      --
      --
      Begin
        update cp_torpa
        set    orpa_nrocom = v_NroCom
        where  orpa_cias = p_cias
        and    orpa_auxi = v_cxp_auxi
        and    orpa_tpmv = v_tpmv
        and    orpa_orpa = decode(p_Agr_CXP,'S',orpa_orpa,'N',v_Orpa)
        and    orpa_user = p_Usua_Gene
        and nvl(orpa_inar_pref, '&&' ) = nvl( i.intm_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
        and nvl( orpa_inar_nrodoc, '&&' ) =  nvl( i.intm_nrodoc,  '&&' ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
        and nvl( orpa_inar_numero, '&&' ) =  nvl( p_Numero,  '&&' )      -- Vs.1034 Sol. 23612 22/04/2013   dcgarces
        ;
      End;
      --
      v_rengln := 0;
      --  inicio.  1012484.  26/03/2012.  
      select nvl(sum(intm_valor),0)
        into   v_valbruto
        from   ge_tintm
       where intm_fecmov   = p_Periodo
         and intm_numero   = p_Numero
         and intm_cias     = p_cias
         and intm_cxp_tpmv = v_tpmv
         and intm_tpliq    in ('B')
         and intm_cxp_auxi = v_cxp_auxi
         and intm_orpa     = decode(p_Agr_CXP,'S',intm_orpa,'N',v_Orpa)
         and nvl(intm_pref, '&&' ) = nvl( i.intm_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
         and nvl( intm_nrodoc, '&&' ) =  nvl( i.intm_nrodoc,  '&&' ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
         ;
         --and intm_tpco     = v_tpco;
      Sf_Pins_Error('Ge_Qinfa.TRIB.  Valor: '||v_valor||' VBruto: '||v_valbruto||' Auxi: '||v_cxp_auxi);
      --  fin.  1012484.  26/03/2012.  
      For j in c_contab_cxp ( i.intm_pref, i.intm_nrodoc ) loop        -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
        --
        Sf_Pins_Error('Ge_Qinfa.TRIB. Orpa: '||j.intm_orpa||' Valor: '||v_valor||' VBruto: '||v_valbruto||' Auxi: '||v_cxp_auxi||' Tpmv: '||v_tpmv);             --  vers.1021.gap.-.15330. ovcaceres.  28/06/2012
        v_valor      := j.intm_valor;
        v_valor_orig := j.intm_vlrmone;      -- COMO058
        --
        If ( j.intm_tporan = 'C' ) then
          v_valor      := v_valor*-1;
          v_valor_orig := v_valor_orig*-1;   -- COMO058
        else
          v_valor      := v_valor;
          v_valor_orig := v_valor_orig;      -- COMO058
        end if;
        --
        v_descri := nvl(j.intm_descri,'INTERFASE NUMERO :'||p_Numero);  --(4)
        --
        if ( j.intm_Mayo_P is not null ) then            -- Soli_5570 (Nueva condicion)
          --
          -- /** BUSCA SI PIDE AREA O CECO **/
          --
          Mayo_Pide_Area_CeCo(v_EtCt, j.intm_mayo_P, v_Pide_Area, v_Pide_CeCo);
          --
          --
          dbms_output.put_line('Mayo(1)='||j.intm_Mayo_P || ' EtCt='||v_EtCt || ' PideCeCo='||v_Pide_Ceco || ' intm_cont_ceco='||j.intm_cont_ceco);
          --
          If ( v_Pide_Area = 'S' ) then
            --
            v_area := j.intm_cont_area;
            --
          else
            --
            v_area := null;
            --
          End if;
          --
          If ( v_Pide_CeCo = 'S' ) then
            --
            v_ceco := j.intm_cont_ceco;
            --
          else
            --
            v_ceco := null;
            --
          End if;
          --
          dbms_output.put_line('Mayo(1)='||j.intm_Mayo_P || ' CeCo='||v_Ceco);
          --
          --
          If ( V_VALOR <> 0 ) THEN                                       /** CARGA MOV.DIF DE CERO **/
            --
            -- Inicia COMO058
            v_reexp_mon  := null;
            v_mone := null;
            --
            open c_mayo ( v_etct, j.intm_mayo_P );
               fetch c_mayo into v_reexp_mon, v_mone;
            close c_mayo;
            --
            if ( v_reexp_mon= 'S' ) then
               --
               if ( j.intm_vlrmone is null ) then
                 --
                 raise_application_error( -20629, 'SC_TMVCO: No Hay Valor Mon. Extranjera en Cuenta: '|| j.intm_mayo_P);
                 --
               end if;
               --
               if ( nvl( j.intm_vlrmone, 0 ) <> 0 ) then
                   v_mone_apl  := j.intm_valor / j.intm_vlrmone;
               else
                  v_mone_apl  := null;
               end if;
               --
            else
              --
              v_reexp_mon  := null;
              v_mone := null;
              --
            end if;
            -- Termina COMO058
             --
             Update sc_tmvco
                set mvco_mtoren      = mvco_mtoren + v_valor,
                    mvco_mtoren_orig = nvl(mvco_mtoren_orig,0) + v_valor_orig       -- COMO058
              where mvco_cias   = p_cias
                and mvco_tpco   = v_tpco
                and mvco_nrocom = v_NroCom
                and mvco_fecmov = v_period
                and mvco_auxi   = nvl(j.intm_auxi_P,1)
                and mvco_mayo||''  = j.intm_mayo_P
                and mvco_tporan = j.intm_tporan
                and nvl(mvco_ceco,'*')= nvl(v_ceco,'*')
                and nvl(mvco_area,'*')= nvl(v_area,'*');

             If (sql%RowCount = 0) then
                --
                v_fecha  := nvl(p_Fecha, to_date(j.intm_fecha,'dd-mm-yyyy'));
              --  inicio vers.1010.gap.-.14029. lhernandez.  09/05/2012
      				if ( i.intm_pref||i.intm_nrodoc is not null ) then
        			v_fecha   := to_date(i.intm_fecha,'dd-mm-yyyy');
      				end if;
      			--  fin vers.1010.gap.-.14029. lhernandez.  09/05/2012
                v_rengln := nvl(v_rengln,0) + 1;
                --
                begin
                  --
                  Insert into sc_tmvco
                  (
                   MVCO_CIAS,       MVCO_TPCO,      MVCO_NROCOM,
                   MVCO_FECMOV,     MVCO_RENGLN,    MVCO_MAYO,
                   MVCO_AUXI,       MVCO_DESCRI,    MVCO_FECDOC,
                   MVCO_MTOREN,     MVCO_TPORAN,    MVCO_ETCT,
                   MVCO_CECO,       MVCO_AREA,
                   mvco_mone,                                           -- COMO058
                   mvco_vmone,      mvco_vmone_apl, mvco_mtoren_orig    -- COMO058
                  )
                  values
                  (
                   p_cias,               v_tpco,        v_NroCom,
                   v_period,             v_rengln,      j.intm_mayo_P,
                   nvl(j.intm_auxi_P,1), v_DESCRI,      v_fecha,
                   v_valor,              j.intm_tporan, v_EtCt,
                   v_ceco,               v_area,
                   v_mone,                                             -- COMO058
                   null,                 v_mone_apl,    v_valor_orig   -- COMO058

                  );
                exception
                 when others then
                   raise_application_error( -20658, 'SC_TMVCO: ' || sqlerrm );
                end;
                --
                --
             End if;
             --
             -- REGISTRO TRIBUTARIO
             --
             v_ciud := j.intm_ciud;       -- 1012484.  ovcaceres.  02/03/2012
             --v_aica := i.intm_aica;       -- 1012484.  ovcaceres.  02/03/2012
             v_aica := j.intm_aica;       -- 1012484 13/03/2012   ymoreno
             --             
             if ( j.intm_acre = 'S' ) then
                --
                sf_pins_error('CAR_CON_TRB 1');
                CAR_CON_TRB ( p_cias,  v_tpco,         v_NroCom,    v_period, v_rengln, j.intm_auxi_terc, j.intm_rete,
                              v_valor, j.intm_vigorpa, j.intm_orpa, v_ciud,   v_aica,   v_fecha,          j.intm_tpliq,
                              v_EtCt, j.intm_inco_base_valor, v_valbruto    -- 1012484.  ovcaceres.  02/03/2012
                            );
                --
             end if;
             
             --
             --COMMIT; -- antes de 13712
             --
          END IF;
          --
          v_Pide_Area := null;
          v_Pide_CeCo := null;
          v_area       := null;
          v_ceco       := null;
          --
        end if;                  -- Soli_5570 (Termina de procesar cuando INTM_MAYO_P no es nula)
        --
        -- /** CARGA SI EXISTE CONTRAPARTIDA **/
        --
        If ( j.intm_mayo_c is not null ) then
           --
           v_valor      := j.intm_valor;
           v_valor_orig := j.intm_vlrmone;   -- COMO058
           --
           If ( j.intm_inco_base_valor is not null ) then
              v_valor := j.intm_inco_base_valor;
           end if;
           --
           If ( j.intm_tporan = 'C' ) then
              v_tporan     := 'D';
              v_valor      := v_valor;
              v_valor_orig := v_valor_orig;    -- COMO058
           else
             v_tporan      := 'C';
              v_valor      := v_valor*-1;
              v_valor_orig := v_valor_orig*-1; -- COMO058
           end if;
           --
           -- /** BUSCA SI PIDE AREA O CECO **/
           --
           Mayo_Pide_Area_CeCo(v_EtCt, j.intm_mayo_c, v_Pide_Area, v_Pide_CeCo);
           --
           --
           If ( v_Pide_Area = 'S' ) then
              --
              v_area := j.intm_cont_area;
              --
           else
              --
              v_area := null;
              --
           End if;
           --
           If ( v_Pide_CeCo = 'S' ) then
              --
              v_ceco := j.intm_cont_ceco;
              --
           else
              --
              v_ceco := null;
              --
           End if;
           --
           --
           v_descri := nvl(j.intm_descri,'INTERFASE NUMERO :'||p_Numero);  --(4)
           --
           --
           if ( V_VALOR <> 0 ) THEN                                       /** CARGA MOV.DIF DE CERO **/
              --
              -- Inicia COMO058
              v_reexp_mon  := null;
              v_mone := null;
              --
              open c_mayo ( v_etct, j.intm_mayo_C );
                 fetch c_mayo into v_reexp_mon, v_mone;
              close c_mayo;
              --
              if ( v_reexp_mon= 'S' ) then
                 --
                 if ( j.intm_vlrmone is null ) then
                   --
                   raise_application_error( -20630, 'SC_TMVCO: No Hay Valor Mon. Extranjera en Cuenta: '|| j.intm_mayo_C);
                   --
                 end if;
                 --
                 if ( nvl( j.intm_vlrmone, 0 ) <> 0 ) then
                     v_mone_apl  := j.intm_valor / j.intm_vlrmone;
                 else
                    v_mone_apl  := null;
                 end if;
                 --
              else
                --
                v_reexp_mon  := null;
                v_mone := null;
                --
              end if;
              -- Termina COMO058
              --
              Update sc_tmvco
                 set mvco_mtoren      = mvco_mtoren + v_valor,
                     mvco_mtoren_orig = nvl(mvco_mtoren_orig,0) + v_valor_orig     -- COMO058
               where mvco_cias   = p_cias
                 and mvco_tpco   = v_tpco
                 and mvco_nrocom = v_NroCom
                 and mvco_fecmov = v_period
                 and mvco_auxi   = nvl(j.intm_auxi_c,1)
                 and mvco_mayo||''   = j.intm_mayo_c
                 and mvco_tporan = v_tporan
                 and nvl(mvco_ceco,'*')= nvl(v_ceco,'*')
                 and nvl(mvco_area,'*')= nvl(v_area,'*');

              If ( sql%rowcount = 0 ) then
                --
                v_fecha  := nvl(p_Fecha, to_date(j.intm_fecha,'dd-mm-yyyy'));
                v_rengln := nvl(v_rengln,0) + 1;
                --
                begin
                  --
                  Insert into sc_tmvco
                  (
                     MVCO_CIAS,         MVCO_TPCO,      MVCO_NROCOM,
                     MVCO_FECMOV,       MVCO_RENGLN,    MVCO_MAYO,
                     MVCO_AUXI,         MVCO_DESCRI,    MVCO_FECDOC,
                     MVCO_MTOREN,       MVCO_TPORAN,    MVCO_ETCT,
                     MVCO_CECO,         MVCO_AREA,
                     mvco_mone,                                               -- COMO058
                     mvco_vmone,        mvco_vmone_apl, mvco_mtoren_orig      -- COMO058
                  )
                  values
                  (
                     p_cias,            V_tpco,        v_NroCom,
                     v_period,          v_rengln,      j.intm_mayo_c,
                     j.intm_auxi_c,     v_DESCRI,      v_fecha,
                     v_valor,           v_tporan,      v_EtCt,
                     v_ceco,            v_area,
                     v_mone,                                                  -- COMO058
                     null,              v_mone_apl,    v_valor_orig           -- COMO058
                  );
                  --
                  exception
                    when others then
                      raise_application_error( -20659, 'SC_TMVCO: ' || sqlerrm );
                end;
                --
                --
              End if;
              --
              -- COMMIT; -- antes de 13712
              --
           END IF;                                       /** CARGA MOV.DIF DE CERO **/
           --
        End if;
        --
        -- COMMIT; -- antes de 13712
        --
        v_Pide_Area := null;
        v_Pide_CeCo := null;
        v_area       := null;
        v_ceco       := null;
        --
      End Loop C_Contab_Cxp;
      --
      --
      Update ge_tintm
         set intm_tpco   = v_tpco,       -- (5)
             intm_nrocom = v_NroCom
       where intm_OrPa     = v_OrPa       -- Cambio (1)(3)
         and intm_VigOrPa  = v_VigOrPa    -- Cambio (1)(3)
         and intm_TpCoE    = v_tpcoe
         and intm_fecmov   = p_Periodo
         and intm_numero   = p_Numero
         and intm_cias     = p_cias
         and intm_cxp_tpmv = v_tpmv
         and intm_orpa     = decode(p_Agr_CXP,'S',intm_orpa,'N',v_Orpa) ---soli 5054
         and intm_tpco     = v_tpco
         and nvl(intm_pref, '&&' ) = nvl( i.intm_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
         and nvl( intm_nrodoc, '&&' ) =  nvl( i.intm_nrodoc,  '&&' ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
         ;
      --
      If ( sql%rowcount ) = 0 then
         --
         Update ge_tintm
            set intm_tpco   = v_tpco,       -- (5)
                intm_nrocom = v_NroCom
          where intm_OrPa     is null
            and intm_VigOrPa  is null
            and intm_tpcoe    = v_tpcoe
            and intm_fecmov   = p_Periodo
            and intm_numero   = p_Numero
            and intm_cias     = p_cias
            and intm_tpliq    = 'I'
            and intm_orpa     = decode(p_Agr_CXP, 'S', intm_orpa, 'N', v_Orpa) ---soli 5054
            and intm_tpco     = v_tpco
            and nvl(intm_pref, '&&' ) = nvl( i.intm_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
            and nvl( intm_nrodoc, '&&' ) =  nvl( i.intm_nrodoc,  '&&' ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
            ;
         --
      end if;
      --
      v_Error := ge_qinfa.val_cuadre_comp(p_cias, v_tpco, v_NroCom, p_Periodo, 'C_Contab_CXP', p_Infa, p_Numero, p_Usua_Gene);

      if v_Error <> 'OK' then -- 109973 japoveda
      	raise_application_error( -20655, 'Valida Comprbante: ' || v_Error );
      end if;
      --
      --
      -- COMMIT; -- antes de 13712
      --
    End loop;
    --
    --
    --
    For k in c_tpco loop
      --
      v_tpco     := k.intm_tpco;
      v_tpcoe    := k.intm_tpcoe;
      v_period   := nvl(v_Periodo_Proc, p_Periodo);
      --
      v_fecha    := nvl(p_Fecha, to_date(k.intm_fecha,'dd-mm-yyyy'));
      --  inicio vers.1011.gap.-.14029. lhernandez.  09/05/2012
      				if ( k.intm_pref||k.intm_nrodoc is not null ) then
        			v_fecha   := to_date(k.intm_fecha,'dd-mm-yyyy');
      				end if;
      --  fin vers.1011.gap.-.14029. lhernandez.  09/05/2012
      --
      --
      Trae_Dat_Cia(p_cias, p_inrq, v_Nivel, v_EtCt, v_EtCF);
      --
      NUMERAR_COMP(p_cias, v_TpCo, v_Period, v_NroCom, v_FecMovG);
      --
      begin
        --
        insert into sc_tctco-- car_con
        (
           CTCO_CIAS,       CTCO_TPCO,       CTCO_NROCOM,
           CTCO_FECCOM,     CTCO_FECMOV,     CTCO_FECCRE,
           CTCO_USER,       CTCO_ULFMOD,     CTCO_NIVEL,
           CTCO_FECMOVG,    CTCO_TPCOG,      CTCO_NROCOMG,
           CTCO_PY_CIAS,    CTCO_PY_ETPY,    CTCO_PY_PROY,
           CTCO_PY_ENAP,
           CTCO_INAR_NUMERO, CTCO_NRODOC  -- SOLI 5584       -- vers.1015.gap.-.14471. ovcaceres.  23/05/2012
        )
        values
        (
           p_cias,          v_TpCo,          v_NroCom,
           v_fecha,         v_period,        sysdate,
           p_Usua_Gene,     sysdate,         v_Nivel,
           v_FecMovG,       v_TpCoe,         v_NroCom,
           p_cias,          p_py_etpy,       p_py_proy,
           p_py_enap,
           p_numero,        k.intm_pref||k.intm_nrodoc   -- Soli 5584   -- vers.1015.gap.-.14471. ovcaceres.  23/05/2012
        );
        --
        exception
          when others then
            raise_application_error( -20660, 'SC_TCTCO: TpCo=' || v_TpCo || ' NroCom='|| v_NroCom || ' : ' || sqlerrm );
      end;
      -- Inicio Antes de 1036 lhernandez
      -- Inicio 1032 lhernandez
      /*Begin
        update cp_torpa
        set    orpa_nrocom = v_NroCom
        where  orpa_cias = p_cias
        and orpa_inar_numero = p_numero
        and    orpa_user = p_Usua_Gene
        and nvl(orpa_inar_pref, '&&' ) = nvl( k.intm_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
        and nvl( orpa_inar_nrodoc, '&&' ) =  nvl( k.intm_nrodoc,  '&&' ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
        ;
      End;*/
      -- Fin 1032 lhernandez
      -- Fin Antes de 1036 lhernandez
      --
      -- COMMIT; -- antes de 13712
      --
      --
      v_rengln := 0;
      --
      for l in c_contab ( k.intm_pref, k.intm_nrodoc ) loop        -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
        --
        v_valbruto := null;          --    1012484.  ovcaceres.  26/03/2012.  
        --
        v_valor      := l.intm_valor;
        v_valor_orig := l.intm_vlrmone;     -- COMO058
        --
        If l.intm_tporan = 'C' then
          v_valor      := v_valor*-1;
          v_valor_orig := v_valor_orig*-1;  -- COMO058
        else
          v_valor      := v_valor;
          v_valor_orig := v_valor_orig;     -- COMO058
        end if;
        --
        --
        v_descri := nvl(l.intm_descri,'INTERFASE NUMERO :'||p_Numero);
        --
        --
        --
        if ( l.intm_Mayo_P is not null ) then            -- Soli_5570 (Nueva condicion)
          --
          -- /** BUSCA SI PIDE AREA O CECO **/
          --
          Mayo_Pide_Area_CeCo(v_EtCt, l.intm_mayo_P, v_Pide_Area, v_Pide_CeCo);
          --
          --
          If ( v_Pide_Area = 'S' ) then
            --
            v_area := l.intm_cont_area;
            --
          else
            --
            v_area := null;
            --
          end if;
          --
          If ( v_Pide_CeCo = 'S' ) then
            --
            v_ceco := l.intm_cont_ceco;
            --
          else
            --
            v_ceco := null;
            --
          end if;
          --
          --
          if ( v_valor <> 0 ) then
            --                                        /** CARGA MOV.DIF DE CERO **/
            -- Soli 5584a update sc_tmvco
            -- Soli 5584a    set mvco_mtoren = mvco_mtoren + v_valor
            -- Soli 5584a  where mvco_cias   = p_cias
            -- Soli 5584a    and mvco_tpco   = v_tpco
            -- Soli 5584a    and mvco_nrocom = v_NroCom
            -- Soli 5584a    and mvco_fecmov = v_period
            -- Soli 5584a    and mvco_auxi   = nvl(l.intm_auxi_P, 1)
            -- Soli 5584a    and mvco_mayo||''  = l.intm_mayo_P
            -- Soli 5584a    and mvco_tporan = l.intm_tporan
            -- Soli 5584a    and nvl(mvco_ceco,'*')= nvl(v_ceco,'*')
            -- Soli 5584a    and nvl(mvco_area,'*')= nvl(v_area,'*');
            --
            -- Soli 5584a if ( sql%rowcount = 0 ) then
              --
              -- Inicia COMO058
              v_reexp_mon  := null;
              v_mone := null;
              --
              open c_mayo ( v_etct, l.intm_mayo_P );
                 fetch c_mayo into v_reexp_mon, v_mone;
              close c_mayo;
              --
              if ( v_reexp_mon= 'S' ) then
                 --
                 if ( l.intm_vlrmone is null ) then
                   --
                   raise_application_error( -20629, 'SC_TMVCO: No Hay Valor Mon. Extranjera en Cuenta: '|| l.intm_mayo_P);
                   --
                 end if;
                 --
                 if ( nvl( l.intm_vlrmone, 0 ) <> 0 ) then
                     v_mone_apl  := l.intm_valor / l.intm_vlrmone;
                 else
                    v_mone_apl  := null;
                 end if;
                 --
              else
                --
                v_reexp_mon  := null;
                v_mone := null;
                --
              end if;
              -- Termina COMO058
              --
              v_fecha  := nvl(p_Fecha, to_date(l.intm_fecha, 'dd-mm-yyyy'));
              v_rengln := nvl(v_rengln, 0) + 1;
              --
              --  inicio vers.1020 15299. dcgarces.  21/06/2012
      				if ( l.intm_pref||l.intm_nrodoc is not null ) then
        			v_fecha   := to_date(l.intm_fecha,'dd-mm-yyyy');
      				end if;
              --  termina vers.1020 15299. dcgarces.  21/06/2012
              
              begin
                --
                insert into sc_tmvco
                (
                    MVCO_CIAS,       MVCO_TPCO,      MVCO_NROCOM,
                    MVCO_FECMOV,     MVCO_RENGLN,    MVCO_MAYO,
                    MVCO_AUXI,       MVCO_DESCRI,    MVCO_FECDOC,
                    MVCO_MTOREN,     MVCO_TPORAN,    MVCO_ETCT,
                    MVCO_CECO,       MVCO_AREA,
                    mvco_mone,                                          -- COMO058
                    mvco_vmone,      mvco_vmone_apl, mvco_mtoren_orig   -- COMO058
                )
                values
                (
                    p_cias,               v_tpco,        v_NroCom,
                    v_period,             v_rengln,      l.intm_mayo_P,
                    nvl(l.intm_auxi_P,1), v_DESCRI,      v_fecha,
                    v_valor,              l.intm_tporan, v_EtCt,
                    v_ceco,               v_area,
                    v_mone,                                               -- COMO058
                    null,                 v_mone_apl,    v_valor_orig     -- COMO058
                );
                --
                exception
                  when others then
                    raise_application_error( -20661, 'SC_TMVCO: ' || sqlerrm );
              end;
              --
            -- Soli 5584a end if;
            --
            -- REGISTRO TRIBUTARIO
            --
            if ( l.intm_cont_trib = 'S' ) then
              --
              sf_pins_error('CAR_CON_TRB 2:');
              CAR_CON_TRB ( p_cias,  v_tpco, v_NroCom, v_NroCom, v_rengln, l.intm_auxi_P, l.intm_cont_rete,
                            v_valor, null,   null,     l.intm_ciud,   l.intm_aica,     v_fecha,   l.intm_tpliq,                -- 1012484.  ovcaceres.  02/03/2012
                            v_EtCt,   l.intm_inco_base_valor, v_valbruto               -- 1012484.  ovcaceres.  02/03/2012
                          );
              --
            end if;
            --
            -- COMMIT; -- antes de 13712
            --
          end if;
          --
        end if;     -- Soli_5570 (Termina de procesar cuando INTM_MAYO_P es no nula)
        --
        --
        v_Pide_Area := null;
        v_Pide_CeCo := null;
        v_area       := null;
        v_ceco       := null;
        --
        If ( l.intm_mayo_c is not null ) then
          --
          -- /** CARGA SI EXISTE CONTRAPARTIDA **/
          --
          --
          v_valor      := l.intm_valor;
          v_valor_orig := l.intm_vlrmone;   -- COMO058
          --
          If ( l.intm_inco_base_valor is not null ) then
            v_valor := l.intm_inco_base_valor;
          end if;
          --
          If l.intm_tporan = 'C' then
            v_tporan     := 'D';
            v_valor      := v_valor;
            v_valor_orig := v_valor_orig;  -- COMO058
          else
            v_tporan     := 'C';
            v_valor      := v_valor*-1;
            v_valor_orig := v_valor_orig*-1;  -- COMO058
          end if;
          --
          -- /** BUSCA SI PIDE AREA O CECO **/
          --
          Mayo_Pide_Area_CeCo(v_EtCt, l.intm_mayo_c, v_Pide_Area, v_Pide_CeCo);
          --
          --
          If v_Pide_Area = 'S' then
            --
            v_area := l.intm_cont_area;
            --
          else
            --
            v_area := null;
            --
          End if;
          --
          If v_Pide_CeCo = 'S' then
            --
            v_ceco := l.intm_cont_ceco;
            --
          else
            --
            v_ceco := null;
            --
          end if;
          --
          --
          v_descri := nvl(l.intm_descri,'INTERFASE NUMERO :'||p_Numero);  --(4)
          --
          --
          IF V_VALOR <> 0 THEN                                       /** CARGA MOV.DIF DE CERO **/
            --
            -- Soli 5584a Update sc_tmvco
            -- Soli 5584a    set mvco_mtoren = mvco_mtoren + v_valor
            -- Soli 5584a  where mvco_cias   = p_cias
            -- Soli 5584a    and mvco_tpco   = v_tpco
            -- Soli 5584a    and mvco_nrocom = v_NroCom
            -- Soli 5584a    and mvco_fecmov = v_period
            -- Soli 5584a    and mvco_auxi   = nvl(l.intm_auxi_c,1)
            -- Soli 5584a    and mvco_mayo||''   = l.intm_mayo_c
            -- Soli 5584a    and mvco_tporan = v_tporan
            -- Soli 5584a    and nvl(mvco_ceco,'*')= nvl(v_ceco,'*')
            -- Soli 5584a    and nvl(mvco_area,'*')= nvl(v_area,'*');
            -- Soli 5584a --
            -- Soli 5584a if (sql%RowCount = 0) then
              --
              v_fecha  := nvl(p_Fecha, to_date(l.intm_fecha,'dd-mm-yyyy'));
              v_rengln := nvl(v_rengln, 0) + 1;
              --
              -- Inicia COMO058
              v_reexp_mon  := null;
              v_mone := null;
              --
              open c_mayo ( v_etct, l.intm_mayo_C );
                 fetch c_mayo into v_reexp_mon, v_mone;
              close c_mayo;
              --
              if ( v_reexp_mon= 'S' ) then
                 --
                 if ( l.intm_vlrmone is null ) then
                   --
                   raise_application_error( -20632, 'SC_TMVCO: No Hay Valor Mon. Extranjera en Cuenta: '|| l.intm_mayo_C);
                   --
                 end if;
                 --
                 if ( nvl( l.intm_vlrmone, 0 ) <> 0 ) then
                     v_mone_apl  := l.intm_valor / l.intm_vlrmone;
                 else
                    v_mone_apl  := null;
                 end if;
                 --
              else
                --
                v_reexp_mon  := null;
                v_mone := null;
                --
              end if;
              -- Termina COMO058
              --
              begin
                --
                Insert into sc_tmvco
                (
                   MVCO_CIAS,       MVCO_TPCO,      MVCO_NROCOM,
                   MVCO_FECMOV,     MVCO_RENGLN,    MVCO_MAYO,
                   MVCO_AUXI,       MVCO_DESCRI,    MVCO_FECDOC,
                   MVCO_MTOREN,     MVCO_TPORAN,    MVCO_ETCT,
                   MVCO_CECO,       MVCO_AREA,
                   mvco_mone,                                            -- COMO058
                   mvco_vmone,      mvco_vmone_apl, mvco_mtoren_orig     -- COMO058
                )
                values
                (
                   p_cias,           v_tpco,          v_NroCom,
                   v_period,         v_rengln,        l.intm_mayo_c,
                   l.intm_auxi_c,    v_DESCRI,        v_fecha,
                   v_valor,          v_tporan,        v_EtCt,
                   v_ceco,           v_area,
                   v_mone,                                                -- COMO058
                   null,             v_mone_apl,      v_valor_orig        -- COMO058
                );
              exception
                when others then
                  raise_application_error( -20662, 'SC_TMVCO: ' || sqlerrm );
              end;
              --
              --
            -- Soli 5584a end if;
            --
            -- COMMIT; -- antes de 13712
            --
          end if;                                       /** CARGA MOV.DIF DE CERO **/
          --
        end if;
        --
        -- COMMIT; -- antes de 13712
        --
        v_Pide_Area := null;
        v_Pide_CeCo := null;
        v_area      := null;
        v_ceco      := null;
        --
      end loop;
      --
      Update ge_tintm
         set intm_tpco   = v_tpco,       -- (5)
             intm_nrocom = v_NroCom
       where intm_OrPa     is null
         and intm_VigOrPa  is null
         and intm_tpcoe    = v_tpcoe
         and intm_fecmov   = p_Periodo
         and intm_numero   = p_Numero
         and intm_cias     = p_cias
         and intm_tpliq    = 'I'
         and intm_orpa     = decode(p_Agr_CXP, 'S', intm_orpa, 'N', v_Orpa) ---soli 5054
         and intm_tpco     = v_tpco
         and nvl(intm_pref, '&&' ) = nvl( k.intm_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
         and nvl( intm_nrodoc, '&&' ) =  nvl( k.intm_nrodoc,  '&&' ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
         ;
      --
      -- COMMIT;    -- 1012954.  ovcaceres.  16/03/2012
      --
      v_Error := ge_qinfa.val_cuadre_comp(p_cias, v_tpco, v_nrocom, p_Periodo, 'C_Contab', p_Infa, p_Numero, p_Usua_Gene);

      if v_Error <> 'OK' then -- 109973 japoveda
      	raise_application_error( -20655, 'Valida Comprbante: ' || v_Error );
      end if;
      --
    end loop;
    --
  End Car_Con;
  -------------------------------------------------------------------------------------------------------------
  -------------------------------------------------------------------------------------------------------------
  procedure CAR_CON_TES ( p_Infa             varchar2,
                          p_inrq             integer,
                          p_Periodo          integer,
                          p_Numero           varchar2,
                          p_Cias             integer,
                          p_Fecha            date,
                          p_Usua_Gene        varchar2,
                          p_Agr_CXP          varchar2,
                          p_py_EtPy          integer,
                          p_py_Proy          varchar2,
                          p_py_EnAp          integer   ) is
    --
    -- Modificaciones:
    -- 1. Almoto - 18 junio 2003 ( ITC ) - Solicitud 1611
    --    . Al validar cuentas bancarias se tiene en cuenta que esten A-ACTIVAS
    --
    -- 2. Almoto - 23 noviembre 2005 - Solicitud 5570
    --    . Se condiciona el procesamiento de la partida contable a que la columna
    --      INTM_MAYO_P no este nula.
    --
    -- 3. EJ2H- 21-DEC-2005 - Solicitud 5584
    --    . Se ajusta para que a lprocesar la interfase no agrupe los registros enviados,
    --      a ser insertados en el mvto de tesoreria.
    --    . La generacion de los comprobantes de contabilidad son generados a los valores definidos en
    --      INTM_TE_TPCO y INTM_TE_TPCOE
    --
    v_tpco        ge_ttpco.tpco_tpco%type;
    v_tpcoe       ge_ttpco.tpco_tpco%type;
    v_nivel       ge_vcias.cias_nivel%type;
    v_etct        ge_vcias.cias_etct%type;
    v_etco        ge_vcias.cias_etco%type;
    v_etar        ge_vcias.cias_etar%type;
    v_etcf        ge_vcias.cias_etcf%type;
    v_etoe        ge_vcias.cias_etoe%type;
    v_feccom      sc_tctco.ctco_feccom%type;
    v_fecmov      sc_tctco.ctco_fecmov%type;
    v_nrocom      sc_tctco.ctco_nrocom%type;
    v_fecmovg     sc_tctco.ctco_fecmov%type;
    v_descri      sc_tmvco.mvco_descri%type;
    v_pide_area   varchar2(1);
    v_pide_ceco   varchar2(1);
    v_area        ge_tarea.area_area%type;
    v_ceco        ge_tcecos.ceco_ceco%type;
    v_valor       sc_tmvco.mvco_mtoren%type;
    v_reng_ints   sc_tmvco.mvco_rengln%type;
    v_reng_tes    sc_tmvco.mvco_rengln%type;
    v_cont_mayo   ge_tmayor.mayo_mayo%type;
    v_cont_auxi   ge_tauxil.auxi_auxi%type;
    v_tporan      te_ttpmv.tpmv_tporan%type;
    v_cont_tporan sc_tmvco.mvco_tporan%type;
    v_cont_valor  sc_tmvco.mvco_mtoren%type;
    v_rengln      sc_tmvco.mvco_rengln%type;
    v_Error       varchar2(4000); -- 109973 japoveda
    --
	--Ini soli_1044 pmp
    v_benefi      ge_tauxil.auxi_auxi%type;
    --
	--Fin soli_1044 pmp
	--
    cursor c_cab is
    select distinct intm_te_tpco, intm_te_tpcoe, intm_fecha,     
    intm_pref, intm_nrodoc --1011
    from   ge_tintm
    where  intm_fecmov     =  p_Periodo
    and    intm_numero     =  p_numero
    and    intm_cias       =  p_cias
    and    intm_tpco       is not null
    and    intm_tpcoe      is not null
    and    intm_tpliq      =  'I'
    and    intm_cxp_tpmv   is null
    and    intm_te_tpmv    is not null;
    --
    cursor c_det is
    select intm_te_tpmv,     intm_ncuenta,    intm_cheque,
           intm_te_etcf,     intm_te_fluj,    intm_te_etoe,
           intm_te_oecj,
           intm_tporan,      intm_mayo_P,     intm_auxi_P,
           intm_mayo_c,      intm_auxi_c,     intm_cont_ceco,
           intm_descri,
           intm_cont_area,
           intm_cont_trib,   intm_cont_rete,  intm_valor,
           intm_fmpg, --COMO058
           intm_vlrmone,     intm_pref,       intm_nrodoc,     -- COMO058
           intm_fecdoc,      intm_valdoc                       -- COMO058
		  ,intm_cuenta_destino                                 --soli_1044 pmp
		  ,intm_banc_destino                                   --soli_1044 pmp
    from ge_tintm
    where intm_te_tpco  =  v_tpco
    and   intm_te_tpcoe =  v_tpcoe
    and   intm_fecmov      =  p_Periodo
    and   intm_numero      =  p_numero
    and   intm_cias        =  p_cias
    and   intm_tpliq       =  'I'
    and   intm_cxp_tpmv    is null
    and   intm_te_tpmv     is not null
    and   intm_ncuenta     is not null;
    --
    cursor c_temp is
    select ints_cias,        ints_tpco,          ints_nrocom,       ints_fecmov,
           ints_mayo,        ints_enti,          ints_tpmv,         ints_cheque,
           ints_benefi,      ints_tporan,        ints_fecent,
           ints_fecpago,     ints_etcf,          ints_fluj,         ints_etoe,
           ints_oecj,        ints_feccre,        ints_fecmod,       ints_user,
           ints_descri,      ints_fecdoc,        ints_status,
           ints_valor,
           ints_fmpg, --COMO058
           ints_vlrmone,     ints_pref,          ints_nrodoc,       ints_fac_fecdoc,   -- COMO058
           ints_valdoc                                                                 -- COMO058
		  ,ints_cuenta_destino                                                         --soli_1044 pmp
		  ,ints_banc_destino                                                           --soli_1044 pmp
      from ge_tints
     where ints_infa   = p_infa
       and ints_numero = p_numero
       and ints_cias   = p_cias
       and ints_tpco   = v_tpco
       and ints_nrocom = v_nrocom
       and ints_fecmov = v_fecmov;
    --
    -- Calcula el renglon siguiente de la tabla GE_TINTS
    --
    cursor c_ge_tints is                          -- Soli 5584
    select nvl(max(ints_rengln),0)+1              -- Soli 5584
    from   ge_tints                               -- Soli 5584
    where  ints_numero = p_numero   -- Soli 5584
    and    ints_infa = p_infa;                    -- Soli 5584
    --
    -- Inicia COMO058
    --
    cursor c_mayo (pc_etct    integer, pc_mayo    varchar2 ) is
        select mayo_reexp_mon, mayo_mone
          from ge_tmayor
         where mayo_etct = pc_etct
           and mayo_mayo = pc_mayo;
    --
    cursor c_enti (pc_enti    integer) is
        select enti_mone
          from ge_tenti
         where enti_auxi = pc_enti;
    --
    v_mone               pi_tmone.mone_mone%type;
    v_valor_orig         sc_tmvco.mvco_mtoren%type;
    v_reexp_mon          ge_tmayor. mayo_reexp_mon%type;
    v_mone_apl           number;
    -- Termina COMO058
  BEGIN
    --
    Trae_Dat_Cia ( p_cias, p_inrq, v_nivel, v_etct, v_etcf );
    --
    for i in c_cab loop
      --
      -- Soli 5548 v_tpco   := i.intm_tpco;
      -- Soli 5548 v_tpcoe  := i.intm_tpcoe;
      v_tpco   := i.intm_te_tpco;       -- Soli 5584
      v_tpcoe  := i.intm_te_tpcoe;      -- Soli 5584
      v_feccom := nvl(p_Fecha, to_date(i.intm_fecha,'dd-mm-yyyy'));
      --  inicio vers.1011.gap.-.14029. lhernandez.  09/05/2012
      				if ( i.intm_pref||i.intm_nrodoc is not null ) then
        			v_feccom   := to_date(i.intm_fecha,'dd-mm-yyyy');
      				end if;
      --  fin vers.1011.gap.-.14029. lhernandez.  09/05/2012
      v_fecmov := nvl(to_char(p_Fecha, 'YYYYMM'), p_Periodo);
      --
      NUMERAR_COMP ( p_cias, v_tpco, v_fecmov, v_nrocom, v_fecmovg );
      --
      --
      begin
        insert into sc_tctco -- no
        (
            CTCO_CIAS,        CTCO_TPCO,      CTCO_NROCOM,
            CTCO_FECCOM,      CTCO_FECMOV,    CTCO_FECCRE,
            CTCO_USER,        CTCO_ULFMOD,    CTCO_NIVEL,
            CTCO_FECMOVG,     CTCO_TPCOG,     CTCO_NROCOMG,
            CTCO_PY_CIAS,     CTCO_PY_ETPY,   CTCO_PY_PROY,
            CTCO_PY_ENAP,
            CTCO_INAR_NUMERO -- SOLI 5584
        )
        values
        (
            p_cias,           i.intm_te_tpco,    v_nrocom,
            v_feccom,         v_fecmov,       sysdate,
            p_Usua_Gene,      sysdate,        v_nivel,
            v_fecmovg,        v_tpcoe,        v_nrocom,
            p_cias,           p_py_etpy,      p_py_proy,
            p_py_enap,
            p_numero    -- Soli 5584
        );
      exception
        when others then
          raise_application_error( -20647, 'SC_TCTCO: TpCo=' || i.INTM_TE_TPCO || ' NroCom='||v_NroCom || ' : ' || sqlerrm );
      end;
      --
      -- COMMIT; -- antes de 13712
      --
      for j in c_det loop
        --
        --
        v_descri := nvl(j.intm_descri,'INTERFASE NUMERO :'||p_Numero);
        --
        --
        if ( j.intm_Mayo_P is not null ) then           -- Soli_5570 (Nueva condicion)
          --
          -- PARTIDA
          --
          -- BUSCA SI PIDE AREA O CECO.
          --
          MAYO_PIDE_AREA_CECO ( v_etct, j.intm_mayo_P, v_pide_area, v_pide_ceco );
          --
          if ( v_pide_area = 'S' ) then
            v_area := j.intm_cont_area;
          else
            v_area := null;
          end if;
          --
          if ( v_pide_ceco = 'S' ) then
            v_ceco := j.intm_cont_ceco;
          else
            v_ceco := null;
          end if;
          --
          if ( j.intm_tporan = 'C' ) then
           v_valor      := abs(j.intm_valor)*(-1);
           v_valor_orig := abs(j.intm_vlrmone)*(-1);      -- COMO058
          else
           v_valor  := abs(j.intm_valor);
           v_valor_orig := abs(j.intm_vlrmone);           -- COMO058
          end if;
          --
          if ( v_valor <> 0 ) then
            --
            -- Soli 55844  update sc_tmvco
            -- Soli 55844  set    mvco_mtoren    = mvco_mtoren + v_valor
            -- Soli 55844  where  mvco_cias      = p_cias
            -- Soli 55844  and    mvco_tpco      = v_tpco
            -- Soli 55844  and    mvco_nrocom    = v_nrocom
            -- Soli 55844  and    mvco_fecmov    = v_fecmov
            -- Soli 55844  and    mvco_auxi      = nvl(j.intm_auxi_P,1)
            -- Soli 55844  and    mvco_mayo||''  = j.intm_mayo_P
            -- Soli 55844  and    mvco_tporan    = j.intm_tporan
            -- Soli 55844  and    nvl(mvco_ceco,'*')= nvl(v_ceco,'*')
            -- Soli 55844  and    nvl(mvco_area,'*')= nvl(v_area,'*');
            --
            --if ( sql%rowcount = 0 ) then
              --
              -- Inicia COMO058
              v_reexp_mon  := null;
              v_mone := null;
              --
              open c_mayo ( v_etct, j.intm_mayo_P );
                 fetch c_mayo into v_reexp_mon, v_mone;
              close c_mayo;
              --
              if ( v_reexp_mon= 'S' ) then
                 --
                 if ( j.intm_vlrmone is null ) then
                   --
                   raise_application_error( -20678, 'SC_TMVCO: No Hay Valor Mon. Extranjera en Cuenta: '|| j.intm_mayo_P);
                   --
                 end if;
                 --
                 if ( nvl( j.intm_vlrmone, 0 ) <> 0 ) then
                     v_mone_apl  := j.intm_valor  / j.intm_vlrmone;
                 else
                    v_mone_apl  := null;
                 end if;
                 --
              else
                --
                v_reexp_mon  := null;
                v_mone := null;
                --
              end if;
              -- Termina COMO058
              --
              v_rengln := nvl(v_rengln,0) + 1;
              --
              begin
                insert into sc_tmvco
                (
                    mvco_cias,          mvco_tpco,        mvco_nrocom,
                    mvco_fecmov,        mvco_rengln,      mvco_mayo,
                    mvco_auxi,          mvco_descri,      mvco_fecdoc,
                    mvco_mtoren,        mvco_tporan,      mvco_etct,
                    mvco_ceco,          mvco_area,
                    mvco_mone,          mvco_vmone,       mvco_vmone_apl,    -- COMO058
                    mvco_mtoren_orig                                         -- COMO058
                )
                values
                (
                    p_cias,               v_tpco,           v_nrocom,
                    v_fecmov,             v_rengln,         j.intm_mayo_P,
                    nvl(j.intm_auxi_P,1), v_descri,         v_feccom,
                    v_valor,              j.intm_tporan,    v_etct,
                    v_ceco,               v_area,
                    v_mone,               null,             v_mone_apl,      -- COMO058
                    v_valor_orig                                             -- COMO058
                );
              exception
                 when others then
                      raise_application_error( -20648, 'SC_TMVCO: ' || sqlerrm );
              end;
              --
            --end if;
            --
            -- REGISTRO TRIBUTARIO
            --
            if ( j.intm_cont_trib = 'S' ) then
              --
              sf_pins_error('CAR_CON_TRB 3:');
              CAR_CON_TRB ( p_cias, v_tpco, v_nrocom, v_fecmov, v_rengln, j.intm_auxi_P, j.intm_cont_rete, v_valor,
                            null,   null,   null,     null,     v_feccom, null,          v_etct );
              --
            end if;
            --
          end if;
          --
        end if;        -- Soli_5570 (Termina de procesar cuando INTM_MAYO_P es no nula)
        --
        -- CONTRAPARTIDA.
        --
        begin
          select enti_mayo, enti_auxi
            into v_cont_mayo, v_cont_auxi
            from ge_tenti, ge_tauxil
           where enti_cias = p_cias
             and enti_auxi = auxi_auxi
             and nvl(enti_Status, 'A') = 'A'  --- Soli_1611
             and auxi_nit  = j.intm_ncuenta;
        exception
         when others then
           raise_application_error( -20649, 'Cuenta Bancaria: ' || sqlerrm );
        end;
        --
        Begin
           select tpmv_tporan
           into   v_tporan
           from   te_ttpmv
           where  tpmv_tpmv = j.intm_te_tpmv;
        exception
          when no_data_found then
            raise_application_error( -20650, 'Tipo de Movimiento de Tesoreria NO EXISTE: ' || j.intm_te_TpMv );
          when others then
            raise_application_error( -20651, 'TE_TTPMV: ' || sqlerrm );
        end;
        --
        if ( v_tporan = 'E' ) then
          v_cont_tporan := 'C';
          v_cont_valor  := abs(j.intm_valor)*(-1);
        else
          v_cont_tporan := 'D';
          v_cont_valor  := abs(j.intm_valor);
        end if;
        --
        -- BUSCA SI PIDE AREA O CECO.
        --
        MAYO_PIDE_AREA_CECO ( v_etct, v_cont_mayo, v_pide_area, v_pide_ceco );
        --
        if ( v_pide_area = 'S' ) then
          v_area := j.intm_cont_area;
        else
          v_area := null;
        end if;
        --
        if ( v_pide_ceco = 'S' ) then
          v_ceco := j.intm_cont_ceco;
        else
          v_ceco := null;
        end if;
        --
        if ( j.intm_valor <> 0 ) then
          --
          -- Soli 5584  update sc_tmvco
          -- Soli 5584  set    mvco_mtoren    = mvco_mtoren + v_cont_valor
          -- Soli 5584  where  mvco_cias      = p_cias
          -- Soli 5584  and    mvco_tpco      = v_tpco
          -- Soli 5584  and    mvco_nrocom    = v_nrocom
          -- Soli 5584  and    mvco_fecmov    = v_fecmov
          -- Soli 5584  and    mvco_auxi      = nvl(v_cont_auxi,1)
          -- Soli 5584  and    mvco_mayo||''  = v_cont_mayo
          -- Soli 5584  and    mvco_tporan    = v_cont_tporan
          -- Soli 5584  and    nvl(mvco_ceco,'*')= nvl(v_ceco,'*')
          -- Soli 5584  and    nvl(mvco_area,'*')= nvl(v_area,'*');
          -- Soli 5584  --
          -- Soli 5584  if ( sql%rowcount = 0 ) then
            --
            v_rengln := nvl(v_rengln,0) + 1;
            --
            begin
              insert into sc_tmvco
              (
                  mvco_cias,          mvco_tpco,      mvco_nrocom,
                  mvco_fecmov,        mvco_rengln,    mvco_mayo,
                  mvco_auxi,          mvco_descri,    mvco_fecdoc,
                  mvco_mtoren,        mvco_tporan,    mvco_etct,
                  mvco_ceco,          mvco_area
              )
              values
              (
                  p_cias,             v_tpco,          v_nrocom,
                  v_fecmov,           v_rengln,        v_cont_mayo,
                  nvl(v_cont_auxi,1), v_descri,        v_feccom,
                  v_cont_valor,       v_cont_tporan,   v_etct,
                  v_ceco,             v_area
              );
            exception
               when others then
                    raise_application_error( -20652, 'SC_TMVCO: ' || sqlerrm );
            end;
            --
          -- end if;
          --
         end if;
         --
         -- CREA REGISTRO EN TESORERIA
         --
         if ( j.intm_valor <> 0 ) then
            --
            -- v_reng_ints := nvl(v_reng_ints,0)+1;  -- Soli 5584 se comenta
            --
            open  c_ge_tints;
            fetch c_ge_tints into v_reng_ints;
            close c_ge_tints;
            --
           begin
			 --Ini soli_1044 pmp
			 --
			 v_benefi := v_cont_auxi;
			 if j.intm_cuenta_destino is not null then
				--
				v_benefi := j.intm_auxi_P;
				--
			 end if;
			 --Fin soli_1044 pmp
			 --
             insert into ge_tints
              ( ints_infa,          ints_numero,        ints_rengln,
                ints_cias,          ints_tpco,          ints_nrocom,       ints_fecmov,
                ints_mayo,          ints_enti,          ints_tpmv,         ints_cheque,
                ints_benefi,        ints_tporan,        ints_valor,        ints_fecent,
                ints_fecpago,       ints_fluj,          ints_etoe,         ints_oecj,
                ints_feccre,        ints_fecmod,        ints_user,
                ints_descri,
                ints_fecdoc,        ints_etcf,          ints_status,       /*COMO058*/ints_fmpg, /*COMO058*/
                ints_vlrmone,       ints_pref,          ints_nrodoc,       ints_fac_fecdoc,   -- COMO058
                ints_valdoc                                                               -- COMO058
		       ,ints_cuenta_destino                                                           --soli_1044 pmp
		       ,ints_banc_destino                                                             --soli_1044 pmp
                )
            values
              ( p_infa,             p_numero,           v_reng_ints,
                p_cias,             v_tpco,             v_nrocom,           v_fecmov,
                v_cont_mayo,        v_cont_auxi,        j.intm_te_tpmv,     j.intm_cheque,
                v_benefi,           v_tporan,           v_cont_valor,       v_feccom,--soli_1044 pmp 
                --soli_1044 pmp v_cont_auxi,        v_tporan,           v_cont_valor,       v_feccom,
                v_feccom,           j.intm_te_fluj,     j.intm_te_etoe,     j.intm_te_oecj,
                sysdate,            sysdate,            p_Usua_Gene,
                v_descri,           --  'TESORERIA INTERFASE '||p_numero,
                v_feccom,           j.intm_te_etcf,     'I',  /*COMO058*/   j.intm_fmpg, /*COMO058*/
                j.intm_vlrmone,     j.intm_pref,        j.intm_nrodoc,      j.intm_fecdoc,    -- COMO058
                j.intm_valdoc                                                                 -- COMO058
		       ,j.intm_cuenta_destino                                                         --soli_1044 pmp
		       ,j.intm_banc_destino                                                           --soli_1044 pmp
                );
            --
           exception
             when others then
               raise_application_error( -20653, 'GE_TINTS: ' || sqlerrm );
           end;
           --
         end if;
         --
      end loop c_det;
      --
      for l in c_temp loop
        --
        v_reng_tes := nvl(v_reng_tes,0)+1;
        --
        -- Inicia COMO058
        v_mone := null;
        --
        open c_enti (  l.ints_enti );
          fetch c_enti into v_mone;
        close c_enti;
        --
        if ( nvl( l.ints_vlrmone,0 ) <> 0 ) then
            v_mone_apl  := l.ints_valor  / l.ints_vlrmone;
        else
           v_mone_apl  := null;
        end if;
        -- Termina COMO058
        --
        begin
          insert into te_tmvte
          (
             mvte_cias,         mvte_tpco,       mvte_nrocom,      mvte_fecmov,
             mvte_mayo,         mvte_enti,       mvte_tpmv,        mvte_cheque,
             mvte_benefi,       mvte_tporan,     mvte_valor,       mvte_fecent,
             mvte_fecpago,      mvte_etcf,       mvte_fluj,        mvte_etoe,
             mvte_oecj,
             mvte_feccre,       mvte_fecmod,     mvte_user,        mvte_descri,
             mvte_fecdoc,       mvte_rengln,     mvte_status,
             mvte_inar_numero,  -- Soli 5584
             mvte_fpag,         -- COMO058
             mvte_voper_morig,  mvte_inar_pref,  mvte_inar_nrodoc, mvte_inar_fecdoc,   -- COMO058
             mvte_inar_valdoc,  mvte_mone,       mvte_vmone_apl,   mvte_fecha                         -- COMO058   --  vers.1005.gap.-.14168. ovcaceres.  15/05/2012
			,mvte_abon_cta     ,mvte_abon_banc                                         --soli_1044 pmp
          )
          values
          (
             l.ints_CIAS,    l.ints_TPCO,     l.ints_NROCOM, l.ints_FECMOV,
             l.ints_MAYO,    l.ints_ENTI,     l.ints_TPMV,   l.ints_CHEQUE,
             l.ints_BENEFI,  l.ints_TPORAN,   l.ints_VALOR,  l.ints_FECENT,
             l.ints_FECPAGO, l.ints_etcf,     l.ints_fluj,   l.ints_etoe,
             l.ints_oecj,
             l.ints_FECCRE,  l.ints_FECMOD,   l.ints_USER,   l.ints_DESCRI,
             l.ints_FECDOC,  v_reng_tes,      l.ints_STATUS,
             p_numero,    -- Soli 5584
             l.ints_fmpg,  --COMO058
             l.ints_vlrmone, l.ints_pref,     l.ints_nrodoc, l.ints_fecdoc,             -- COMO058
             l.ints_valdoc,  v_mone,          v_mone_apl,    l.ints_fac_fecdoc                          -- COMO058  --  vers.1005.gap.-.14168. ovcaceres.  15/05/2012
			,l.ints_cuenta_destino           ,l.ints_banc_destino                                       --soli_1044 pmp
           );
        exception
          when others then
               raise_application_error( -20654, 'TE_TMVTE: ' || sqlerrm );
        end;
        --
      end loop c_temp;
      --
      v_Error := ge_qinfa.val_cuadre_comp(p_cias, v_tpco, v_nrocom, v_fecmov, 'CAR_CON_TES', p_Infa, p_Numero, p_Usua_Gene);
      -- Validacion de Comprobante Descuadrado
      if v_Error <> 'OK' then -- 109973 japoveda
      	raise_application_error( -20655, 'Valida Comprbante: ' || v_Error );
      end if;


      --
    end loop c_cab;
    --
  end CAR_CON_TES;
  --
  --
  --
  procedure CAR_CON_TRB ( p_cias          integer,
                          p_tpco          integer,
                          p_nrocom        integer,
                          p_Periodo       integer,
                          p_rengln        integer,
                          p_auxi          integer,
                          p_rete          varchar2,
                          p_valor         number,
                          p_vigorpa       integer,
                          p_orpa          integer,
                          p_ciud          integer,
                          p_aica          integer,
                          p_fecha         date,
                          p_tpliq         varchar2,
                          p_etct          integer,
                          p_base          number   default null,           -- 1012484.  ovcaceres.  02/03/2012
                          p_valbruto      number   default null            -- 1012484.  ovcaceres.  02/03/2012
                        )  IS
    --
    v_tpret   ge_tauxil.auxi_tpret%type;
    v_clase   ge_tdere.dere_clase%type;
    v_porc    ge_tdere.dere_porc%type;
    v_tipo    ge_tdere.dere_tipo%type;
    v_tpliq   ge_tacre.acre_tpliq%type;
    --
    cursor c_auxi is
      select auxi_tpret
      from   ge_tauxil
      where  auxi_auxi = p_auxi;
    --
    cursor c_dere is
      select dere_clase, dere_porc, dere_tipo
      from   ge_tdere
      where  dere_etct = p_etct
      and    dere_rete = p_rete;
    -- inicio 1012484.  ovcaceres.  02/03/2012
    v_rete           ge_tacre.acre_rete%type;
    cursor c_aica is select aica_porc
                     from ge_taica
                     where aica_ciud = p_ciud
                     and   aica_aica = p_aica
                     and   aica_etct = p_etct;
    --
    /* -- inicio antes de inc.14427
    cursor c_orpv is select orpv_tpvl
                     from cp_torpv
                     where orpv_cias = p_cias
                     and   orpv_vigorpa = p_vigorpa
                     and   orpv_orpa= p_orpa
                     and   orpv_tpliq = 'B';
    */ -- fin antes de inc.14427
    --
    v_tpvl           cp_torpv.orpv_tpvl%type;
    -- fin 1012484.  ovcaceres.  02/03/2012
    -- inicio 13509
  --cursor c_orpv2 is                   -- antes de inc.14427
  --cursor c_orpv2 (pc_base number) is  -- inc.14427                    -- antes de inc.16491
    cursor c_orpv2 (pc_base number, pc_tpliq varchar2 default null) is  -- inc.16491
      select orpv_tpvl,
             orpv_baseg -- inc.14427
      from   cp_torpv
      where  orpv_cias = p_cias
      and    orpv_vigorpa = p_vigorpa
      and    orpv_orpa = p_orpa
    --and    orpv_tpliq = 'B'               -- antes de inc.16491
      and    orpv_tpliq = nvl(pc_tpliq,'B') -- inc.16491
    --and    orpv_valor = nvl(abs(p_base), abs(p_valor)); -- antes de 13369
      -- inicio 13369
    --and    (abs(orpv_valor) = abs(p_base)               -- antes de inc.14427
      and    (abs(orpv_valor) = nvl(pc_base,abs(p_base))  -- inc.14427
              or abs(orpv_valor) = abs(p_valor)
             ); 
      -- fin 13369    
    -- fin 13509
    v_orpv_baseg      cp_torpv.orpv_baseg%type; -- inc.14427
    v_dump            cp_torpv.orpv_baseg%type; -- inc.14427
    -- inicio inc.16266
    cursor c_orpv3 is
      select orpv_cpto_liq_base
      from   cp_torpv
      where  orpv_cias = p_cias
      and    orpv_vigorpa = p_vigorpa
      and    orpv_orpa = p_orpa
      and    orpv_tpliq = 'D'
      and    orpv_cpto_liq_base is not null;
    -- fin inc.16266
    --
  BEGIN
    --
    open c_auxi;
    fetch c_auxi into v_tpret;
    if ( c_auxi%notfound ) then
      v_tpret := null;
    end if;
    close c_auxi;
    --
    open c_dere;
    fetch c_dere into v_clase, v_porc, v_tipo;
    if ( c_dere%notfound ) then
     v_clase := 'RF';
      v_porc  := 10;
    end if;
    close c_dere;
    -- inicio 1012484.  ovcaceres.  02/03/2012
    --
  --sf_pins_error('Ge_Qinfa 0 p_etct='||p_etct||' p_rete='||p_rete||' v_clase='||v_clase||' v_porc='||v_porc||' v_tipo='||v_tipo||' p_base='||p_base||' p_valor='||p_valor||' p_orpa='||p_orpa);
    if ( p_orpa is not null ) then
      /* -- inicio antes de inc.14427
      open  c_orpv;
        fetch c_orpv into v_tpvl;
      close c_orpv;
      */ -- fin antes de inc.14427
      -- inicio inc.16491
      if ( v_clase = 'RV' ) then
        v_tpliq := 'V';
      end if;
      -- fin inc.16491
      -- inicio inc.14427
    --open  c_orpv2 (null);           -- antes de inc.16491
      open  c_orpv2 (null, v_tpliq);  -- inc.16491
        fetch c_orpv2 into v_tpvl, v_orpv_baseg;
      close c_orpv2;
      -- fin inc.14427
    --sf_pins_error('Ge_Qinfa 1 v_tpvl='||v_tpvl||' v_orpv_baseg='||v_orpv_baseg);
    else
      --
      v_tpvl := p_rete;
      --
    end if;
    --
    if ( v_clase = 'IK' ) then
      --
      open  c_aica;
        fetch c_aica into v_porc;
      close c_aica;
      --
      v_rete := p_aica;
      --
    -- inicio 13509
    elsif ( v_clase = 'RF' and p_tpliq in ('D', 'A') ) then    -- vers.1005.15330. ovcaceres.  12/07/2012
      --
    --open  c_orpv2;        -- antes de inc.14427
      open  c_orpv2 (null); -- inc.14427
        fetch c_orpv2 into v_tpvl,
                           v_dump; -- inc.14427
      close c_orpv2;
      --
    --v_rete := v_tpvl; -- antes de inc.16491
      v_rete := p_rete; -- inc.16491
      --
    -- fin 13509 
    -- inicio inc.14427
    elsif ( v_clase = 'RV' ) then
      --
      open  c_orpv2 (v_orpv_baseg);
        fetch c_orpv2 into v_tpvl, v_dump;
      close c_orpv2;
      --
    --v_rete := v_tpvl; -- antes de inc.16491
      v_rete := p_rete; -- inc.16491
      --
    -- fin inc.14427     
    else
      --
      v_rete := p_rete;
      --
    end if;
    -- fin 1012484.  ovcaceres.  02/03/2012
  --Sf_Pins_Error('Ge_Qinfa 3 p_cias:'||p_cias||' Clase: '||v_clase||' Tpliq: '||p_tpliq||' rete:'||v_rete||' valor:'||p_valor||' tpliq:'||v_tpliq||' v_tpvl:'||v_tpvl);
    if ( p_tpliq is null ) then
      v_tpliq := v_tipo;
      --  inicio 1012776.  ovcaceres.  21/03/2012
      if ( v_clase = 'IV' ) then
        --
        v_tpliq := 'V';
        --
      end if;
      --  fin 1012776.  ovcaceres.  21/03/2012
    else
      v_tpliq := p_tpliq;
      /* -- inicio antes de 13298
      -- inicio 1012484.  ovcaceres.  02/03/2012
      if ( v_tpliq = 'D' ) then
        v_tpliq := 'A';
      end if;
      -- fin 1012484.  ovcaceres.  02/03/2012
      */ -- fin antes de 13298
      --  inicio 1012776.  ovcaceres.  21/03/2012
      if ( v_clase = 'IV' ) then
        --
        v_tpliq := 'V';
        --
      end if;
      --  fin 1012776.  ovcaceres.  21/03/2012
    end if;
    --  inicio vers.1023.gap.-.15472. ovcaceres.  10/07/2012
    if ( v_rete is null ) then
    --raise_application_error( -20752, 'No se encontr� Base (acre_rete) Cias:'||p_cias||' Clase: '||v_clase||' rete:'||v_rete||' valor:'||p_valor||' tpliq:'||v_tpliq||' v_tpvl:'||v_tpvl||' Bs: '||abs(p_base)||' Orpa: '||p_orpa ); -- antes de inc.16266
      -- inicio inc.16266
      open  c_orpv3;
        fetch c_orpv3 into v_rete;
        if c_orpv3%notfound then
          raise_application_error( -20752, 'No se encontr� Base (acre_rete) Cias:'||p_cias||' Clase: '||v_clase||' rete:'||v_rete||' valor:'||p_valor||' tpliq:'||v_tpliq||' v_tpvl:'||v_tpvl||' Bs: '||abs(p_base)||' Orpa: '||p_orpa );
        else
          --
          begin
            --
            insert into ge_tacre
               ( acre_cias,                     acre_tpco,   acre_nrocom,
                 acre_rengln,                   acre_fecmov, acre_auxi,
                 acre_tpret,                    acre_rete,   acre_base,
                 acre_iva,                      acre_valor,  acre_valic,
                 acre_valst,                    acre_cert,   acre_orpa,
                 acre_vigorpa,                  acre_ciud,   acre_aica,
                 acre_vrbruto,                  acre_feccom, acre_feccre,
                 acre_tpliq,                    acre_clase,  acre_rete_orig,
                 acre_porc,                     acre_etct )
            values
               ( p_cias,                        p_tpco,      p_nrocom,
                 p_rengln,                      p_Periodo,   p_auxi,
                 v_tpret,                       v_rete,      nvl(p_base, p_valor),
                 0,                             p_valor,     0,
                 0,                             null,        p_orpa,
                 p_vigorpa,                     p_ciud,      p_aica,
                 nvl(p_valbruto,abs(p_valor)),  p_fecha,     sysdate,
                 'B',                           v_clase,     v_tpvl,
                 v_porc,                        p_etct );
          exception
            when others then
              raise_application_error( -20701, 'GE_TACRE: ' || sqlerrm );
          end;
          --
        end if;
      close c_orpv3;
      -- fin inc.16266
    end if;
    --  fin vers.1023.gap.-.15472. ovcaceres.  10/07/2012
    --Sf_Pins_Error('Ge_Qinfa 1 p_cias:'||p_cias||' vigorpa:'||p_vigorpa||' orpa:'||p_orpa||' Clase: '||v_clase||' Tpliq: '||p_tpliq||' rete:'||v_rete||' valor:'||p_valor||
    --              ' tpliq:'||v_tpliq||' auxi:'||p_auxi||' tpvl:'||v_tpvl||' base:'||p_base);
    --
    begin
      --
      insert into ge_tacre
         ( acre_cias,      acre_tpco,   acre_nrocom,
           acre_rengln,    acre_fecmov, acre_auxi,
           acre_tpret,     acre_rete,   acre_base,
           acre_iva,       acre_valor,  acre_valic,
           acre_valst,     acre_cert,   acre_orpa,
           acre_vigorpa,   acre_ciud,   acre_aica,
           acre_vrbruto,   acre_feccom, acre_feccre,
           acre_tpliq,     acre_clase,  acre_rete_orig,
           acre_porc,      acre_etct )
      values
         ( p_cias,         p_tpco,      p_nrocom,
           p_rengln,       p_Periodo,   p_auxi,
         --v_tpret,        /*p_rete*/ v_rete,    nvl(abs(p_base), abs(p_valor)),   -- 1012484.  ovcaceres.  02/03/2012 -- antes de 13369
           v_tpret,        /*p_rete*/ v_rete,    nvl(p_base, p_valor),             -- 13369
           0,              p_valor,     0,
           0,              null,        p_orpa,
           p_vigorpa,      p_ciud,      p_aica,
           nvl(p_valbruto ,abs(p_valor)),   p_fecha,     sysdate,                  -- 1012484.  ovcaceres.  26/03/2012
           v_tpliq,        v_clase,     v_tpvl /*p_rete*/,                         -- 1012484.  ovcaceres.  02/03/2012
           v_porc,         p_etct );
    exception
      when others then
        raise_application_error( -20646, 'GE_TACRE: ' || sqlerrm );
    end;
    --
  end CAR_CON_TRB;
  --
  --
  --
  Procedure Car_Cxp ( p_Infa             varchar2,
                      p_Periodo          integer,
                      p_Numero           varchar2,
                      p_Cias             integer,
                      p_Fecha            date,
                      p_Usua_Gene          varchar2,
                      p_Agr_CXP          varchar2,
                      p_py_EtPy          integer,
                      p_py_Proy          varchar2,
                      p_py_EnAp          integer   ) is
    --
    -- Registro de Cambios
    -- ===================
    -- Cambio Realizo Fecha       Descripcion del Cambio
    -- ====== ======= =========== ================================================================
    -- (1)    Ira     28/02/2002  Numero de documento de ppto tambien se inserta en laorden de pago
    --                                         sin Pasivo Emtelsa
    --
    -- 2. Almoto - 11 marzo 2003 ( ITC ) - Solicitud 1237
    --    . Verifica que No Exista para un mismo Nit Agrupa, mas de un tipo de movimiento
    --      de Cuentas por Pagar. SOLO SE VERIFICA UNO POR PROCESO.
    --
    -- 3. Almoto - 9 abril 2003 ( ITC ) - Solicitud 1237
    --    . Se elimino validacion del cambio(2).
    --
    --
    v_OrPa          cp_torpa.orpa_orpa%type;
    v_ciud          ge_tciud.ciud_secu%type;
    v_auxi          ge_tauxil.auxi_auxi%type;
    v_tpmv          cp_ttpmv.tpmv_tpmv%type;
    v_vigorpa       cp_torpa.orpa_vigorpa%type;
    v_nrodoc        pp_tdocu.docu_nrodoc%type;
    v_pasivo        cp_ttpmv.tpmv_pasivo%type;
    v_ppto          cp_ttpmv.tpmv_ppto%type;
    v_valbruto      cp_torpa.orpa_valbruto%type;
    v_valdesc       cp_torpa.orpa_valdesc%type;
    v_valreint      cp_torpa.orpa_valreint%type;
    v_valneto       cp_torpa.orpa_valneto%type;
    v_val_base       cp_torpa.orpa_valneto%type; --*
    v_descri        cp_torpa.orpa_descri1%type;
    v_fecha         date;
    v_rete          ge_tauxil.auxi_tpret%type;
    v_tpdo2         cp_torpa.orpa_tpdo%type;
    v_nrodoc2       cp_torpa.orpa_nrodoc%type;
    v_tpco          cp_torpa.orpa_tpco%type;
    v_nrocom        cp_torpa.orpa_nrocom%type;
    v_tpliq_B_1     varchar2(1);
    v_tpliq_B_2     varchar2(1);
    v_tpliq_D       varchar2(1);
    v_causa_dsctos  cp_tctrl.ctrl_causa_dsctos%type;
    --
    v_Periodo_Proc integer;    -- Soli_5213
    --
    cursor c_auxi is
    select distinct intm_cxp_auxi, intm_cxp_tpmv, intm_fecha,
                    intm_ciud,     intm_tpco,     intm_cxp_pgpr,
                    decode(p_Agr_CXP, 'S', 1, 'N', intm_rengln) rengln, ---soli 5054
                    intm_fmpg,                                           ---COMO058
                  --intm_vlrmone,                                      -- antes de 1012546
                    intm_pref, intm_nrodoc, intm_fecdoc, intm_valdoc   -- COMO058
      from ge_tintm
     where intm_fecmov   =  p_Periodo
       and intm_numero   =  p_Numero
       and intm_cias     =  p_Cias
       and intm_cxp_auxi is not null
       and intm_cxp_tpmv is not null
       and intm_tpliq    not in ( 'I', 'N' )
       and intm_rete     is not null
       order by decode(p_Agr_CXP, 'S', 1, 'N', intm_rengln);
    --
    cursor c_valida is
    select intm_cxp_auxi, count(distinct intm_cxp_tpmv) QTpMv
      from ge_tintm
     where intm_fecmov   =  p_Periodo
       and intm_numero   =  p_Numero
       and intm_cias     =  p_Cias
       and intm_cxp_auxi is not null
       and intm_cxp_tpmv is not null
       and intm_tpliq    not in ( 'I', 'N' )
       and intm_rete     is not null
     group by intm_cxp_auxi
    having count(distinct intm_cxp_tpmv) > 1;
    --
    r_Va       c_Valida%RowType;
    v_Nit_CXP  integer;
    --
    cursor c_Nit ( pc_Auxi  integer ) is
    select auxi_Nit
      from ge_tauxil
     where auxi_Auxi = pc_Auxi;
    -- inicio 1012546
    cursor c_vlrmone (p_rengln integer, p_auxi integer, p_tpmv integer, pc_pref    varchar2,pc_nrodoc   varchar2,pc_fpag number ) is  -- vers.1022.gap.-.15473. ovcaceres.  09/07/2012
      select nvl(sum(intm_vlrmone),0)
      from   ge_tintm
      where  intm_fecmov   = p_Periodo
      and    intm_numero   = p_Numero
      and    intm_cias     = p_Cias
      and    intm_cxp_auxi = p_auxi
    --and    intm_cxp_tpmv = p_tpmv                             -- antes de inc.15473 ovcaceres.  09/07/2012
      and    intm_rengln   = decode(p_Agr_CXP, 'S', intm_rengln, 'N', p_rengln)
      and    intm_tpliq = 'N'                                   -- inc.15473 ovcaceres.  09/07/2012
      and    intm_fmpg     = pc_fpag   -- jarodriguez -- soli 1041
      and    nvl(intm_pref, '&&' ) = nvl( pc_pref,  '&&' )      -- vers.1022.gap.-.15473. ovcaceres.  09/07/2012
      and    nvl( intm_nrodoc, '&&' ) =  nvl( pc_nrodoc,  '&&' ); -- vers.1022.gap.-.15473. ovcaceres.  09/07/2012
    --
    v_vlrmone   ge_tintm.intm_vlrmone%type;
    -- fin 1012546
    v_orpa_Mayo_Pasivo  cp_torpa.orpa_Mayo_Pasivo%type; -- 14217
    --
  BEGIN
    --
    --
    -- Ini.Soli_5213
    --
    if ( p_Fecha is not null ) then
      v_Periodo_Proc := to_char(p_Fecha, 'yyyymm');
    else
      v_Periodo_Proc := null;
    end if;
    --
    -- Fin.Soli_5213
    --
    --
    for i in c_auxi loop
      --
      v_auxi        := i.intm_cxp_auxi;
      v_tpmv        := i.intm_cxp_tpmv;
      v_vigorpa     := trunc(nvl(v_Periodo_Proc, p_Periodo)/100);
      v_ciud        := i.intm_ciud;
      v_ppto        := null;
      --
      --
      begin
        select tpmv_pasivo, tpmv_ppto
        into   v_pasivo,    v_ppto
        from   cp_ttpmv
        where  tpmv_tpmv = v_tpmv;
      exception
        when no_data_found then
          raise_application_error( -20643, 'Tipo de Movimiento de CXP No Existe: ' || v_TpMv );
        when others then
          raise_application_error( -20644, 'CP_TTPMV: ' || sqlerrm );
      end;
      --
      if ( v_pasivo = 'P' ) then
        v_tpliq_B_1 := 'B';
        v_tpliq_B_2 := 'P';
        v_tpliq_D   := 'D';
      else
        v_tpliq_B_1 := 'D';
        v_tpliq_D   := 'X';
      end if;
      --
      begin
        select nvl(sum(intm_valor),0)
        into   v_valbruto
        from   ge_tintm
        where  intm_fecmov   = p_Periodo
        and    intm_numero   = p_Numero
        and    intm_cias     = p_Cias
        and    intm_cxp_auxi = v_auxi
        and    intm_cxp_tpmv = v_tpmv
        and    intm_rengln   = decode(p_Agr_CXP, 'S', intm_rengln, 'N', i.rengln) ---soli 5054
        and    intm_tpliq    in ('B')
        --*and    intm_fmpg     = i.intm_fmpg   -- jarodriguez -- soli 1041 ant 1043 rbermudez
        and    nvl(intm_fmpg, '&&' ) = nvl( i.intm_fmpg,  '&&' ) --* 1043 rbermudez
        and    nvl(intm_pref, '&&' ) = nvl( i.intm_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
        and    nvl( intm_nrodoc, '&&' ) =  nvl( i.intm_nrodoc,  '&&' ); -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
      exception
        when others then
            null;
      end;
      --
      --
      begin
        select nvl(sum(intm_valor),0)
        into   v_valdesc
        from   ge_tintm
        where  intm_fecmov   = p_Periodo
        and    intm_numero   = p_Numero
        and    intm_cias     = p_Cias
        and    intm_cxp_auxi = v_auxi
        and    intm_cxp_tpmv = v_tpmv
        and    intm_rengln   = decode(p_Agr_CXP, 'S', intm_rengln, 'N', i.rengln) ---soli 5054
        and    intm_tpliq    in ('D')
        --*and    intm_fmpg     = i.intm_fmpg   -- jarodriguez -- soli 1041  ant 1043 
        and    nvl(intm_fmpg, '&&' ) = nvl( i.intm_fmpg,  '&&' ) --* 1043 rbermudez
        and    nvl(intm_pref, '&&' ) = nvl( i.intm_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
        and    nvl( intm_nrodoc, '&&' ) =  nvl( i.intm_nrodoc,  '&&' ); -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
      exception
        when others then
            null;
      end;
      Sf_Pins_Error('Ge_Qinfa * CxP. v_val_base: '||v_val_base||' p_Periodo: '||p_Periodo||' p_Numero: '||p_Numero||' v_auxi: '||v_auxi||' Tpmv: '||v_tpmv);   

      --
      begin
        select nvl(sum(intm_valor),0)
        into   v_valreint
        from   ge_tintm
        where  intm_fecmov   = p_Periodo
        and    intm_numero   = p_Numero
        and    intm_cias     = p_Cias
        and    intm_cxp_auxi = v_auxi
        and    intm_cxp_tpmv = v_tpmv
        and    intm_rengln   = decode(p_Agr_CXP, 'S', intm_rengln, 'N', i.rengln) ---soli 5054
        and    intm_tpliq    in ('P')
        --* and    intm_fmpg     = i.intm_fmpg   -- jarodriguez -- soli 1041 --*1043
        and    nvl(intm_fmpg, '&&' ) = nvl( i.intm_fmpg,  '&&' ) --* 1043 rbermudez
        and    nvl(intm_pref, '&&' ) = nvl( i.intm_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
        and    nvl( intm_nrodoc, '&&' ) =  nvl( i.intm_nrodoc,  '&&' ); -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012

      exception
        when others then
            null;
      end;
      --
      -- inicio 1012546
      v_vlrmone := null;    -- vers.1022.gap.-.15473. ovcaceres.  09/07/2012
      open  c_vlrmone ( i.rengln, v_auxi, v_tpmv, i.intm_pref, i.intm_nrodoc, i.intm_fmpg  );     -- vers.1022.gap.-.15473. ovcaceres.  09/07/2012  -- jarodriguez -- soli 1041
      fetch c_vlrmone into v_vlrmone;
      close c_vlrmone;
      -- fin 1012546
      --
      v_fecha   := nvl(p_Fecha, to_date(i.intm_fecha,'dd-mm-yyyy'));
      --  inicio vers.1011.gap.-.14029. lhernandez.  09/05/2012
      				if ( i.intm_pref||i.intm_nrodoc is not null ) then
        			v_fecha   := to_date(i.intm_fecha,'dd-mm-yyyy');
      				end if;
      --  fin vers.1011.gap.-.14029. lhernandez.  09/05/2012
      v_valneto := nvl(v_valbruto,0) - nvl(v_valdesc,0) + nvl(v_valreint,0); 
      --
      Sf_Pins_Error('Ge_Qinfa*CxP. v_valneto: '||v_valneto||' v_valbruto: '||v_valbruto||' v_valdesc: '||v_valdesc||' v_valreint: '||v_valreint||' v_val_base: '||v_val_base);             
      
      v_descri  := 'ORDEN DE PAGO INTERFASE NUMERO: '||p_Numero;
      --
      Cp_PNume_OrPa_Fases (p_Cias, v_vigorpa, nvl(v_Periodo_Proc, p_Periodo), v_OrPa);
      --
      --
      begin
        select auxi_tpret
        into   v_rete
        from   ge_tauxil
        where  auxi_auxi = v_auxi;
      exception
        when no_data_found then
          raise_application_error( -20667, 'Codigo Auxiliar NO EXISTE : ' || v_Auxi );
        when others then
          raise_application_error( -20668, 'GE_TAUXIL: ' || sqlerrm );
      end;
      --
      if ( ( v_pasivo In('P','S') and v_ppto = 'S' ) or   -- Cambio(1)
           ( v_pasivo = 'P' and v_ppto = 'N' ) ) then
        --
        begin
          select distinct nvl(intm_pp_tpdo2, intm_pp_tpdo), nvl(intm_pp_nrodoc2, intm_pp_nrodoc), intm_tpco
          into   v_tpdo2, v_nrodoc2, v_tpco
          from   ge_tintm
          where  intm_fecmov   = p_Periodo
          and    intm_numero   = p_Numero
          and    intm_cias     = p_Cias
          and    intm_cxp_auxi = v_auxi
          and    intm_cxp_tpmv = v_tpmv
          and    intm_pp_tpdo is not null
          and    intm_tpco is not null
          and    intm_rengln   = decode(p_Agr_CXP,'S',intm_rengln,'N',i.rengln) ---soli 5054
          and    intm_cxp_tpdo is not null
          and    intm_fmpg     = i.intm_fmpg   -- jarodriguez -- soli 1041
          and    nvl(intm_pref, '&&' ) = nvl( i.intm_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
          and    nvl( intm_nrodoc, '&&' ) =  nvl( i.intm_nrodoc,  '&&' ); -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
          --
        exception
               --when No_data_Found then
                -- Bloqueo('No Encontro datos cias='||pe_cias||' auxi='||v_auxi||' tpmv='||v_tpmv||' numero='||p_Numero);
          when others then
            v_tpco := i.intm_tpco;
        end;
        --
      else
        v_tpdo2  := null;
        v_nrodoc2:= null;
        v_tpco   := i.intm_tpco;
      end if;
      --
      -- Busca el Modulo de Causacion de los Descuentos.
      --
      begin
        select ctrl_causa_dsctos
        into   v_causa_dsctos
        from   cp_tctrl
        where  ctrl_cias = p_Cias;
      exception
        when others then
          v_causa_dsctos := 'C';
      End;
      --
      -- inicio 14217
      begin
      --select distinct intm_inpa_cont_mayo         -- antes de inc.14628
        select intm_inpa_cont_mayo                  -- inc.14628
        into   v_orpa_Mayo_Pasivo
        from   ge_tintm
        where  intm_numero   = p_numero
        and    intm_fecmov   = p_Periodo
        and    intm_tpliq    = 'N'
        and    intm_cias     = p_cias
        and    intm_cxp_auxi = v_auxi
        and    intm_rengln   = decode(p_Agr_CXP, 'S', intm_rengln, 'N', i.rengln)
        and    intm_inpa_cont_mayo is not null
        and    intm_fmpg     = i.intm_fmpg   -- jarodriguez -- soli 1041
        -- inicio inc.14628
        and    nvl(intm_pref, '&&' ) = nvl( i.intm_pref,  '&&' )
        and    nvl( intm_nrodoc, '&&' ) =  nvl( i.intm_nrodoc,  '&&' )
        having sum(intm_valor) = v_valneto  
        group by intm_inpa_cont_mayo;
        -- fin inc.14628
      exception
        when no_data_found then         -- inc.14217 28/05/2012   dfgarzon
          v_orpa_Mayo_Pasivo := null;   -- inc.14217 28/05/2012   dfgarzon
        when others then
          null;
      end;
      -- fin 14217
        --
      begin
        --
        sf_pins_error(  'CIAS:'||p_cias||' ORPA:'||v_OrPa||' VIGORPA:'||v_VIGORPA||' TPDO:'||v_TPDO2||' VALOR NETO:'||v_VALNETO||
                        ' VALDESC:'||v_VALDESC||' VALBRUTO:'||v_VALBRUTO ||' v_orpa_Mayo_Pasivo:'||v_orpa_Mayo_Pasivo||' v_Periodo_Proc:'||v_Periodo_Proc
                        ||' v_auxi:'||v_auxi||' p_numero:'||p_numero);
        insert into Cp_tOrpa
        (
            ORPA_CIAS,       ORPA_VIGORPA,     ORPA_ORPA,
            ORPA_VIGDOCU,    ORPA_TPDO,        ORPA_NRODOC,
            ORPA_VALBRUTO,   ORPA_VALDESC,     ORPA_VALNETO,
            ORPA_ACTAOP,     ORPA_TPMV,        ORPA_FECVTO,
            ORPA_TPCO,       ORPA_NROCOM,      ORPA_FECMOV,
            ORPA_FECCOM,     ORPA_DESCRI1,     ORPA_FECCRE,
            ORPA_AUTORIZADO, ORPA_USER,        ORPA_RETE,
            ORPA_CIASCONTAB, ORPA_AUXI,        ORPA_CAUSA_DSCTOS,
            ORPA_CIUD,       ORPA_VALFACT,     ORPA_PAGO_PARCIAL,
            ORPA_VALREINT,   ORPA_PROCESO,
            ORPA_PY_CIAS,    ORPA_PY_ETPY,     ORPA_PY_PROY,
            ORPA_PY_ENAP,
            ORPA_INAR_NUMERO,  -- SOLI 5584
            ORPA_FPAG,          -- COMO058,
            ORPA_INAR_VLRMONE, ORPA_INAR_PREF,                       -- COMO058
            ORPA_INAR_NRODOC, ORPA_INAR_FECDOC, ORPA_INAR_VALDOC,     -- COMO058
            orpa_Mayo_Pasivo -- 14217
        )
        values
        (
            p_CIAS,          v_VIGORPA,        v_OrPa,
            v_vigorpa,       v_TPDO2,          v_NRODOC2,
            v_VALBRUTO,      v_VALDESC,        v_VALNETO,
            -99,             v_TPMV,           v_fecha,
            v_TPCO,          null,             nvl(v_Periodo_Proc, p_Periodo),
            v_fecha,         v_DESCRI,         sysdate,
            'N',             p_Usua_Gene,        v_RETE,
            p_CIAS,          v_auxi,           v_causa_dsctos,
            v_ciud,          v_valbruto,       i.intm_cxp_pgpr,
            v_ValReint,      'INTERFASE',
            p_cias,          p_py_etpy,        p_py_proy,
            p_py_enap,
            p_numero,   -- Soli 5584
            i.intm_fmpg, -- COMO058
          --i.intm_vlrmone,  i.intm_pref,      i.intm_nrodoc,  -- COMO058 -- antes de 1012546
            v_vlrmone,       i.intm_pref,      i.intm_nrodoc,             -- 1012546
            i.intm_fecdoc,   i.intm_valdoc,                     -- COMO058
            v_orpa_Mayo_Pasivo -- 14217
        );
        --
        exception
          when others then
            raise_application_error( -20645, 'CP_TORPA: OrPa='||v_OrPa || ' : ' || sqlerrm );
      end;
      --
      --
      -- CARGA LIQUIDACION.
      --
      dbms_output.put_line('Antes de CAR_ORPV.  Orpa='||v_OrPa || ' VigOrPa='||v_VigOrPa || ' Agr_CXP='||p_Agr_CXP || ' TpMv='||v_TpMv || ' Auxi='||v_Auxi);
      --
      CAR_ORPV ( p_Infa, p_Periodo, p_Numero, p_Cias,     p_Fecha,   p_Usua_Gene,     v_VigOrPa,
                 v_OrPa, v_Auxi,    v_TpMv,   v_ValBruto, v_ValNeto, i.Rengln,      p_Agr_CXP,
                 i.intm_pref, i.intm_nrodoc );   -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
      --
      --Raise_application_error(-20026,'STOPPP');
      --
      update ge_tintm
         set intm_vigorpa  = v_vigorpa,
             intm_orpa     = v_OrPa
       where intm_fecmov   = p_Periodo
         and intm_numero   = p_Numero
         and intm_cias     = p_Cias
         and intm_cxp_auxi = v_auxi
         and intm_rengln   = decode(p_Agr_CXP, 'S', intm_rengln, 'N', i.rengln) ---soli 5054
         and intm_tpliq  not in ('I')
         and intm_fmpg     = i.intm_fmpg   -- jarodriguez -- soli 1041
         and nvl(intm_pref, '&&' ) = nvl( i.intm_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
         and nvl( intm_nrodoc, '&&' ) =  nvl( i.intm_nrodoc,  '&&' ); -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012

      --
      --
      dbms_output.put_line('Act.' || sql%RowCount || ' Regs. Infa='||p_Infa || ' Per='||p_Periodo || ' Num='||p_Numero ||
                           ' Cias='||p_Cias || ' Auxi='||v_Auxi || ' Agr='||p_Agr_CXP || ' Ren='||i.Rengln);
      --
      --
      If ( v_ppto = 'S' ) then
        --
        Car_Ppto_CXP( p_Infa, p_Periodo, p_Numero, p_Cias,     p_Fecha,   p_Usua_Gene, v_VigOrPa,
                      v_OrPa, v_TpMv,    v_Auxi,   v_ValBruto, i.intm_pref, i.intm_nrodoc );    -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
        --
      end if;
      --
      --
      Car_CXP_PgPr( p_Infa,    p_Periodo, p_Numero, p_Cias,     p_Fecha,
                    p_Usua_Gene, v_VigOrPa, v_OrPa,   v_ValNeto, i.intm_pref, i.intm_nrodoc );  -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012

      --
      -- Ini soli_60065
      --
      update cp_torpa
      	set orpa_autorizado = 'S'
      where orpa_cias       = p_Cias
      and   orpa_orpa       = v_OrPa
      and   orpa_vigorpa    = v_VigOrPa
      ;
      --
      -- Fin soli_60065
      --
    end loop c_Auxi;
    --
    -- commit;   -- 1012954.  ovcaceres.  16/03/2012
    --
  end Car_CxP;
  --
  --
  --
  procedure Car_Cxp_PgPr( p_Infa             varchar2,
                          p_Periodo          integer,
                          p_Numero           varchar2,
                          p_Cias             integer,
                          p_Fecha            date,
                          p_Usua_Gene          varchar2,
                          p_VigOrpa          integer,
                          p_Orpa             integer,
                          p_VrNeto           number,
                          p_pref             varchar2   default null,          -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
                          p_nrodoc           varchar2   default null           -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
                             ) is
    --
    -- Modificaciones:
    -- 1. Almoto - 19 septiembre 2002 ( ICT ).
    --    . Se modificaron cursores para que traigan la dependencia o area a la que pertenece
    --      el pago, para tenerlo en cuenta en el ordenamiento. El cursor C_1_PAGO, se modifico,
    --      ademas para que ordene de acuerdo al nit del beneficiario y no por el auxiliar.
    --      Se tiene en cuenta en la insercion a CP_Tpgpr, la nueva columna pgpr_DEPENDENCIA.
    --
    -- 2. Almoto - 26 septiembre 2002 ( APTO ).
    --    . Se crean cursores c_intm_Nom y c_intm_Nit
    --
    -- 3. Almoto - 29 septiembre 2002 ( APTO ).
    --    . Nueva variable V_CON_PGPR, para poder identificar si la orden de pago, tiene o no
    --      pagos parciales. Trae informacion relacionada con Operaciones Efectivas de Caja y
    --      con Flujos de Caja. Se crearon nuevas variables para guardar dicha informacion, para
    --      luego actualizar la Orden de Pago.
    --
    -- 4. Almoto - 18 octubre 2002 ( ITC ).
    --    . Se habilito procesamiento de cursor C_INTM_CHEQUE.
    --
    -- 5. Almoto - 14 noviembre 2002 ( ITC ).
    --    . Se arreglo GROUP BY del cursor C_INTM_CHEQUE.
    --
    -- 6. Almoto - 22 febrero 2003 ( ITC ) - Solicitud 1138
    --    . Se modifico condicion en cursor c_intm_cheque, para que tome los registros NETOS,
    --      lo los BASES.
    --    . Se tiene en cuenta la columna PGPR_VNETO en la insercion.
    --
    -- 7. Almoto - 11 marzo 2003 ( ITC ) - Solicitud 1138
    --    . Se crearon variables tipo exception.
    --    . Nuevas variables v_error y v_mensaje.
    --    . Sentencias de insercion a la tabla cp_tpgpr, se dejaron dentro de un bloque, con
    --      manejo de errores.
    --    . Al final del procedimiento, se modifico el area de excepciones.
    --
    -- 8. Almoto - 2 julio 2003 - Solicitud 1597
    --    . Ajuste menor realizado para cuando todos los pagos parciales tienen asociado numero
    --      de cheque.  Se agrego sentencia "v_con_PgPr := true;", para que la Orden de Pago
    --      quede con Pagos Parciales ( ORPA_PAGO_PARCIAL = 'S' ).
    --
    -- 9. Almoto - 25 julio 2003 - Solicitud 1722
    --    . Se agrego sentencia para actualizar ge_tintm, con el numero de pago parcial.
    --
    v_nropag       integer := 0;
  --v_porc         number;          -- Antes de vs.1022 sol. 15673 03/07/2012 dcgarces
    v_porc         number (22,17);  -- vs.1022 sol. 15673 03/07/2012 dcgarces
    v_saldo        number;
    v_VPagos       number := 0;
    v_fecpag       date;
    v_Benefi       integer;
    --
    v_Con_PgPr          boolean   := false;
    v_INTM_TE_ETCF   ge_tintm.INTM_TE_ETCF%Type;
    v_INTM_TE_FLUJ   ge_tintm.INTM_TE_FLUJ%Type;
    v_INTM_TE_ETOE   ge_tintm.INTM_TE_ETOE%Type;
    v_INTM_TE_OECJ   ge_tintm.INTM_TE_OECJ%Type;
    --
    e_pgpr_1    exception;             -- Soli_1138
    e_pgpr_2    exception;             -- Soli_1138
    e_pgpr_3    exception;             -- Soli_1138
    v_Error     varchar2(500);         -- Soli_1138
    v_Mensaje   varchar2(500);         -- Soli_1138
    --
    cursor c_intm_Nom is
    select intm_cxp_auxi_pgpr, intm_fecha,   auxi_descri,  intm_Dependencia, intm_valor,
           intm_te_etoe,       intm_te_oecj, intm_te_etcf, INTM_TE_FLUJ,
           intm_fmpg, --COMO058
           intm_vlrmone,       intm_pref,    intm_nrodoc,  intm_fecdoc,      intm_valdoc   -- COMO058
      from ge_tintm, ge_tauxil
     where intm_fecmov          = p_Periodo
       and intm_numero          = p_Numero
       and intm_cias            = p_Cias
       and intm_vigorpa         = p_VigOrpa
       and intm_Orpa            = p_Orpa
       and intm_tpliq           = 'N'
       and intm_cxp_PgPr        = 'S'
       and intm_cxp_Ordena_PgPr = 'NM'
       and intm_ncuenta         is null
       and intm_cheque          is null
       and auxi_auxi            = intm_cxp_auxi_pgpr
       and    nvl(intm_pref, '&&' ) = nvl( p_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
       and    nvl( intm_nrodoc, '&&' ) =  nvl( p_nrodoc, '&&'  ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
     order by intm_Dependencia, auxi_descri;
    --
    cursor c_intm_Nit is
    select intm_cxp_auxi_pgpr, intm_fecha,   auxi_Nit,     intm_Dependencia, sum(intm_valor) intm_valor,
           intm_te_etoe,       intm_te_oecj, intm_te_etcf, INTM_TE_FLUJ,
           intm_fmpg, --COMO058
           sum(intm_vlrmone)   intm_vlrmone, intm_pref,    intm_nrodoc,      intm_fecdoc,       -- COMO058
           sum(intm_valdoc)    intm_valdoc                                                      -- COMO058
      from ge_tintm, ge_tauxil
     where intm_fecmov          = p_Periodo
       and intm_numero          = p_Numero
       and intm_cias            = p_Cias
       and intm_vigorpa         = p_VigOrpa
       and intm_Orpa            = p_Orpa
       and intm_tpliq           = 'N'
       and intm_cxp_PgPr        = 'S'
       and intm_cxp_Ordena_PgPr = 'NI'
       and intm_ncuenta         is null
       and intm_cheque          is null
       and auxi_auxi            = intm_cxp_auxi_pgpr
       and    nvl(intm_pref, '&&' ) = nvl( p_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
       and    nvl( intm_nrodoc, '&&' ) =  nvl( p_nrodoc, '&&'  ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
     Group by intm_cxp_auxi_pgpr, intm_Dependencia, intm_fecha,   auxi_Nit,
              intm_te_etoe,       intm_te_oecj,     intm_te_etcf, INTM_TE_FLUJ,
              intm_fmpg, --COMO058
              intm_pref,          intm_nrodoc,      intm_fecdoc       -- COMO058
     order by intm_Dependencia, auxi_Nit;
    --
    --
    cursor c_intm_Cheque is
    select intm_cxp_auxi_pgpr, intm_fecha,   intm_Dependencia,
           intm_fmpg, --COMO058
           nvl(sum(intm_inco_base_valor), sum(intm_valor)) intm_valor,
           sum(intm_vlrmone)   intm_vlrmone, intm_pref,        intm_nrodoc,    intm_fecdoc,    -- COMO058
           sum(intm_valdoc)    intm_valdoc                                                     -- COMO058
      from ge_tintm, ge_tauxil
     where intm_fecmov    =  p_Periodo
       and intm_numero    =  p_Numero
       and intm_cias      =  p_Cias
       and intm_vigorpa   =  p_VigOrpa
       and intm_Orpa      =  p_Orpa
       and intm_tpliq     =  'N'                                    --- Soli_1138
       and intm_ncuenta   is not null
       and auxi_auxi      =  intm_cxp_auxi_pgpr
       and    nvl(intm_pref, '&&' ) = nvl( p_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
       and    nvl( intm_nrodoc, '&&' ) =  nvl( p_nrodoc, '&&'  ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
     Group by intm_cxp_auxi_pgpr, intm_fecha,  intm_Dependencia,    --- Cambio(5)
              intm_fmpg,  --COMO058
              intm_pref,          intm_nrodoc, intm_fecdoc          -- COMO058
     order by intm_Dependencia;
    --
    --
    --
  BEGIN
    --
    -- Carga Pagos Parciales con estado P-Procesados. Vienen con Numero de Cuenta Bancaria y
    -- posiblemente con Numero de Cheque.
    --
    For j in c_intm_Cheque loop
      --
      v_NroPag := nvl(v_NroPag,0) + 1;
      --
      --incio 13298. lhernandez
      if(p_vrneto = 0) then
        v_Porc := 0;
      else
        v_Porc   := (j.intm_valor * 100) / p_vrneto;
      end if; 
      --fin 13298. lhernandez
      -- v_Porc   := (j.intm_valor * 100) / p_vrneto;
      v_VPagos := nvl(v_VPagos, 0) + j.intm_valor;
      v_Saldo  := p_vrneto - v_VPagos;
      v_fecpag := nvl(p_Fecha, to_date(j.intm_Fecha,'dd-mm-yyyy'));
      --
      begin
        --
        Insert into Cp_tPgPr
          (PgPr_Cias,             PgPr_VigOrPa,      PgPr_OrPa,        PgPr_PgPr,
           PgPr_FecPago,          PgPr_Porc,         PgPr_VPago,       PgPr_VSaldo,
           PgPr_Stat,             PgPr_CtCo_TpCo,    PgPr_CtCo_NroCom, PGPR_CTCO_PERIOD,
           PgPr_FecCre,           PgPr_Usua,         PgPr_FecMod,      PgPr_UsuaMod,
           PgPr_Benefi,           pgpr_Vneto,        /*COMO058*/       pgpr_fpag, /*COMO058*/
           pgpr_inar_vlrmone,     pgpr_inar_pref,    pgpr_inar_nrodoc, pgpr_inar_fecdoc,    -- COMO058
           pgpr_inar_valdoc                                                                 -- COMO058
           )
        Values
          (p_Cias,                p_VigOrPa,         p_OrPa,           v_NroPag,
           v_fecpag,              v_porc,            j.intm_valor,     v_saldo,
           'P',                   null,              null,             null,
           sysdate,               p_Usua_Gene,       sysdate,          p_Usua_Gene,
           j.intm_cxp_auxi_pgpr,  j.intm_Valor,      /*COMO058*/       j.intm_fmpg,/*COMO058*/
           j.intm_vlrmone,        j.intm_pref,       j.intm_nrodoc,    j.intm_fecdoc,        -- COMO058
           j.intm_valdoc                                                                     -- COMO058
           );
        --
      exception
        when others then
           --v_Mensaje := 'Pago='||v_NroPag || ' Porc='||v_Porc || ' Valor='||j.intm_Valor || ' Neto='||p_VrNeto || ' Saldo='||v_Saldo;
           v_Error := sqlerrm;
           raise e_PgPr_1;
      end;
      --
      -- Actualiza Numero de Pago Parcial en Archivo Principal
      --
      begin                                                  --- Soli_1722  Ini.A
        --
        update ge_tintm
           set intm_PgPr                  =  v_NroPag
         where intm_fecmov                =  p_Periodo
           and intm_numero                =  p_Numero
           and intm_cias                  =  p_Cias
           and intm_vigorpa               =  p_VigOrpa
           and intm_Orpa                  =  p_Orpa
           and intm_tpliq                 =  'N'
           and intm_ncuenta               is not null
           and intm_cxp_auxi_PgPr         = j.intm_cxp_Auxi_PgPr
           and nvl(intm_Dependencia, '0') = nvl(j.intm_Dependencia, '0')
           and intm_Fecha                 = j.intm_Fecha;
        --
      end;                                                   --- Soli_1722  Fin.A
      --
      v_con_PgPr := true;      ---- Soli_1597
      --
    end loop c_intm_Cheque;
    --
    -- Carga Pagos Parciales ordenados por Nombre
    --
    for j in c_intm_Nom loop
      --
      v_NroPag := v_NroPag + 1;
      --
      --inicio 13298. lhernandez
      if(p_vrneto = 0) then
        v_Porc := 0;
      else
        v_Porc   := (j.intm_valor*100) / p_vrneto;
      end if;
      --fin 13298 lhernandez
      --
      -- v_Porc   := (j.intm_valor*100) / p_vrneto;   -- 13298
      v_VPagos := nvl(v_VPagos, 0) + j.intm_valor;
      v_Saldo  := p_vrneto - v_VPagos;
      v_fecpag := nvl(p_Fecha, to_date(j.intm_Fecha,'dd-mm-yyyy'));
      v_Benefi := j.intm_cxp_auxi_pgpr;
      --
      v_INTM_TE_ETCF   := j.INTM_TE_ETCF;
      v_INTM_TE_FLUJ   := j.INTM_TE_FLUJ;
      v_INTM_TE_ETOE   := j.INTM_TE_ETOE;
      v_INTM_TE_OECJ   := j.INTM_TE_OECJ;
      --
      begin
        --
        Insert into Cp_tpgpr
          (pgpr_Cias,         pgpr_VigOrPa,       pgpr_OrPa,        pgpr_pgpr,
           pgpr_FecPago,      pgpr_Porc,          pgpr_VPago,       pgpr_VSaldo,
           pgpr_Stat,         pgpr_CtCo_TpCo,     pgpr_CtCo_NroCom, pgpr_CTCO_PERIOD,
           pgpr_FecCre,       pgpr_Usua,          pgpr_FecMod,      pgpr_UsuaMod,
           pgpr_Benefi,       pgpr_Dependencia,   pgpr_VNeto,       /*COMO058*/pgpr_fpag,/*COMO058*/
           pgpr_inar_vlrmone, pgpr_inar_pref,     pgpr_inar_nrodoc,      -- COMO058
           pgpr_inar_fecdoc,  pgpr_inar_valdoc                           -- COMO058
           )
        Values
          (p_Cias,         p_VigOrPa,          p_OrPa,           v_NroPag,
           v_fecpag,       v_porc,             j.intm_valor,     v_saldo,
           'A',            null,               null,             null,
           sysdate,        p_Usua_Gene,        sysdate,          p_Usua_Gene,
           v_Benefi,       j.intm_Dependencia, j.intm_Valor,     /*COMO058*/j.intm_fmpg,/*COMO058*/
           j.intm_vlrmone, j.intm_pref,        j.intm_nrodoc,            -- COMO058
           j.intm_fecdoc,  j.intm_valdoc                                 -- COMO058
           );
        --
      exception
         when others then
           --v_Mensaje := 'Pago='||v_NroPag || ' Porc='||v_Porc || ' Valor='||j.intm_Valor || ' Neto='||p_VrNeto || ' Saldo='||v_Saldo || ' OrPa='||p_OrPa;
           v_Error := sqlerrm;
           raise e_PgPr_2;
      end;
      --
      v_con_PgPr := true;
      --
    End loop c_intm_Nom;
    --
    -- Carga Pagos Parciales ordenados por NIT
    --
    --
    For i in c_intm_Nit loop
      --
      v_NroPag := nvl(v_NroPag,0) + 1;
      --
      --incio 13298 lhernandez
      if(p_vrneto = 0) then
        v_Porc := 0;
      else
        v_Porc   := (i.intm_valor*100) / p_vrneto;
      end if; 
      -- fin 13298. lhernandez
      --  v_Porc   := (i.intm_valor*100) / p_vrneto;   -- 13298
      v_VPagos := nvl(v_VPagos,0) + i.intm_valor;
      v_saldo  := p_vrneto - v_VPagos;
      v_fecpag := nvl(p_Fecha, to_date(i.intm_Fecha,'dd-mm-yyyy'));
      v_Benefi := i.intm_cxp_auxi_pgpr;
      --
      v_INTM_TE_ETCF   := i.INTM_TE_ETCF;
      v_INTM_TE_FLUJ   := i.INTM_TE_FLUJ;
      v_INTM_TE_ETOE   := i.INTM_TE_ETOE;
      v_INTM_TE_OECJ   := i.INTM_TE_OECJ;
      --
      --
      begin
        --
        Insert into Cp_tpgpr
          (pgpr_Cias,            pgpr_VigOrPa,       pgpr_OrPa,        pgpr_pgpr,
           pgpr_FecPago,         pgpr_Porc,          pgpr_VPago,       pgpr_VSaldo,
           pgpr_Stat,            pgpr_CtCo_TpCo,     pgpr_CtCo_NroCom, pgpr_CTCO_PERIOD,
           pgpr_FecCre,          pgpr_Usua,          pgpr_FecMod,      pgpr_UsuaMod,
           pgpr_Benefi,          pgpr_Dependencia,   pgpr_VNeto,       /*COMO058*/pgpr_fpag,/*COMO058*/
           pgpr_inar_vlrmone,    pgpr_inar_pref,     pgpr_inar_nrodoc,        -- COMO058
           pgpr_inar_fecdoc,     pgpr_inar_valdoc                             -- COMO058
           )
        Values
          (p_Cias,               p_VigOrPa,          p_OrPa,           v_NroPag,
           v_fecpag,             v_porc,             i.intm_valor,     v_saldo,
           'A',                  null,               null,             null,
           sysdate,              p_Usua_Gene,        sysdate,          p_Usua_Gene,
           i.intm_cxp_auxi_pgpr, i.intm_Dependencia, i.intm_Valor,    /*COMO058*/i.intm_fmpg,/*COMO058*/
           i.intm_vlrmone,       i.intm_pref,        i.intm_nrodoc,           -- COMO058
           i.intm_fecdoc,        i.intm_valdoc                                -- COMO058
           );
        --
      exception
         when others then
           --v_Mensaje := 'Pago='||v_NroPag || ' Porc='||to_char(v_Porc,'999,999.99') || ' Valor='||i.intm_Valor || ' Neto='||p_VrNeto || ' Saldo='||v_Saldo || ' Ben='||i.intm_cxp_auxi_pgpr;
           v_Error := sqlerrm;
           raise e_PgPr_3;
      end;
      --
      v_con_PgPr := true;
      --
    end loop c_intm_Nit;
    --
    if ( v_con_PgPr ) then
      --
      update cp_torpa
      set    orpa_pago_Parcial = 'S',
             orpa_EtCF         = v_INTM_TE_ETCF,
             orpa_Fluj         = v_INTM_TE_FLUJ,
             orpa_ETOE         = v_INTM_TE_ETOE,
             orpa_OECJ         = v_INTM_TE_OECJ
      where  orpa_OrPa    =  p_OrPa
      and    orpa_VigOrPa =  p_VigOrpa
      and    orpa_Cias    =  p_Cias;
      --
    end if;
    --
  exception
    --
    when e_pgpr_1 then
      raise_application_error( -20639, 'CP_TPGPR(Ordenados por Cheque): ' || v_Error );
    when e_pgpr_2 then
      raise_application_error( -20640, 'CP_TPGPR(Ordenados por Nombre): ' || v_Error );
    when e_pgpr_3 then
      raise_application_error( -20641, 'CP_TPGPR(Ordenados por Nit): ' || v_Error );
    when others then
      raise_application_error( -20642, 'GE_INFA.Car_CXP_PGPR: ' || sqlerrm );
    --
  end Car_Cxp_PgPr;
  --
  --
  --
  procedure CAR_ORPV ( p_Infa             varchar2,
                       p_Periodo          integer,
                       p_Numero           varchar2,
                       p_cias             integer,
                       p_Fecha            date,
                       p_Usua_Gene        varchar2,
                       p_Vigorpa          integer,
                       p_Orpa             integer,
                       p_auxi             integer,
                       p_tpmv             integer,
                       p_ValBruto         number,
                       p_ValNeto          number,
                       p_rengln           integer,
                       p_Agr_CXP          varchar2,
                       p_pref             varchar2,             -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
                       p_nrodoc           varchar2              -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
                         ) is
    --
    -- Registro de Cambios
    -- ===================
    -- Cambio Realizo       Fecha   Solicitud   Cliente   Descripcion del Cambio
    -- ==================== ======= =========== ========= =========================================================================
    -- 1.   Ovco          23/08/2002  605      UNICALDAS Adicion EtCt de Empresa a Tabla cp_torpv.
    --
    -- 2.  Andres Herrera  23/12/2002  979      E. V.     Asignacion del campo orpv_mayo_pasivo.
    --
    -- 3. Almoto - 26 febrero 2003 ( UNAL ) - Solicitud 1138.
    --    . Cambio en asignacion del mayor Pasivo, cuando la cuenta INPA_CXP_MAYO esta parametrizada.
    --
    -- 4. Almoto - 11 septiembre 2003 - Solicitud 1826
    --    . Se deja nula la cuenta mayor pasivo si no se trata de una Base.
    --
    -- 5. Geovanni 11 Marzo de 2004 -- Solicitud 2256
    --    . Se deja nula la cuenta mayor pasivo si no se trata de un tipo de liquidacion B o P
    --
    -- 6. Almoto - 2 septiembe 2005 - Solicitud 5434
    --    . Se modifica sentencia de insercion a la tabla CP_TORPV, para tener en cuenta la
    --      columna ORPV_ORPV (llave de la tabla).
    --
    -- 7. jcrubiano. 3/10/2011 se modifica para que la base gravable de los conceptos sea la
    --               que se env�e en el archivo
    --
    v_mayo            ge_tmayor.mayo_mayo%type;
    v_mayo_pasivo     ge_tmayor.mayo_mayo%type;
    v_valor_desc      cp_torpv.orpv_vpasivo%type;
    v_causa_pasivo    cp_ttpmv.tpmv_pasivo%type;
    v_etct            ge_tcias.cias_etct%type;            -- (01)
    --
    cursor c_etct is
      select cias_etct                    -- (01)
      from   ge_tcias                     -- (01)
      where  cias_cias = p_cias;          -- (01)
    --
    cursor c_orpv is
      select intm_tporan, intm_mayo_c,  intm_mayo_P,
             intm_cpto_liq_base,                               -- inc.16266
      --     intm_tpliq,  intm_rete,   sum(intm_valor) intm_valor, -- Antes de 9289
             intm_tpliq,  intm_rete,   intm_aica, sum(intm_valor) intm_valor, sum(INTM_INCO_BASE_VALOR) intm_valorvb -- Coldex 9289    --   1012484.  ovaceres.  01/03/2012
      from   ge_tintm
      where  intm_cxp_auxi = p_auxi
      and    intm_cxp_tpmv = p_tpmv
      and    intm_numero   = p_Numero
      and    intm_fecmov   = p_Periodo
      and    intm_cias     = p_Cias
      and    intm_rengln   = decode(p_Agr_cxp, 'S', intm_rengln, 'N', p_Rengln)  ---soli 5054
      and    nvl(intm_tpliq,'X') not in ('I','X','N')
      and    nvl(intm_pref, '&&' ) = nvl( p_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
      and    nvl( intm_nrodoc, '&&' ) =  nvl( p_nrodoc, '&&'  ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
      group by intm_tporan, intm_mayo_c, intm_mayo_P,
               intm_cpto_liq_base,                               -- inc.16266
               intm_tpliq,  intm_rete, intm_aica;                               --   1012484.  ovaceres.  01/03/2012
    --   inicio  1012484.  ovaceres.  01/03/2012
    cursor c_dere  ( pc_etct    integer,   pc_dere    varchar2 ) is select dere_clase
                     from ge_tdere
                     where dere_etct = pc_etct
                     and   dere_rete = pc_dere;
    --
    v_tpvl          cp_torpv.orpv_tpvl%type;
    v_clase         ge_tdere.dere_clase%type;
    v_tpliq         ge_tacre.acre_tpliq%type;
    --   fin 1012484.  ovaceres.  01/03/2012
  BEGIN
    --
    --  (1) Asignacion de La Estructura de Cuentas de la Empresa a la Variable v_etct
    --
    open  c_etct;                        -- (01)
    fetch c_etct into v_etct;            -- (01)
    close c_etct;                        -- (01)
    --
    sf_pins_error('CAR_ORPV. Cias='||p_Cias || ' VigOrPa='||p_VigOrPa || ' OrPa='||p_OrPa || ' TpMv='||p_TpMv || ' Auxi='||p_Auxi || ' Numero='||p_Numero || ' Agr_CXP='||p_Agr_CXP||' Periodo='||p_Periodo||' Pref='||p_pref||' Nrodoc='||p_nrodoc);
    --
    for i in c_orpv loop
      --   inicio  1012484.  ovaceres.  01/03/2012
      v_clase := null;
      --
      open c_dere ( v_etct, i.intm_rete );
        fetch c_dere into v_clase;
      close c_dere;
      --
      if ( v_clase = 'IK' ) then
        v_tpvl := i.intm_aica;
      else
        v_tpvl := i.intm_rete;
      end if;
      /* -- inicio antes de 1012776
      -- inicio 1012484.  ovcaceres.  02/03/2012
      if ( i.intm_tpliq = 'D' ) then
        v_tpliq := 'A';
      else
        v_tpliq := i.intm_tpliq;
      end if;
      -- fin 1012484.  ovcaceres.  02/03/2012
      */ -- fin antes de 1012776
      --   fin  1012484.  ovaceres.  01/03/2012
      -- Define Cuenta Mayor Pasivo.
      --
      begin
        select tpmv_pasivo
        into   v_causa_pasivo
        from   cp_ttpmv
        where  tpmv_tpmv = p_tpmv;
      exception
         when others then
           v_causa_pasivo := 'P';
      end;
      --
      dbms_output.put_line('CAR_ORPV.  Pasivo='||v_causa_Pasivo );
      --
      --sf_pins_error('Cias='||p_Cias || ' VigOrPa='||p_VigOrPa || ' OrPa='||p_OrPa || ' TpMv='||p_TpMv || ' Auxi='||p_Auxi || ' Numero='||p_Numero ||
      --              ' Agr_CXP='||p_Agr_CXP||' i.intm_mayo_C:'||i.intm_mayo_C||' i.intm_mayo_P:'||i.intm_mayo_P);
      if ( v_causa_pasivo = 'P' ) then
         --
         v_mayo        := nvl(i.intm_mayo_c, i.intm_mayo_P);
         --
         if ( i.intm_mayo_C is not null ) then              ----  Soli_1138
            v_mayo_Pasivo := i.intm_mayo_C;                  ----  Soli_1138
         -- inicio inc.14217
         elsif ( i.intm_mayo_P is not null ) then
            v_mayo_Pasivo := i.intm_mayo_P;
         -- fin inc.14217            
         else
           v_mayo_pasivo := Trae_Mayo_Pasivo_Neto( p_cias, p_Infa, p_Periodo, p_Numero );
         end if;
         --
         v_mayo_pasivo := nvl(v_mayo_pasivo, nvl(i.intm_mayo_c, i.intm_mayo_P));  -- ahm esta asignacion es nueva , revisar (02)
         --
      else
         v_mayo        := nvl(i.intm_mayo_P, i.intm_mayo_c);
         v_mayo_pasivo := nvl(i.intm_mayo_P, i.intm_mayo_c);
      end if;
      --
      -- DEFINE EL VALOR DE LOS DESCUENTOS.
      --
      if ( i.intm_tpliq = 'D' ) then
         v_valor_desc  := nvl(v_valor_desc,0) + i.intm_valor;
      end if;
      --
      if ( i.intm_tpliq not in  ('B','P') ) then     -- Soli_1826   --Soli 2256
         v_mayo_pasivo := null;            -- Soli_1826
      end if;                              -- Soli_1826
      --
      update cp_torpv
      set    orpv_valor       = orpv_valor + i.intm_valor,
             orpv_vpasivo     = orpv_vpasivo + i.intm_valor,
             orpv_mayo_pasivo = v_mayo_pasivo
      where  orpv_cias    = p_cias
      and    orpv_vigorpa = p_vigorpa
      and    orpv_orpa    = p_orpa
      and    orpv_tpliq   = i.intm_tpliq
      and    orpv_tpvl    = i.intm_rete
      and    nvl(orpv_cpto_liq_base,'z') = nvl(i.intm_cpto_liq_base,'z') -- inc.16266
      and    orpv_acta    = -99;
      --
      /*
      sf_pins_error('CAR_ORPV. 1 Pasivo='||v_causa_Pasivo || ' Regs='||sql%RowCount || ' Valor='||i.intm_Valor || ' TpLiq='||i.intm_TpLiq ||
                           ' Rete='||i.intm_Rete || ' Mayo_Pasivo='||v_mayo_Pasivo||' intm_cpto_liq_base='||
                           --i.intm_cpto_liq_base||
                           ' p_orpa='||p_orpa);
      */
      --
      if (sql%rowcount = 0) then
        --
        begin
    /*    
    sf_pins_error('CAR_ORPV. 2 Pasivo='||v_causa_Pasivo || ' Regs='||sql%RowCount || ' Valor='||i.intm_Valor || ' TpLiq='||i.intm_TpLiq ||
                           ' Rete='||i.intm_Rete || ' Mayo_Pasivo='||v_mayo_Pasivo||' intm_cpto_liq_base='||
                           --i.intm_cpto_liq_base||
                           ' p_orpa='||p_orpa);
      sf_pins_error('CAR_ORPV. 3 p_cias='||p_cias||' p_vigorpa'||p_vigorpa||' p_orpa='||p_orpa||' intm_tpliq='||i.intm_tpliq||' v_tpvl='||v_tpvl);
    */  
          insert into cp_torpv
            (orpv_cias,    orpv_vigorpa,      orpv_orpa,
             orpv_tpvl,    orpv_valor,        orpv_tpliq,
             orpv_mayo,    orpv_mayo_pasivo,  orpv_acta,
             orpv_vpasivo, orpv_auxi,         orpv_baseg,
             orpv_etct,    orpv_OrPv,                          -- Soli_5434 (Se incluye columna ORPV_ORPV)
             orpv_cpto_liq_base                                -- inc.16266
            ) 
          values
            (p_cias,       p_vigorpa,         p_orpa,
           --v_tpvl /*i.intm_rete*/,  i.intm_valor,      v_tpliq/*i.intm_tpliq*/,           --   1012484.  ovaceres.  01/03/2012 -- antes de 1012776
             v_tpvl /*i.intm_rete*/,  i.intm_valor,      /*v_tpliq*/i.intm_tpliq,           --   1012776
             v_mayo,       v_mayo_pasivo,     -99,
           --i.intm_valor, p_auxi,            p_valbruto, -- Antes de 9289
             i.intm_valor, p_auxi, NVL(i.intm_valorvb,p_valbruto ), -- Coldex 9289
             v_etct,       cp_sorpv.NextVal,                   -- Soli_5434 (Se incluye columna ORPV_ORPV)
             i.intm_cpto_liq_base                              -- inc.16266
            ); 
        exception
            when others then
              raise_application_error( -20638, 'CP_TORPV: ' || sqlerrm );
        end;
        --
      end if;
      --
    end loop c_orpv;
    --
    update cp_torpv
    set    orpv_vpasivo = orpv_vpasivo - nvl(v_valor_desc,0)
    where  orpv_cias    = p_cias
    and    orpv_vigorpa = p_vigorpa
    and    orpv_orpa    = p_orpa
    and    orpv_tpliq   = 'B'
    and    orpv_mayo_pasivo is not null
    and    orpv_valor   in (select max(orpv_valor)
                            from   cp_torpv
                            where  orpv_cias    = p_cias
                            and    orpv_vigorpa = p_vigorpa
                            and    orpv_orpa    = p_orpa
                            and    orpv_tpliq   = 'B' );
    --
    -- inicio inc.16491
    update cp_torpv
    set    orpv_tpliq = 'V'
    where  orpv_cias    = p_cias
    and    orpv_vigorpa = p_vigorpa
    and    orpv_orpa    = p_orpa
    and    orpv_tpliq   = 'B'
    and    orpv_tpvl in ( select dere_rete
                          from   ge_tdere
                          where  dere_etct  = v_etct
                          and    dere_tipo  = 'V'
                          and    dere_clase = 'IV'
                        );
    -- fin inc.16491
    -- COMMIT;              -- 1012954.  ovcaceres.  16/03/2012
    --
  end CAR_ORPV;
  --
  --
  -----------------------------------------------------------------------------------------------------
  Procedure Car_Tes ( p_Infa             varchar2,
                      p_inrq             integer,
                      p_Periodo          integer,
                      p_Numero           varchar2,
                      p_cias             integer,
                      p_Fecha            date,
                      p_Usua_Gene          varchar2,
                      p_py_EtPy          integer,
                      p_py_Proy          varchar2,
                      p_py_EnAp          integer     ) is
    --
    --
    -- Modificaciones:
    --  1. Almoto - 18 junio 2003 ( ITC ) - Solicitud 1611
    --     . Al validar cuentas bancarias se tiene en cuenta que esten A-ACTIVAS
    --
    --  2. Almoto - 25 julio 2003 - Solicitud 1722
    --     . Cursor TES_SC: se agregaron columnas intm_Dependencia, intm_PgPr.
    --       Cursor C_TEMP, se agregaron columnas ints_Dependencia, ints_PgPr.
    --       En las dos sentencias de insercion a la tabla TE_TMVTE, se agrego la columna
    --       MVTE_PGPR.  Lo mismo se hizo en la sentencia de actualizacion sobre te_tmvte.
    --
    v_ints_cias_ant    ge_tints.ints_cias%type;
    v_ints_tpco_ant    ge_tints.ints_tpco%type;
    v_ints_nrocom_ant  ge_tints.ints_nrocom%type;
    v_ints_fecmov_ant  ge_tints.ints_fecmov%type;
    v_signo            number;
    v_tpco             sc_tctco.ctco_tpco%type;
    v_tpcoe            sc_tctco.ctco_tpcog%type;
    v_period           sc_tctco.ctco_fecmov%type;
    v_cias_nivel       ge_tcias.cias_nivel%type;
    v_cias_etct        ge_tcias.cias_etct%type;
    v_cias_etcf        ge_tcias.cias_etcf%type;
    v_nrocom           sc_tctco.ctco_nrocom%type;
    v_fecmovg          sc_tctco.ctco_fecmovg%type;
    v_descri           sc_tmvco.mvco_descri%type;
    v_mayo             sc_tmvco.mvco_mayo%type;
    v_mayo_opc1        sc_tmvco.mvco_mayo%type;
    v_mayo_opc2        sc_tmvco.mvco_mayo%type;
    v_tporan           sc_tmvco.mvco_tporan%type;
    v_tpoNat           te_tmvte.mvte_tporan%type;
    v_auxi             sc_tmvco.mvco_auxi%type;
    v_valor            sc_tmvco.mvco_mtoren%type;
    v_rengln           number;
    v_rengln2          number;
    v_rengln_tmp       number;
    v_tesor_rengln     number;
    v_enti             sc_tmvco.mvco_auxi%type;
    v_mayo_enti        sc_tmvco.mvco_mayo%type;
    v_vigorpa          cp_torpa.orpa_vigorpa%type;
    v_orpa             cp_torpa.orpa_orpa%type;
    v_nit              ge_tauxil.auxi_nit%type;
    v_fecha            date;
    v_desc             sc_tmvco.mvco_mtoren%type;
    ps_TpoNat          te_ttpmv.tpmv_tporan%type;
    ps_GenMvP          te_ttpmv.tpmv_genmvp%type;
    v_vigorpa_ant      cp_torpa.orpa_vigorpa%type:=-1;
    v_orpa_ant         cp_torpa.orpa_orpa%type:=-1;
    v_tot_egreso       te_tmvte.mvte_valor%type;
    v_valneto          cp_torpa.orpa_valneto%type;
    v_estado           varchar2(1);
    v_error            varchar2(500);
    v_auxi_Agr         integer;
    --
    v_Periodo_Proc integer;    -- Soli_5213
    --
    cursor c_tpco is
    select distinct intm_te_tpco, intm_te_tpcoe, intm_fecha, intm_auxi_Agr,
    intm_pref, intm_nrodoc --1011
    from   ge_tintm
    where  intm_fecmov     =  p_Periodo
    and    intm_numero     =  p_Numero
    and    intm_cias       =  p_Cias
    and    intm_tpliq      not in ('I')                                          --   Cambio Teletulua
    and    intm_te_tpmv    is not null
    and    intm_te_tpco is not null
    and    intm_ncuenta    is not null;
    --
    cursor tes_sc is
    select intm_fecha,       intm_tpco,    intm_nrocom,
           intm_te_tpmv,     intm_te_auxi, intm_te_etcf,
           intm_te_fluj,     intm_te_etoe, intm_te_oecj,
           intm_Dependencia, intm_PgPr,                             -- Soli_1722
           intm_fmpg,                                               --COMO058
           intm_pref,        intm_nrodoc,  intm_fecdoc,             -- COMO058
           sum(intm_valor)   intm_valor,
           sum(intm_inco_base_valor) intm_inco_base_valor,
           sum(intm_vlrmone) intm_vlrmone, sum(intm_valdoc) intm_valdoc  -- COMO058
      from ge_tintm
     where intm_fecmov      = p_Periodo
       and intm_numero      = p_Numero
       and intm_cias        = p_Cias
       and intm_tpliq       not in ('I')                                         --   Cambio Teletulua
       and intm_te_tpmv     is not null
       and intm_te_tpco  is null
     group by intm_fecha,      intm_tpco,    intm_nrocom,
             intm_te_tpmv,     intm_te_auxi, intm_te_etcf,
             intm_te_fluj,     intm_te_etoe, intm_te_oecj,
             intm_Dependencia, intm_PgPr ,                         -- Soli_1722
             intm_fmpg,                                          -- COMO058
             intm_pref,        intm_nrodoc,  intm_fecdoc         -- COMO058
             ;
    --
    cursor c_temp is
    select ints_cias,        ints_tpco,          ints_nrocom,       ints_fecmov,
           ints_mayo,        ints_enti,          ints_tpmv,         ints_cheque,
           ints_benefi,      ints_tporan,        ints_fecent,
           ints_fecpago,     ints_orpa,          ints_vigorpa,
           ints_feccre,      ints_fecmod,        ints_user,         ints_descri,
           ints_fecdoc,      ints_status,
           ints_etcf,        ints_fluj,          ints_etoe,         ints_oecj,
           ints_Dependencia, ints_PgPr,                                              -- Soli_1722
           ints_fmpg,                                                                 -- COMO058
           ints_pref,        ints_nrodoc,        ints_fac_fecdoc,                         -- COMO058
           sum(ints_valor)   ints_valor,
           sum(ints_vlrmone) ints_vlrmone,       sum(ints_valdoc)   ints_valdoc       -- COMO058
      from ge_tints
     where ints_infa   = p_Infa
       and ints_numero = p_Numero
       and ints_tpco   = v_tpco
       and ints_nrocom = v_nrocom
     group by ints_cias,        ints_tpco,          ints_nrocom,       ints_fecmov,
              ints_mayo,        ints_enti,          ints_tpmv,         ints_cheque,
              ints_benefi,      ints_tporan,        ints_fecent,
              ints_fecpago,     ints_orpa,          ints_vigorpa,
              ints_feccre,      ints_fecmod,        ints_user,         ints_descri,
              ints_fecdoc,      ints_status,
              ints_etcf,        ints_fluj,          ints_etoe,         ints_oecj,
              ints_Dependencia, ints_PgPr,
              ints_fmpg,         --COMO058
              ints_pref,        ints_nrodoc,        ints_fac_fecdoc                       -- COMO058
     order by ints_cias, ints_tpco, ints_nrocom, ints_fecmov;
    --
    -- Inicia COMO058
    cursor c_enti (pc_enti    integer) is
      select enti_mone
        from ge_tenti
       where enti_auxi = pc_enti;
    --
    v_mone                    ge_tenti.enti_mone%type;
    v_valor_orig            sc_tmvco.mvco_mtoren%type;
    v_mone_apl            number;
    -- Termina COMO058
    --
  BEGIN
    --
    v_Rengln_tmp := 0;
    --
    --
    -- Ini.Soli_5213
    --
    if ( p_Fecha is not null ) then
      v_Periodo_Proc := to_char(p_Fecha, 'yyyymm');
    else
      v_Periodo_Proc := null;
    end if;
    --
    -- Fin.Soli_5213
    --
    Trae_Dat_Cia ( p_cias, p_inrq, v_cias_nivel, v_cias_etct, v_cias_etcf );  -- Soli 5584  18-ene-2006
    --
    for i in c_tpco loop
      --
      v_tpco       := i.intm_te_tpco;
      v_tpcoe      := i.intm_te_tpcoe;
      v_period     := nvl(v_Periodo_Proc, p_Periodo);
      v_fecha      := nvl(p_Fecha, to_date(i.intm_fecha,'dd-mm-yyyy'));
      --  inicio vers.1011.gap.-.14029. lhernandez.  09/05/2012
      				if ( i.intm_pref||i.intm_nrodoc is not null ) then
        			v_fecha   := to_date(i.intm_fecha,'dd-mm-yyyy');
      				end if;
      --  fin vers.1011.gap.-.14029. lhernandez.  09/05/2012
      v_auxi_Agr   := i.intm_auxi_Agr;
      --
      -- Trae_Dat_Cia ( p_cias, p_inrq, v_cias_nivel, v_cias_etct, v_cias_etcf );  -- Soli 5584 18-ene-2006
      --
      Numerar_Comp ( p_cias, v_TpCo, v_Period, v_nrocom, v_fecmovg );
      --
      --
      insert into sc_tctco-- no
      (
         CTCO_CIAS,        CTCO_TPCO,    CTCO_NROCOM,
         CTCO_FECCOM,      CTCO_FECMOV,  CTCO_FECCRE,
         CTCO_USER,        CTCO_ULFMOD,  CTCO_NIVEL,
         CTCO_FECMOVG,     CTCO_TPCOG,   CTCO_NROCOMG,
         CTCO_PY_CIAS,     CTCO_PY_ETPY, CTCO_PY_PROY,
         CTCO_PY_ENAP,
         CTCO_INAR_NUMERO  -- SOLI 5584
      )
      values
      (
         p_Cias,            v_TpCo,        v_nrocom,
         v_fecha,           v_period,      sysdate,
         p_Usua_Gene,       sysdate,       v_cias_nivel,
         v_fecmovg,         v_tpcoe,       v_nrocom,
         p_Cias,            p_py_etpy,     p_py_proy,
         p_py_enap,
         p_numero   -- Soli 5584
      );
      --
      -- commit; -- antes de 13712
      --
      -- CARGA TESORERIA DE CONCEPTOS NO NETOS.
      --
      dbms_output.put_line('Car_Tes_No_Neto(antes). Numero='||p_Numero || ' Ren='||v_Rengln || ' Ren2='||v_Rengln2);
      --
      Car_Tes_No_Neto( p_Infa, p_Periodo, p_Numero, p_Cias,       p_Fecha,     p_Usua_Gene,
                       v_TpCo, v_TpCoE,   v_NroCom, v_auxi_Agr,   v_cias_etct, v_Rengln,      v_Rengln2 );
      --
      -- CARGA TESORERIA DE CONCEPTOS NETOS.
      --
      dbms_output.put_line('Car_Tes_Neto(antes). Numero='||p_Numero || ' Ren='||v_Rengln || ' Ren2='||v_Rengln2);
      --
      Car_Tes_Neto( p_Infa, p_Periodo, p_Numero, p_Cias,       p_Fecha,     p_Usua_Gene,
                    v_TpCo, v_TpCoE,   v_NroCom, v_auxi_Agr,   v_cias_etct, v_Rengln,      v_Rengln2 );
      --
      dbms_output.put_line('Car_Tes_Neto(despues). Numero='||p_Numero || ' Ren='||v_Rengln || ' Ren2='||v_Rengln2);
      --
      Begin
        --
        update ge_tintm
        set    intm_te_nrocom = v_nrocom
        where  intm_fecmov          =  p_Periodo
        and    intm_numero          =  p_Numero
        and    intm_cias            =  p_Cias
        and    intm_te_tpco         =  v_tpco
        and    intm_te_tpcoe        =  v_tpcoe
        and    nvl(intm_Auxi_Agr,1) =  nvl(v_auxi_Agr,1)
        and    intm_tpliq           in ('P','B','N')
        and    intm_ncuenta         is not null;
        --
        -- commit; -- antes de 13712
        --
      end;
      --
      -- CARGA DE TABLA TEMPORAL
      --
      for l in c_temp loop
        --
        if ( (nvl(v_ints_cias_ant,0) <> l.ints_cias ) or
             (nvl(v_ints_tpco_ant,0) <> l.ints_tpco ) or
            (nvl(v_ints_nrocom_ant,0) <> l.ints_nrocom ) or
            (nvl(v_ints_fecmov_ant,0) <> l.ints_fecmov ) ) then
          --
          v_tesor_rengln := 0;
          --
        end if;
        --
        v_tesor_rengln := nvl(v_tesor_rengln,0)+1;
        --
        -- Inicia COMO058
        v_mone := null;
        --
        open c_enti (  l.ints_enti );
          fetch c_enti into v_mone;
        close c_enti;
        --
        if ( nvl( l.ints_vlrmone,0 ) <> 0 ) then
            v_mone_apl  := l.ints_valor  / l.ints_vlrmone;
        else
           v_mone_apl  := null;
        end if;
        -- Termina COMO058
        --
        begin
          --
          insert into te_tmvte
          (
             MVTE_CIAS,        MVTE_TPCO,         MVTE_NROCOM,    MVTE_FECMOV,
             MVTE_MAYO,        MVTE_ENTI,         MVTE_TPMV,      MVTE_CHEQUE,
             MVTE_BENEFI,      MVTE_TPORAN,       MVTE_VALOR,     MVTE_FECENT,
             MVTE_FECPAGO,     MVTE_ORPA,         MVTE_VIGORPA,
             MVTE_FECCRE,      MVTE_FECMOD,       MVTE_USER,      MVTE_DESCRI,
             MVTE_FECDOC,      MVTE_RENGLN,       MVTE_STATUS,
             MVTE_ETCF,        MVTE_FLUJ,         MVTE_ETOE,      MVTE_OECJ,
             MVTE_CIAS_DEST,                                              -- CAMBIO TELETULUA
             MVTE_PGPR,
             MVTE_INAR_NUMERO, -- SOLI 5584
             MVTE_FPAG,
             MVTE_VOPER_MORIG, MVTE_INAR_PREF,   MVTE_INAR_NRODOC,                   -- COMO058
             MVTE_INAR_FECDOC, MVTE_INAR_VALDOC, MVTE_MONE,       MVTE_VMONE_APL     -- COMO058

          )                                                  -- Soli_1722
          values
          (
             l.ints_CIAS,       l.ints_TPCO,       l.ints_NROCOM,    l.ints_FECMOV,
             l.ints_MAYO,       l.ints_ENTI,       l.ints_TPMV,      l.ints_CHEQUE,
             l.ints_BENEFI,     l.ints_TPORAN,     l.ints_VALOR,     l.ints_FECENT,
             l.ints_FECPAGO,    l.ints_ORPA,       l.ints_VIGORPA,
             l.ints_FECCRE,     l.ints_FECMOD,     l.ints_USER,      l.ints_DESCRI,
             l.ints_FECDOC,     v_tesor_rengln,    'I',
             l.ints_etcf,       l.ints_fluj,       l.ints_etoe,      l.ints_oecj,
             l.ints_Cias,                                           -- Cambio Teletulua
             l.ints_PgPr,                                           -- Soli 1722
             p_numero,                                              -- Soli 5584
             l.ints_fmpg,                                           -- COMO058
             l.ints_vlrmone,    l.ints_pref,       l.ints_nrodoc,   l.ints_fecdoc,     -- COMO058
             l.ints_valdoc,     v_mone,            v_mone_apl                          -- COMO058
            );
        --
        exception
          when others then
               raise_application_error( -20671, 'GE_TINTS: ' || sqlerrm );
        end;
        --
      --commit; -- antes de 13712
        --
        v_ints_cias_ant := l.ints_cias;
        v_ints_tpco_ant := l.ints_tpco;
        v_ints_nrocom_ant := l.ints_nrocom;
        v_ints_fecmov_ant := l.ints_fecmov;
        --
        -- ACTUALIZA ESTADO DE ORDENES DE PAGO.
        --
        if (( nvl(v_vigorpa_ant,1) <> l.ints_vigorpa ) or
           ( nvl(v_orpa_ant,1)    <> l.ints_orpa    )) then
          --
          begin
            select orpa_valneto
            into   v_valneto
            from   cp_torpa
            where  orpa_cias    = p_cias
            and    orpa_vigorpa = l.ints_vigorpa
            and    orpa_orpa    = l.ints_orpa;
          exception
            when others then
              v_valneto := 0;
          end;
          --
          begin
            select abs(sum(ints_valor))
            into   v_tot_egreso
            from   ge_tints
            where  ints_infa    = p_Infa
            and    ints_numero  = p_Numero
            and    ints_vigorpa = l.ints_vigorpa
            and    ints_orpa    = l.ints_orpa;
          exception
            when others then
             v_tot_egreso := 0;
          end;
          --
          if ( v_valneto = v_tot_egreso ) then
            v_estado := 'S';
          else
            v_estado := 'P';
          end if;
          --
          update cp_torpa
          set    orpa_pago    = v_estado,
                 orpa_proceso = 'INTERFASE-PAGO'
          where  orpa_cias    = p_cias
          and    orpa_vigorpa = l.ints_vigorpa
          and    orpa_orpa    = l.ints_orpa;
          --
          v_vigorpa_ant := l.ints_vigorpa;
          v_orpa_ant    := l.ints_orpa;
        --
        end if;
        --
        -- ACTUALIZA CHEQUERAS
        --
        if ( l.ints_cheque is not null ) then
          --
          --
          begin
            select auxi_nit
            into   v_nit
            from   ge_tauxil
            where  auxi_auxi = l.ints_benefi;
          exception
            when no_data_found then
              raise_application_error( -20669, 'Codigo Auxiliar NO EXISTE : ' || l.ints_Benefi );
            when others then
              raise_application_error( -20670, 'GE_TAUXIL: ' || sqlerrm );
          end;
          --
          v_fecha   := nvl( p_Fecha, l.ints_fecdoc );
          --
          --
          begin
            --
            update te_tcheq
            set    cheq_valor = cheq_valor+l.ints_valor
            where  cheq_enti  = l.ints_enti
            and    cheq_cheque= l.ints_cheque
            and    cheq_movi  = 'G';
            --
            if (sql%rowcount = 0) then
              --
              --
              begin
                --
                insert into te_tcheq
                (
                   CHEQ_ENTI,       CHEQ_CHEQUE,  CHEQ_MOVI,
                   CHEQ_FECHA,      CHEQ_USER,    CHEQ_VALOR,
                   CHEQ_BENAUX,     CHEQ_BENNIT,  CHEQ_BENDES,
                   CHEQ_FECCOM,
                   CHEQ_INAR_NUMERO  -- Soli 5584
                )
                values
                (
                   l.ints_enti,    l.ints_cheque,   'G',
                   l.ints_fecdoc,  p_Usua_Gene,     l.ints_valor,
                   l.ints_benefi,  v_nit,           null,
                   l.ints_fecdoc,
                   p_numero   -- Soli 5584
                );
                --
                exception
                  when others then
                    raise_application_error( -20613, 'TE_TCHEQ : Enti=' || l.ints_enti || ' Cheque='||l.ints_cheque || ' : ' || sqlerrm );
                --
              end;
              --
            end if;
            --
          --commit; -- antes de 13712
            --
          end;
          --
        end if;
        --
      --commit; -- antes de 13712
       --
      end loop c_temp;
     --
    end loop c_tpco;
    --
    -- CARGA MOVIMIENTOS DE PAGO EN PRESUPUESTO.
    --
    Car_Ppto_Tesor ( p_Infa, p_Periodo, p_Numero, p_Cias, p_Fecha, p_Usua_Gene );
    --
    v_tesor_rengln := 0;
    --
    for l in tes_sc loop
      --
      -- BUSCA CTA.MAYOR DE LA ENTIDAD
      --
      Begin
        select enti_mayo
          into v_mayo
          from ge_tenti
         where enti_auxi   = l.intm_te_auxi
           and nvl(enti_Status, 'A') = 'A'   --- Soli_1611
           and enti_cias+0 = p_cias;
      exception
        when others then
          v_mayo := null;
      End;
      --
      if ( v_mayo is not null ) then
        --
        -- Trae_Dat_Cia( p_cias, p_inrq, v_cias_nivel, v_cias_etct, v_cias_Etcf);  -- Soli 5584 18-ene-2006
        --
        Trae_te_TpMv( l.intm_te_tpmv, v_TpoNat, ps_GenMvP );
        --
        If v_tpoNat = 'E' then
          v_signo := -1;
        else
          v_signo := 1;
        end if;
        --
        v_valor      := l.intm_valor;
        v_valor_orig := l.intm_vlrmone;     -- COMO058
        --
        begin -- Cambio (1)
          v_fecha   := nvl( p_Fecha, to_date(l.intm_fecha,'dd-mm-yyyy'));
        exception
          when others then
            raise_application_error( -20614, 'Error con Fecha (dd-mm-yyyy) : ' || nvl(p_Fecha, l.intm_fecha) );
        end;
        --
        begin
           --
          update te_tmvte
             set mvte_valor       = (abs(mvte_valor)+abs(v_valor))*v_signo,
                 mvte_voper_morig = (abs(mvte_voper_morig)+abs(v_valor_orig))*v_signo    -- COMO058
           where mvte_cias          =  p_cias
             and mvte_tpco          =  l.intm_tpco
             and mvte_nrocom        =  l.intm_nrocom
             and mvte_fecmov        =  nvl(v_Periodo_Proc, p_Periodo)
             and mvte_mayo          =  v_mayo
             and mvte_enti+0        =  l.intm_te_auxi
             and mvte_tpmv          =  l.intm_te_tpmv
             and mvte_benefi        =  l.intm_te_auxi
             and nvl(mvte_fluj,'*') =  nvl(l.intm_te_fluj,'*')
             and nvl(mvte_oecj,'*') =  nvl(l.intm_te_oecj,'*')
             and nvl(mvte_PgPr, 0)  =  nvl(l.intm_PgPr, 0);         --- Soli_1722
          --
          If (sql%rowcount = 0) then
            --
            v_tesor_rengln := nvl(v_tesor_rengln,0)+1;
            --
            -- Inicia COMO058
            v_mone := null;
            --
            open c_enti (  l.intm_te_auxi );
              fetch c_enti into v_mone;
            close c_enti;
            --
            if ( nvl(v_valor_orig,0 ) <> 0 ) then
                v_mone_apl  := v_valor / v_valor_orig;
              else
                v_mone_apl  := null;
            end if;
            -- Termina COMO058
            --
            begin
              insert into Te_tMvTe
              (
                   MVTE_CIAS,         MVTE_TPCO,        MVTE_NROCOM,  MVTE_FECMOV,
                   MVTE_MAYO,         MVTE_ENTI,        MVTE_TPMV,
                   MVTE_BENEFI,       MVTE_TPORAN,      MVTE_VALOR,   MVTE_FECENT,
                   MVTE_FECPAGO,
                   MVTE_FECCRE,       MVTE_FECMOD,      MVTE_USER,    MVTE_DESCRI,
                   MVTE_FECDOC,       MVTE_RENGLN,      MVTE_STATUS,
                   MVTE_ETCF,         MVTE_FLUJ,        MVTE_ETOE,    MVTE_OECJ,
                   MVTE_CIAS_DEST,                             --   CAMBIO TELETULUA
                   MVTE_PGPR,                                  --  SOLI 1722
                   MVTE_INAR_NUMERO,                            --  SOLI 5584
                   MVTE_FPAG,      --COMO058
                   MVTE_VOPER_MORIG,  MVTE_INAR_PREF,   MVTE_INAR_NRODOC,               -- COMO058
                   MVTE_INAR_FECDOC,  MVTE_INAR_VALDOC, MVTE_MONE,    MVTE_VMONE_APL    -- COMO058

              )
              values
              (
                   p_cias,             l.intm_tpco,       l.intm_nrocom,     nvl(v_Periodo_Proc, p_Periodo),
                   v_mayo,             l.intm_te_auxi,    l.intm_te_tpmv,
                   l.intm_te_auxi,     v_TpoNat,          v_valor, v_fecha,
                   v_fecha,
                   sysdate,            sysdate,           p_Usua_Gene,       'EGRESO INTERFASE '||p_Numero,
                   v_fecha,            v_tesor_rengln,    'I',
                   l.intm_te_etcf,     l.intm_te_fluj,    l.intm_te_etoe,    l.intm_te_oecj,
                   p_cias,                                             --   Cambio Teletulua
                   l.intm_PgPr,                                        -- Soli 5584
                   p_numero,                                            -- Soli 5584
                   l.intm_fmpg,                                          -- COMO058
                   v_valor_orig,       l.intm_pref,       l.intm_nrodoc,     l.intm_fecdoc,   -- COMO058
                   l.intm_valdoc,      v_mone,            v_mone_apl                          -- COMO058
              );
            exception
              when others then
                   raise_application_error( -20615, 'TE_TMVTE : ' || sqlerrm );
            end;
            --
          end if;
          --
        --commit; -- antes de 13712
          --
        end;
        --
      end if;
      --
    End Loop;
    --
  End Car_Tes;
  --
  --
  -----------------------------------------------------------------------------------------------------
  Procedure Car_Ppto ( p_Infa             varchar2,
                       p_Periodo          integer,
                       p_Numero           varchar2,
                       p_Cias             integer,
                       p_Fecha            date,
                       p_Usua_Gene          varchar2,
                       p_py_EtPy          integer,
                       p_py_Proy          varchar2,
                       p_py_EnAp          integer     ) is
    --
    --
    v_tpdo        pp_tdocu.docu_tpdo%type;
    v_intm_fecha  ge_tintm.intm_fecha%type;
    v_intm_tpnr   ge_tintm.intm_pp_tpnr%type;
    v_valor       pp_tdocu.docu_valor%type;
    v_vigdocu     pp_tdocu.docu_vigdocu%type;
    v_observ      varchar2(2000);
    v_mes         pp_tmovi.movi_mes%type;
    v_rengln      pp_tmovi.movi_rengln%type;
    v_fecha       date;
    v_NroDoc      pp_tdocu.docu_nrodoc%type;
    v_Acta        pp_tdocu.docu_acta%type;
    v_error       varchar2(1000);
    --
    v_Periodo_Proc integer;    -- Soli_5213
    --
    Cursor docu is
      select distinct intm_pp_tpdo, intm_fecha, intm_pp_tpnr
      from   ge_tintm
      where  intm_fecmov = p_Periodo
      and    intm_numero = p_Numero
      and    intm_cias   = p_Cias
      and    intm_pp_tpdo is not null;
      --
    Cursor docu_descri is --(695)
      select intm_descri
      from   ge_tintm
      where  intm_fecmov = p_Periodo
      and    intm_numero = p_Numero
      and    intm_cias   = p_Cias
      and    intm_pp_tpdo is not null;
      --
    Cursor movi is
      select intm_pp_tpmv, intm_pp_area, intm_recu, intm_impu, intm_valor
      from   ge_tintm
      where  intm_fecmov    = p_Periodo
      and    intm_numero    = p_Numero
      and    intm_cias      = p_Cias
      and    intm_pp_tpdo      = v_tpdo
      and    intm_fecha     = v_intm_fecha
      and    intm_pp_tpnr = v_intm_tpnr
      and    intm_pp_tpmv is not null
      for update of intm_pp_nrodoc, intm_pp_acta;
      --
    Cursor c_Temp is
      select InPp_Cias,   InPp_VigDocu,  InPp_TpDo,
             InPp_NroDoc, InPp_Acta,     InPp_Vigencia,
             InPp_Mes,    InPp_TpMv,     InPp_Area,
             InPp_ReCu,   InPp_Impu,     sum(InPp_Valor) InPp_Valor
      from   Sc_tInPpto
      where  InPp_Cias    = p_Cias
      and    InPp_InFa    = p_Infa
      and    InPp_Numero  = p_Numero
      and    InPp_VigDocu = v_VigDocu
      and    InPp_TpDo    = v_TpDo
      and    InPp_NroDoc  = v_NroDoc 
      and    InPp_Acta    = v_Acta
      and    InPp_Origen = 'PPTO1'
      Group by InPp_Cias,   InPp_VigDocu,  InPp_TpDo,
             InPp_NroDoc, InPp_Acta,     InPp_Vigencia,
             InPp_Mes,    InPp_TpMv,     InPp_Area,
             InPp_ReCu,   InPp_Impu
      order by InPp_TpMv desc; -- smcalderon  1040
      --
  BEGIN
    --
    -- Ini.Soli_5213
    --
    if ( p_Fecha is not null ) then
      v_Periodo_Proc := to_char(p_Fecha, 'yyyymm');
    else
      v_Periodo_Proc := null;
    end if;
    --
    -- Fin.Soli_5213
    --
    -- (695)
    Open docu_descri;
    Fetch docu_descri Into v_observ;
    Close docu_descri;
    --
    If ( v_observ Is Null ) Then
       v_observ:= 'INTERFASE '||p_Infa||'-'||p_Numero;
    End if;
    --
    For i in docu loop
      --
      v_TpDo      := i.INTM_pp_TPDO;
      v_intm_Fecha:= i.intm_Fecha;
      v_intm_TpNr := NVL(i.INTM_PP_TPNR,'M');
      --
      -- /** CALCULA VALOR DOCUMENTO **/
      --
      begin
        --
        select nvl(sum(intm_valor*agmv_signo),0)
          into v_valor
          from ge_tintm, ge_ttpdo, pp_tagmv
         where intm_fecmov    = p_Periodo
           and intm_numero    = p_Numero
           and intm_cias      = p_Cias
           and intm_pp_tpdo      = i.intm_pp_tpdo
           and intm_fecha     = i.intm_fecha
           and intm_pp_tpnr = i.intm_pp_tpnr
           and tpdo_tpdo      = i.intm_pp_tpdo
           and tpdo_grmv      = agmv_grmv
           and agmv_tpcons    = 'A'
           and agmv_tpmv      = intm_pp_tpmv;
        --
        exception
          when others then
            v_valor := 0;
      End;
      --
      Nro_Doc_Ppto( p_Infa, p_Periodo, p_Numero, p_Cias, i.INTM_pp_TPDO, i.INTM_PP_TPNR, v_NroDoc, v_Acta );
      --
      --
      v_vigdocu := trunc(nvl( v_Periodo_Proc, p_Periodo)/100);
      v_fecha   := nvl(p_Fecha, to_date(i.intm_fecha,'dd-mm-yyyy'));
      --
      --
      begin
        insert into pp_tdocu
        (
           DOCU_CIAS,       DOCU_VIGDOCU,  DOCU_TPDO,
           DOCU_NRODOC,     DOCU_ACTA,     DOCU_FECHA,
           DOCU_AUXI,       DOCU_VALOR,    DOCU_OBSERV1,
           DOCU_OBSERV2,    DOCU_OBSERV3,
           DOCU_FECCRE,     DOCU_USER,     DOCU_ULFMOD,
           DOCU_PY_CIAS,    DOCU_PY_ETPY,  DOCU_PY_PROY,
           DOCU_PY_ENAP,
           DOCU_INAR_NUMERO  -- SOLI 5584
        )
        values
        (
           p_Cias,     v_vigdocu,   i.intm_pp_tpdo,
           v_NroDoc,   v_Acta,      v_fecha,
           1    ,      v_valor,     Substr(v_observ,1,75),
           Substr(v_observ,76,75),  Substr(v_observ,151,75) ,  --(695)
           sysdate,    p_Usua_Gene, sysdate,
           p_Cias,     p_py_etpy, p_py_proy,
           p_py_enap,
           p_numero  -- Soli 5584
        );
      exception
        when dup_val_on_index then         -- 1012954.  ovcaceres.  15/03/2012
             raise_application_error( -20638, 'PP_TDOCU: Doc. Presupuestal Duplicado. Empresa: ' || p_Cias||'  Vig:'||v_vigdocu||' Tpdo: '||i.intm_pp_tpdo||' NroDoc: '||v_NroDoc );  -- 1012954.  ovcaceres.  15/03/2012
        when others then
             raise_application_error( -20631, 'PP_TDOCU: ' || sqlerrm );
      end;
      --
      For j in movi loop
        --
        --
        v_mes := (nvl(v_Periodo_proc, p_Periodo)-(v_vigdocu*100));
        --
        If    ( j.intm_pp_area is null ) then
          raise_application_error( -20632, 'ERROR CARGANDO PRESUPUESTO. VERIFIQUE LOS PARAMETROS DE LAS AREAS (Area Nula).');
        elsif ( j.intm_impu is null ) then
          raise_application_error( -20633, 'ERROR CARGANDO PRESUPUESTO. VERIFIQUE LOS PARAMETROS DE LAS IMPUTACIONES (Imputacion Nula).');
        elsif ( j.intm_pp_tpmv is null ) then
          raise_application_error( -20634, 'ERROR CARGANDO PRESUPUESTO. VERIFIQUE LOS PARAMETROS DE TIPOS DE MOVIMIENTO (Tp.Mv. Nulo).');
        elsif ( j.intm_recu is null ) then
          raise_application_error( -20635, 'ERROR CARGANDO PRESUPUESTO. VERIFIQUE LOS PARAMETROS DE LOS RECURSOS (Recurso Nulo).');
        end if;
        --
        --  (1). Inserta en Tabla Temporal.
        --
        Begin
          --
          Insert into Sc_tInPpto
            (InPp_Cias,         InPp_InFa,           InPp_Numero,
             InPp_VigDocu,      InPp_TpDo,          InPp_NroDoc,
             InPp_Acta,         InPp_Vigencia,      InPp_Mes,
             InPp_TpMv,         InPp_Area,          InPp_ReCu,
             InPp_Impu,         InPp_Valor,         InPp_Origen)
          Values
            (p_Cias,             p_Infa,              p_Numero,
             v_VigDocu,         i.INTM_pp_TPDO,        v_NroDoc,
             v_Acta,            v_VigDocu,           v_Mes,
             j.INTM_PP_TPMV,  j.INTM_PP_AREA,   j.intm_ReCu,
             j.intm_Impu,       j.intm_Valor,       'PPTO1');
        exception
          when others then
            raise_application_error( -20636, 'SC_TINPPTO: ' || sqlerrm );
        End;
        --
        update ge_tintm
        set    INTM_PP_NRODOC = v_NroDoc,
               INTM_PP_ACTA   = v_Acta
        where current of movi;
        --
      End Loop;
      --
      --  Abre cursor de la tabla temporal.
      --
      For k in c_Temp Loop
        --
        v_rengln := nvl(v_rengln,0) + 1;
        --
        Begin
          --
          --
          Insert into Pp_tMovi
          (
             Movi_Cias,      Movi_VigDocu,    Movi_TpDo,
             Movi_NroDoc,    Movi_Acta,       Movi_Rengln,
             Movi_Vigencia,  Movi_Area,       Movi_Impu,
             Movi_TpMv,      Movi_Mes,        Movi_Valor,
             Movi_FecCre,    Movi_User,       Movi_Recu,
             Movi_Fecha,
             movi_inar_numero  -- Soli 5584
          )
          Values
          (
             k.InPp_Cias,    k.InPp_VigDocu,  k.InPp_TpDo,
             k.InPp_NroDoc,  k.InPp_Acta,     v_rengln,
             k.InPp_Vigencia,k.InPp_Area,     k.InPp_impu,
             k.InPp_TpMv,    k.InPp_Mes,      k.InPp_Valor,
             sysdate,        p_Usua_Gene,     k.InPp_Recu,
             v_Fecha,
             p_numero  -- Soli 5584
          );
          --
        exception
          when others then
               raise_application_error( -20637, 'PP_TMOVI: ' || sqlerrm );
        end;
        --
      End Loop;
      --
    End loop;
    --
    -- commit;   -- 1012954.  ovcaceres.  15/03/2012
    --
  End Car_Ppto;
  --
  --
  --
  procedure CAR_PPTO_2 ( p_Infa             varchar2,
                         p_Periodo          integer,
                         p_Numero           varchar2,
                         p_Cias             integer,
                         p_Fecha            date,
                         p_Usua_Gene          varchar2,
                         p_py_EtPy          integer,
                         p_py_Proy          varchar2,
                         p_py_EnAp          integer    ) is
    --
    v_valor       pp_tdocu.docu_valor%type;
    v_vigdocu     pp_tdocu.docu_vigdocu%type;
    v_observ      varchar2(2000);
    v_tpdo2       pp_tdocu.docu_tpdo%type;
    v_intm_fecha  ge_tintm.intm_fecha%type;
    v_ppto_tpnr2  ge_tintm.intm_pp_tpnr2%type;
    v_mes         pp_tmovi.movi_mes%type;
    v_rengln      pp_tmovi.movi_rengln%type;
    v_refvigdocu  pp_tmovi.movi_refvigdocu%type;
    v_reftpdo     pp_tmovi.movi_reftpdo%type;
    v_refnrodoc   pp_tmovi.movi_refnrodoc%type;
    v_refacta     pp_tmovi.movi_refacta%type;
    v_fecha date;
    v_NroDoc2     pp_tdocu.docu_nrodoc%type;
    v_Acta2       pp_tdocu.docu_acta%type;
    v_error       varchar2(1000);
    --
    v_Periodo_Proc integer;    -- Soli_5213
    --
    Cursor docu2 is
    Select distinct intm_pp_tpdo2, intm_fecha, intm_pp_tpnr2
      from ge_tintm
     where intm_fecmov = p_Periodo
       and intm_numero = p_numero
       and intm_cias   = p_Cias
       and intm_pp_tpdo2 is not null;
    --
    Cursor docu_descri is --(695)
    Select intm_descri
      from ge_tintm
     where intm_fecmov = p_Periodo
       and intm_numero = p_numero
       and intm_cias   = p_Cias
       and intm_pp_tpdo is not null;
    --
    Cursor movi2 is
    Select intm_pp_tpmv2, intm_pp_area, intm_recu, intm_impu, intm_valor,
          intm_pp_tpdo, intm_pp_nrodoc, intm_pp_acta, intm_cheque
      from ge_tintm
     where intm_fecmov     = p_Periodo
       and intm_numero     = p_Numero
       and intm_cias       = p_Cias
       and intm_pp_tpdo2      = v_tpdo2
       and intm_fecha      = v_intm_fecha
       and intm_pp_tpnr2 = v_ppto_tpnr2
       and intm_pp_tpmv2 is not null
       for update of intm_pp_nrodoc2, intm_pp_acta2;
    --
    Cursor c_Temp2 is
    Select InPp_Cias,   InPp_VigDocu,  InPp_TpDo,
           InPp_NroDoc, InPp_Acta,     InPp_Vigencia,
           InPp_Mes,    InPp_TpMv,     InPp_Area,
           InPp_ReCu,   InPp_Impu,     InPp_RefVigDocu,
           InPp_RefTpDo,InPp_RefNroDoc,InPp_RefActa,
           sum(InPp_Valor) InPp_Valor
      from Sc_tInPpto
     Where InPp_Cias   = p_Cias
       and InPp_InFa   = p_Infa
       and InPp_Numero = p_Numero
       and InPp_VigDocu = v_VigDocu
       and InPp_TpDo    = v_TpDo2
       and InPp_NroDoc  = v_NroDoc2
       and InPp_Acta    = v_Acta2
       and InPp_Origen = 'PPTO2'
     Group by InPp_Cias,   InPp_VigDocu,  InPp_TpDo,
              InPp_NroDoc, InPp_Acta,     InPp_Vigencia,
              InPp_Mes,    InPp_TpMv,     InPp_Area,
              InPp_ReCu,   InPp_Impu,     InPp_RefVigDocu,
              InPp_RefTpDo,InPp_RefNroDoc,InPp_RefActa;
    --
  BEGIN
    --
    -- Ini.Soli_5213
    --
    if ( p_Fecha is not null ) then
      v_Periodo_Proc := to_char(p_Fecha, 'yyyymm');
    else
      v_Periodo_Proc := null;
    end if;
    --
    -- Fin.Soli_5213
    --
    --
    -- (695)
    Open docu_descri;
    Fetch docu_descri Into v_observ;
    Close docu_descri;
    --
    If ( v_observ Is Null ) Then
       v_observ := 'INTERFASE '||p_Infa||'-'||p_Numero;
    End if;
    --
    For i in docu2 loop
      --
      v_tpdo2      := i.intm_pp_tpdo2;
      v_intm_fecha := i.intm_fecha;
      v_ppto_tpnr2 := i.intm_pp_tpnr2;
      --
      -- /** CALCULA VALOR DOCUMENTO 2 **/
      Begin
        Select nvl(sum(intm_valor*agmv_signo),0)
          into v_valor
          from ge_tintm, ge_ttpdo, pp_tagmv
         Where intm_fecmov    = p_Periodo
           and intm_numero    = p_Numero
           and intm_cias      = p_Cias
           and intm_pp_tpdo2     = i.intm_pp_tpdo2
           and intm_fecha     = i.intm_fecha
           and intm_pp_tpnr2= i.intm_pp_tpnr2
           and tpdo_tpdo      = i.intm_pp_tpdo2
           and tpdo_grmv      = agmv_grmv
           and agmv_tpcons    = 'A'
           and agmv_tpmv      = intm_pp_tpmv2;
        exception
          when others then
          v_valor := 0;
      End;
      --
      Nro_Doc_Ppto( p_Infa, p_Periodo, p_Numero, p_Cias, i.INTM_pp_TPDO2, i.INTM_PP_TPNR2, v_NroDoc2, v_Acta2 );
      --
      v_vigdocu := trunc(nvl( v_Periodo_Proc, p_Periodo)/100);
      v_fecha   := nvl(p_Fecha, to_date(i.intm_fecha,'dd-mm-yyyy'));
      --
      begin
        insert into pp_tdocu
        (
            DOCU_CIAS,    DOCU_VIGDOCU,  DOCU_TPDO,
            DOCU_NRODOC,  DOCU_ACTA,  DOCU_FECHA,
            DOCU_AUXI,    DOCU_VALOR, DOCU_OBSERV1, DOCU_OBSERV2, DOCU_OBSERV3,
            DOCU_FECCRE,  DOCU_USER,  DOCU_ULFMOD,
            docu_py_cias, docu_py_etpy, docu_py_proy,
            docu_py_enap,
            docu_inar_numero    --- Soli 5584
        )
        values
        (
            p_Cias,       v_vigdocu, i.intm_pp_tpdo2,
            v_NroDoc2,    v_Acta2, v_fecha,
            1,            v_valor,     Substr(v_observ,1,75) ,Substr(v_observ,76,75) ,Substr(v_observ,151,75) ,  --(695)
            sysdate,      p_Usua_Gene,sysdate,
            p_Cias,       p_py_etpy, p_py_proy,
            p_py_enap,
            p_numero  -- Soli 5584
        );
        --
      exception
        when others then
          raise_application_error( -20624, 'PP_TDOCU : ' || sqlerrm );
      end;
      --
      For j in movi2 loop
        --
        v_mes := to_number(substr(to_char(nvl( v_Periodo_Proc, p_Periodo)),5,2));
        --
        If    ( j.intm_pp_area is null ) then
          raise_application_error( -20625, 'ERROR CARGANDO PRESUPUESTO. VERIFIQUE LOS PARAMETROS DE LAS AREAS (Area Nula).');
        elsif ( j.intm_impu is null ) then
          raise_application_error( -20626, 'ERROR CARGANDO PRESUPUESTO. VERIFIQUE LOS PARAMETROS DE LAS IMPUTACIONES (Imputacion Nula).');
        elsif ( j.intm_pp_tpmv2 is null ) then
          raise_application_error( -20627, 'ERROR CARGANDO PRESUPUESTO. VERIFIQUE LOS PARAMETROS DE TIPOS DE MOVIMIENTO (Tp.Mv. Nulo).');
        elsif ( j.intm_recu is null ) then
          raise_application_error( -20628, 'ERROR CARGANDO PRESUPUESTO. VERIFIQUE LOS PARAMETROS DE LOS RECURSOS (Recurso Nulo).');
        end if;
        --
        --
        --  (1). Inserta en Tabla Temporal.
        --
        Begin
          --
          Insert into Sc_tInPpto
            (InPp_Cias,         InPp_InFa,          InPp_Numero,
             InPp_VigDocu,      InPp_TpDo,          InPp_NroDoc,
             InPp_Acta,         InPp_Vigencia,      InPp_Mes,
             InPp_TpMv,         InPp_Area,          InPp_ReCu,
             InPp_Impu,         InPp_Valor,         InPp_Origen,
             InPp_RefVigDocu,   InPp_RefTpDo,       InPp_RefNroDoc,
             InPp_RefActa,      inpp_cheque)
          Values
            (p_Cias,            p_Infa,             p_Numero,
             v_VigDocu,         i.INTM_pp_TPDO2,       v_NroDoc2,
             v_Acta2,           v_VigDocu,          v_Mes,
             j.INTM_PP_TPMV2, j.INTM_PP_AREA,   j.intm_ReCu,
             j.intm_Impu,       j.intm_Valor,       'PPTO2',
             v_VigDocu,         j.intm_pp_tpdo,        j.intm_pp_nrodoc,
             j.intm_pp_acta,  j.intm_cheque);
        exception
          when others then
            raise_application_error( -20629, 'SC_TINPPTO: ' || sqlerrm );
        End;
        --
        --
        Update ge_tintm
           set intm_pp_nrodoc2 = v_nrodoc2,
               intm_pp_acta2   = v_acta2
         where current of movi2;
        --
      end Loop;
      --
      --
      --  Abre cursor de la tabla temporal.
      --
      For k in c_Temp2 Loop
        --
        v_rengln := nvl(v_rengln,0) + 1;
        --
        Begin
          --
          --
          --
          insert into Pp_tMovi
          (
              MOVI_CIAS,         MOVI_VIGDOCU,   MOVI_TPDO,
              MOVI_NRODOC,       MOVI_ACTA,      MOVI_RENGLN,
              MOVI_VIGENCIA,     MOVI_AREA,      MOVI_IMPU,
              MOVI_TPMV,         MOVI_MES,       MOVI_VALOR,
              MOVI_FECCRE,       MOVI_USER,      MOVI_RECU,
              MOVI_REFVIGDOCU,   MOVI_REFTPDO,   MOVI_REFNRODOC,
              MOVI_REFACTA,      Movi_Fecha,
              MOVI_INAR_NUMERO   -- Soli 5584
          )
          values
          (
              k.InPp_Cias,       k.InPp_Vigdocu, k.InPp_TpDo,
              k.InPp_NroDoc,     k.InPp_Acta,    v_rengln,
              k.InPp_Vigencia,   k.InPp_Area,    k.InPp_Impu,
              k.InPp_TpMv,       k.InPp_Mes,     k.InPp_Valor,
              sysdate,           p_Usua_Gene,    k.InPp_Recu,
              k.InPp_RefVigDocu, k.InPp_RefTpDo, k.InPp_RefNroDoc,
              k.InPp_RefActa,    v_Fecha,
              p_numero   -- Soli 5584
          );
          --
        exception
          When others then
            raise_application_error( -20630, 'PP_TMOVI: ' || sqlerrm );
        End;
        --
      End Loop;
      --
    End loop;
    --
    --COMMIT;   -- 1012954.  ovcaceres.  16/03/2012
    --
  end CAR_PPTO_2;
  --
  --
  --
  procedure CAR_PPTO_CXP ( p_Infa             varchar2,
                           p_Periodo          integer,
                           p_Numero           varchar2,
                           p_Cias             integer,
                           p_Fecha            date,
                           p_Usua_Gene          varchar2,
                           p_VigOrPa          integer,
                           p_OrPa             integer,
                           p_Cxp_Tpmv         integer,
                           p_Cxp_Auxi         integer,
                           p_Valor            number,
                           p_pref             varchar2   default null,          -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
                           p_nrodoc           varchar2   default null           -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
                          ) is
    --
    v_tpmv        pp_tmovi.movi_tpmv%type;
    v_tpmv_ppto   pp_tmovi.movi_tpmv%type;
    v_cxp_tpdo    pp_tdocu.docu_tpdo%type;
    v_cxp_nrodoc  pp_tdocu.docu_nrodoc%type;
    v_cxp_acta    pp_tdocu.docu_nrodoc%type;
    v_rengln      integer;
    v_vigdocu     pp_tdocu.docu_vigdocu%type;
    v_mes         pp_tmovi.movi_mes%type;
    v_valor_rubro pp_tmovi.movi_valor%type;
    v_fecha       date;
    --
    v_Periodo_Proc integer;    -- Soli_5213
    --
    Cursor docucxp is
      select distinct intm_cxp_tpdo
      from   ge_tintm
      where  intm_fecmov = p_Periodo
      and    intm_numero = p_Numero
      and    intm_cias   = p_Cias
      and    intm_cxp_tpdo  is not null
      and   (intm_pp_tpdo   is not null or intm_pp_tpdo2 is not null)   --soli_60065
      and    nvl(intm_pref, '&&' ) = nvl( p_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
      and    nvl( intm_nrodoc, '&&' ) =  nvl( p_nrodoc, '&&'  ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
      ;
--soli_60065      and    intm_pp_tpdo      is not null;
    --
    Cursor docu is
      select distinct intm_pp_tpdo tpdo, intm_pp_nrodoc nrodoc, intm_pp_acta acta, intm_pp_tpmv tpmv
      from   ge_tintm
      where  intm_fecmov = p_Periodo
      and    intm_numero = p_Numero
      and    intm_cias   = p_Cias
      and    intm_pp_tpdo   = v_cxp_tpdo
      Union
      Select distinct intm_pp_tpdo2 tpdo, intm_pp_nrodoc2 nrodoc, intm_pp_acta2 acta, intm_pp_tpmv2 tpmv
      from   ge_tintm
      where  intm_fecmov = p_Periodo
      and    intm_numero = p_Numero
      and    intm_cias   = p_Cias
      and    intm_pp_tpdo2  = v_cxp_tpdo
      and    nvl(intm_pref, '&&' ) = nvl( p_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
      and    nvl( intm_nrodoc, '&&' ) =  nvl( p_nrodoc, '&&'  ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
      ;
    --
    cursor movi is
      select distinct intm_pp_area, intm_recu, intm_impu, sum(intm_valor) intm_valor, intm_fecha
      from   ge_tintm
      where  intm_fecmov     = p_Periodo
      and    intm_numero     = p_Numero
      and    intm_cias       = p_Cias
      and    nvl(intm_pp_tpdo2,intm_pp_tpdo)               = v_cxp_tpdo
      and    nvl(intm_pp_nrodoc2, intm_pp_nrodoc)= v_cxp_nrodoc
      and    nvl(intm_pp_acta2,intm_pp_acta)     = v_cxp_acta
      and    intm_cxp_tpmv    = p_Cxp_Tpmv
      and    intm_cxp_auxi    = p_Cxp_Auxi
      and    (intm_pp_tpmv  = v_tpmv_ppto
             or intm_pp_tpmv2 = v_tpmv_ppto)
      and    nvl(intm_pref, '&&' ) = nvl( p_pref,  '&&' )      -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
      and    nvl( intm_nrodoc, '&&' ) =  nvl( p_nrodoc, '&&'  ) -- vers.1005.gap.-.COMO033. ovcaceres.  24/04/2012
      group by intm_pp_area, intm_recu, intm_impu, intm_fecha;
    --
  Begin
    --
    --
    -- Ini.Soli_5213
    --
    if ( p_Fecha is not null ) then
      v_Periodo_Proc := to_char(p_Fecha, 'yyyymm');
    else
      v_Periodo_Proc := null;
    end if;
    --
    -- Fin.Soli_5213
    --
    For i in docucxp loop
      --
      v_cxp_tpdo := i.intm_cxp_tpdo;
      --
      For j in docu loop
        --
        v_cxp_nrodoc := j.nrodoc;
        v_cxp_acta   := j.acta;
        --
        --
        Begin
          select max(movi_rengln)
          into   v_rengln
          from   pp_tmovi
          where  movi_cias    = p_Cias
          and    movi_vigdocu = trunc(p_Periodo/100)
          and    movi_tpdo    = v_cxp_tpdo
          and    movi_nrodoc  = v_cxp_nrodoc
          and    movi_acta    = v_cxp_acta;
        exception
          when no_data_found then
            v_rengln := 0;
        end;
        --
        v_vigdocu   := trunc(p_Periodo/100);
        v_tpmv_ppto := j.tpmv;
        --
        for k in movi loop
          --
          Begin
            Select fuen_dest
            into v_tpmv
            from pp_tfuen
            where fuen_fuen = j.tpmv
            and fuen_user = 'CXP';
          exception
            when no_data_found then
              raise_application_error( -20621, 'TpMv.Fuente Destino no Existe para CXP, Fuente='|| j.TpMv );
            when others then
              raise_application_error( -20622, 'TpMv.Fuente Destino para CXP, Fuente='|| j.TpMv || ' : ' || sqlerrm );
          End;
          --
          v_fecha   := nvl( p_Fecha, to_date(k.intm_fecha,'dd-mm-yyyy'));
          v_rengln  := nvl(v_rengln,0)+1;
          v_vigdocu := trunc(nvl( v_Periodo_Proc, p_Periodo)/100);
          v_mes := to_number(substr(to_char(nvl(v_Periodo_Proc, p_Periodo)),5,2));
          --
          --
          begin
          /*  
          sf_pins_error(  'CIAS'||p_cias||
                          ' VIGDOCU:'||v_vigdocu||
                          ' TPDO:'||v_cxp_tpdo||
                          ' NRODOC:'||v_cxp_nrodoc||
                          ' ACTA:'||v_cxp_acta||
                          ' RENGLN:'||v_rengln||
                          ' AREA:'||k.intm_pp_area||
                          ' IMPU:'||k.intm_impu||
                          ' RECU:'||k.intm_recu||
                          ' VALOR:'||k.intm_valor||
                          ' p_Periodo:'||p_Periodo||
                          ' p_Numero:'||p_Numero||
                          ' p_Cias:'||p_Cias||
                          ' p_Cxp_Tpmv:'||p_Cxp_Tpmv||
                          ' p_Cxp_Auxi:'||p_Cxp_Auxi||
                          ' v_tpmv_ppto:'||v_tpmv_ppto
                       );*/
            insert into pp_tmovi
            (
                 MOVI_CIAS,   MOVI_VIGDOCU,  MOVI_TPDO,  MOVI_NRODOC,
                 MOVI_ACTA,   MOVI_RENGLN,   MOVI_VIGENCIA, MOVI_AREA,
                 MOVI_IMPU,   MOVI_TPMV,  MOVI_MES,   MOVI_VALOR,
                 MOVI_FECCRE, MOVI_USER,  MOVI_RECU,  MOVI_VIGORPA,
                 MOVI_ORPA,   Movi_Fecha,
                 MOVI_INAR_NUMERO   -- Soli 5584
             )
             values
             (
                 p_cias,        v_vigdocu,   v_cxp_tpdo,  v_cxp_nrodoc,
                 v_cxp_acta,    v_rengln,    v_vigdocu,   k.intm_pp_area,
                 k.intm_impu,   v_tpmv,      v_mes,       k.intm_valor,
                 sysdate,       p_Usua_Gene, k.intm_recu, p_VigOrPa,
                 p_Orpa,        v_fecha,
                 p_numero        -- Soli 5584
             );
          exception
            when others then
                 raise_application_error( -20623, 'PP_TMOVI : ' || sqlerrm );
          end;
          --
        End loop;
        --
        --
        -- Ini soli_60065
        --
        update cp_torpa
        	set orpa_tpdo    = v_cxp_tpdo,
        	    orpa_nrodoc  = v_cxp_nrodoc
        where orpa_cias    = p_cias
        and   orpa_vigorpa = p_VigOrPa
        and   orpa_orpa    = p_Orpa
        ;
        --
        -- Fin soli_60065
        --
      --commit; -- antes de 13712
      --
      End loop;
    --
    End loop;
    --
    -- commit;          -- 1012954.  ovcaceres.  16/03/2012
    --
  end CAR_PPTO_CXP;
  --
  --
  --
  Procedure Car_Ppto_Tesor ( p_Infa             varchar2,
                             p_Periodo          integer,
                             p_Numero           varchar2,
                             p_cias             integer,
                             p_Fecha            date,
                             p_Usua_Gene          varchar2    ) is
    --
    -- Modificaciones:
    -- 1. Almoto - 22 febrero 2003 ( ITC ) - Solicitud 1138
    --  . Hay que tener en cuenta que presupuestalmente, en este caso, o sea,
    --    cuando genera tesoreria, el valor a afectar es por el total causado.
    --    Si quedan pagos pendientes, esos ya no afectan presupuesto.
    --    Estas son las razones para que la condicion con el numero de Cheque
    --    NO ESTE HABILITADA.
    --  . Se modifico cursor C_FUENTE, para traer MOVI_VALOR y ademas para traer
    --    solo aquellas ordenes de pago, que tienen pago relacionado.  Se elimintmon
    --    variables v_vigorpa2 y v_orpa2. El valor que se recupera se tiene en cuenta
    --    para crear el nuevo movimiento de presupuesto.  Al insertar en presupuesto
    --    se hace teniendo en cuenta los n registros que recupere el cursor C_FUENTE.
    --
    -- 2. Almoto - 5 junio 2003 ( ITC ) - Solicitud 1541
    --    . Cursor C_FUENTE se modifico.  Se le crearon como parametros los codigos
    --      de Area, Imputacion y Recurso.
    --
    v_vigdocu     pp_tmovi.movi_vigencia%type;
    v_mes         pp_tmovi.movi_mes%type;
    v_tpmv        pp_tmovi.movi_tpmv%type;
    v_tpmv1       pp_tmovi.movi_tpmv%type;
    v_tpmv2       pp_tmovi.movi_tpmv%type;                                       -- (1096)
    v_vigdocu2    pp_tmovi.movi_vigencia%type;                                   -- (1096)
    v_tpdo2       pp_tdocu.docu_tpdo%type;                                       -- (1096)
    v_nrodoc2     pp_tdocu.docu_nrodoc%type;                                     -- (1096)
    v_acta2       pp_tdocu.docu_acta%type;                                       -- (1096)
    v_cias2       ge_tcias.cias_cias%type;                                       -- (1096)
    v_cxp_tpdo    pp_tdocu.docu_tpdo%type;
    v_cxp_nrodoc  pp_tdocu.docu_nrodoc%type;
    v_cxp_acta    pp_tdocu.docu_nrodoc%type;
    v_rengln      number;
    v_fecha       date;
    v_x           varchar2(1);
    v_proc_tes    varchar2(1);
    --
    v_Periodo_Proc integer;    -- Soli_5213
    --
    cursor c_tes is
      select 'x'
      from   ge_tintm
      where  intm_fecmov = p_Periodo
      and    intm_numero = p_Numero
      and    intm_cias   = p_Cias
      and    intm_te_tpmv is not null
      and    intm_te_tpco is not null
      and    intm_ncuenta    is not null;
    --
    cursor docucxp is
      select distinct intm_cxp_tpdo
      from   ge_tintm
      where  intm_fecmov = p_Periodo
      and    intm_numero = p_Numero
      and    intm_cias   = p_cias
      and    intm_cxp_tpdo is not null;
    --
    Cursor docu is
      select distinct intm_pp_tpdo tpdo, intm_pp_nrodoc nrodoc, intm_pp_acta acta, intm_fecha
      from   ge_tintm
      where  intm_fecmov = p_Periodo
      and    intm_numero = p_Numero
      and    intm_cias   = p_cias
      and    intm_pp_tpdo   = v_cxp_tpdo
      union
      select distinct intm_pp_tpdo2 tpdo, intm_pp_nrodoc2 nrodoc, intm_pp_acta2 acta, intm_fecha
      from   ge_tintm
      where  intm_fecmov = p_Periodo
      and    intm_numero = p_Numero
      and    intm_cias   = p_cias
      and    intm_pp_tpdo2  = v_cxp_tpdo;
    --
    cursor c_temp is
    select InPp_Cias,   InPp_VigDocu,  InPp_TpDo,
           InPp_NroDoc, InPp_Acta,     InPp_Vigencia,
           InPp_Mes,    InPp_TpMv,     InPp_Area,
           InPp_ReCu,   InPp_Impu,     InPp_RefVigDocu,
           InPp_RefTpDo,InPp_RefNroDoc,InPp_RefActa,
           sum(InPp_Valor) InPp_Valor
      from Sc_tInPpto
     where InPp_Cias   = p_cias
       and InPp_InFa   = p_Infa
       and InPp_Numero = p_Numero
       and InPp_VigDocu = trunc(nvl(v_Periodo_Proc, p_Periodo)/100)
       and InPp_TpDo    = v_cxp_tpdo
       and InPp_NroDoc  = v_cxp_nrodoc
       and InPp_Acta    = v_cxp_acta
       and InPp_Origen  = 'PPTO2'
      --**and inpp_cheque is not null                                ---- Soli_1138
     Group by InPp_Cias,   InPp_VigDocu,  InPp_TpDo,
              InPp_NroDoc, InPp_Acta,     InPp_Vigencia,
              InPp_Mes,    InPp_TpMv,     InPp_Area,
              InPp_ReCu,   InPp_Impu,     InPp_RefVigDocu,
              InPp_RefTpDo,InPp_RefNroDoc,InPp_RefActa;
    --
    cursor c_fuente ( pc_Area varchar2, pc_Impu varchar2, pc_Recu varchar2 ) is   --- Soli_1541
    select movi_orpa, movi_vigorpa, movi_Valor      ------ Soli_1138
      from pp_tmovi, pp_tfuen, cp_torpa             ------ Soli_1138
     where fuen_fuen    = movi_tpmv
       and fuen_user    = 'TESOR'
       and movi_cias    = v_cias2
       and movi_vigdocu = v_vigdocu2
       and movi_nrodoc  = v_nrodoc2
       and movi_tpdo    = v_tpdo2
       and movi_acta    = v_acta2
       and movi_Area    = pc_Area                  ------ Soli_1541
       and movi_Impu    = pc_Impu                  ------ Soli_1541
       and movi_Recu    = pc_Recu                  ------ Soli_1541
       and orpa_OrPa    = movi_OrPa                ------ Soli_1138
       and orpa_VigOrPa = movi_VigOrPa             ------ Soli_1138
       and orpa_Cias    = movi_Cias                ------ Soli_1138
       and orpa_Proceso = 'INTERFASE-PAGO'         ------ Soli_1138
       and fuen_dest    = v_tpmv2;
    --
    --
  Begin
    --
    --
    --
    -- Ini.Soli_5213
    --
    if ( p_Fecha is not null ) then
      v_Periodo_Proc := to_char(p_Fecha, 'yyyymm');
    else
      v_Periodo_Proc := null;
    end if;
    --
    -- Fin.Soli_5213
    --
    open c_tes;
    fetch c_tes into v_x;
    if ( c_tes%notfound ) then
      v_proc_tes := 'N';
    else
      v_proc_tes := 'S';
    end if;
    close c_tes;
    --
    if ( v_proc_tes = 'S' ) then
      --
      for i in docucxp loop
        --
        v_cxp_tpdo := i.intm_cxp_tpdo;
        --
        --
        for j in docu loop
          --
          v_cxp_nrodoc := j.nrodoc;
          v_cxp_acta   := j.acta;
          --
          --
          begin
            select max(movi_rengln)
            into   v_rengln
            from   pp_tmovi
            where  movi_cias    = p_cias
            and    movi_vigdocu = trunc(nvl(v_Periodo_Proc, p_Periodo)/100)
            and    movi_tpdo    = v_cxp_tpdo
            and    movi_nrodoc  = v_cxp_nrodoc
            and    movi_acta    = v_cxp_acta;
          exception
            when no_data_found then
              v_rengln := 0;
          end;
          --
          v_vigdocu := trunc(nvl(v_Periodo_Proc, p_Periodo)/100);
          v_fecha   := nvl(p_Fecha, to_date(j.intm_fecha,'dd-mm-yyyy'));
          v_mes     := to_number(substr(to_char(nvl(v_Periodo_Proc, p_Periodo)), 5, 2));
          --
          for k in c_temp loop
            --
            begin
              select fuen_dest
              into   v_tpmv1
              from   pp_tfuen
              where  fuen_user = 'CXP'
              and    fuen_fuen = k.inpp_tpmv;
            exception
              when no_data_found then
                raise_application_error( -20616, 'TpMv.Fuente Destino no Existe para CXP, Fuente='||k.inpp_TpMv );
              when others then
                raise_application_error( -20617, 'TpMv.Fuente Destino para CXP, Fuente='||k.inpp_TpMv || ' : ' || sqlerrm );
            end;
            --
            begin
              select fuen_dest
              into   v_tpmv
              from   pp_tfuen
              where  fuen_user = 'TESOR'
              and    fuen_fuen = v_tpmv1;
            exception
              when no_data_found then
                raise_application_error( -20618, 'TpMv.Fuente Destino no Existe para TESOR, Fuente='|| v_TpMv1 );
              when others then
                raise_application_error( -20619, 'TpMv.Fuente Destino para TESOR, Fuente='|| v_TpMv1 || ' : ' || sqlerrm );
            end;
            --
            begin
              --
              v_cias2    := k.inpp_cias;                         -- (1096)
              v_vigdocu2 := k.inpp_vigdocu;                      -- (1096)
              v_tpdo2    := k.inpp_tpdo;                         -- (1096)
              v_nrodoc2  := k.inpp_nrodoc;                       -- (1096)
              v_acta2    := k.inpp_acta;                         -- (1096)
              v_tpmv2    := v_tpmv;                              -- (1096)
              --
              --open  c_fuente;                                    -- (1096)
              --fetch c_fuente into r_fte;                         -- (1096) -- Soli_1138
              --close c_fuente;                                    -- (1096)
              --
              for p in c_fuente ( k.inpp_Area, k.inpp_Impu, k.inpp_Recu ) loop      ---- Soli_1541
                --
                v_rengln := nvl(v_rengln,0)+1;
                --
                -- nota(' Vigdocu: '||v_vigdocu2||'Tipo Doc. '||k.InPp_TpDo||' Vrodoc: '||v_nrodoc2||' TpMv '||v_tpmv||' Acta '||v_acta2);
                begin
                   --
                  insert into pp_tmovi
                  (
                     MOVI_CIAS,        MOVI_VIGDOCU,  MOVI_TPDO,       MOVI_NRODOC,
                     MOVI_ACTA,        MOVI_RENGLN,   MOVI_VIGENCIA,   MOVI_AREA,
                     MOVI_IMPU,        MOVI_TPMV,     MOVI_MES,        MOVI_VALOR,
                     MOVI_FECCRE,      MOVI_USER,     MOVI_RECU,       MOVI_VIGORPA,
                     MOVI_ORPA,        Movi_Fecha,
                     MOVI_INAR_NUMERO    -- Soli 5584
                  )
                  values
                  (
                     k.inpp_cias,   k.inpp_vigdocu,     k.inpp_tpdo, k.inpp_nrodoc,
                     k.inpp_acta,   v_rengln,           v_vigdocu,   k.inpp_area,
                     k.inpp_impu,   v_tpmv,             v_mes,       p.movi_Valor,               --- Soli_1138
                     sysdate,       p_Usua_Gene,        k.inpp_recu, p.movi_VigOrPa,  -- (1096)  --- Soli_1138
                     p.movi_OrPa,   v_fecha,            -- (1096)  --- Soli_1138
                     p_numero                           -- Soli 5584
                  );
                  --
                exception
                  when others then
                       raise_application_error( -20620, 'PP_TMOVI: ' || sqlerrm );
                end;
                --
              end loop c_fuente;
              --
            end;
             --
             -- k.inpp_impu,      v_tpmv,            v_mes,       k.inpp_valor,                   --- Soli_1138
             -- sysdate,           p_Usua_Gene, k.inpp_recu, v_VigOrPa2,          -- (1096)  --- Soli_1138
             -- v_OrPa2,         v_fecha );                                           -- (1096)  --- Soli_1138
             --
          end loop c_temp;
          --
        --commit;  -- antes de 13712
          --
        end loop docu;
        --
      end loop docucxp;
      --
    end if;
    --
  End Car_Ppto_Tesor;
  --
  --
  --
  Procedure Car_Tes_Neto ( p_Infa              varchar2,
                           p_Periodo           integer,
                           p_Numero            varchar2,
                           p_cias              integer,
                           p_Fecha             date,
                           p_Usua_Gene         varchar2,
                           p_tpco              integer,
                           p_tpcoe             integer,
                           p_nrocom            integer,
                           p_auxi_Agr          integer,
                           p_cias_etct         integer,
                           p_rengln     in out integer,
                           p_rengln_tmp in out integer   ) is
    --
    -- Modificaciones:
    -- 1. Almoto - 18 junio 2003 ( ITC ) - Solicitud 1611
    --    . Al validar cuentas bancarias se tiene en cuenta que esten A-ACTIVAS
    --
    -- 2. Almoto - 25 julio 2003 - Solicitud 1722
    --    . Cursor c_tes_neto, se agregaron las columnas intm_Dependencia, intm_PgPr.
    --      En la sentencia de insercion a la tabla ge_tints, se agregaron estas dos columnas.
    --
    -- 3. Almoto - 23 noviembre 2005 - Solicitud 5570
    --    . Se condiciona el procesamiento de la partida contable a que la columna
    --      INTM_MAYO_P no este nula.
    --
    --
    v_descri     sc_tmvco.mvco_descri%type;
    v_mayo       sc_tmvco.mvco_mayo%type;
    v_mayo_opc1  sc_tmvco.mvco_mayo%type;
    v_mayo_opc2  sc_tmvco.mvco_mayo%type;
    v_auxi       sc_tmvco.mvco_auxi%type;
    v_tporan     sc_tmvco.mvco_tporan%type;
    v_valor      sc_tmvco.mvco_mtoren%type;
    v_fecha      sc_tmvco.mvco_fecdoc%type;
    v_rengln     sc_tmvco.mvco_rengln%type  :=  p_rengln;
    v_vigorpa    cp_torpa.orpa_vigorpa%type;
    v_orpa       cp_torpa.orpa_orpa%type;
    v_enti       ge_tenti.enti_auxi%type;
    v_mayo_enti  sc_tmvco.mvco_mayo%type;
    v_tponat     te_ttpmv.tpmv_tporan%type;
    v_genmvp     te_ttpmv.tpmv_genmvp%type;
    --
    v_Periodo_Proc integer;    -- Soli_5213
    --
    cursor c_tes_neto is
    select intm_mayo_c,         intm_tporan,     intm_auxi_c,
           intm_mayo_P,         intm_auxi_P,     intm_descri,
           intm_fecha,          intm_ncuenta,    intm_cheque, intm_vigorpa, intm_orpa,
           intm_te_tpmv,        intm_tpliq,      intm_te_auxi,
           intm_cxp_auxi,       intm_te_etcf, intm_te_fluj,
           intm_te_etoe,        intm_te_oecj,
           intm_Dependencia,    intm_PgPr,                              -- Soli_1722
           intm_fmpg,            --COMO058
           sum(intm_vlrmone)    intm_vlrmone,    intm_pref,                           -- COMO058
           intm_nrodoc,         intm_fecdoc,     sum(intm_valdoc)  intm_valdoc,       -- COMO058
           sum(intm_inco_base_valor) intm_inco_base_valor,
           sum(intm_valor) intm_valor
      from ge_tintm
     where intm_fecmov      = p_Periodo
       and intm_numero      = p_Numero
       and intm_cias        = p_cias
       and intm_te_tpco  = p_tpco
       and intm_te_tpcoe = p_tpcoe
       and intm_tpliq       = 'N'
       and nvl(intm_Auxi_Agr,1) = nvl(p_auxi_Agr,1)
       and intm_ncuenta is not null
     group by intm_mayo_c,     intm_tporan,     intm_auxi_c,     intm_descri,      intm_mayo_P,      intm_auxi_P,
              intm_fecha,      intm_ncuenta,    intm_cheque,     intm_vigorpa,     intm_orpa,
              intm_te_tpmv,    intm_tpliq,      intm_te_auxi,    intm_cxp_auxi,    intm_te_etcf,
              intm_te_fluj,    intm_te_etoe,    intm_te_oecj,    intm_Dependencia, intm_PgPr, /*COMO058*/intm_fmpg,/*COMO058*/
              intm_vlrmone,    intm_pref,       intm_nrodoc,     intm_fecdoc              -- COMO058
     order by intm_vigorpa,    intm_orpa,       intm_ncuenta,    intm_cheque;
    --
    -- Calcula el renglon siguiente de la tabla GE_TINTS
    --
    cursor c_ge_tints is                          -- Soli 5584
    select nvl(max(ints_rengln),0)+1              -- Soli 5584
    from   ge_tints                               -- Soli 5584
    where  ints_numero = p_numero   -- Soli 5584
    and    ints_infa = p_infa;                    -- Soli 5584
    --
    -- Inicia COMO058
    cursor c_mayo (pc_etct    integer, pc_mayo    varchar2 ) is select mayo_reexp_mon, mayo_mone
                                from ge_tmayor
                                where mayo_etct = pc_etct
                                and mayo_mayo = pc_mayo;
    --
    v_mone              pi_tmone.mone_mone%type;
    v_valor_orig        sc_tmvco.mvco_mtoren%type;
    v_reexp_mon         ge_tmayor. mayo_reexp_mon%type;
    v_mone_apl          number;
    -- Termina COMO058
    --
  BEGIN
    --
    --
    -- Ini.Soli_5213
    --
    if ( p_Fecha is not null ) then
      v_Periodo_Proc := to_char(p_Fecha, 'yyyymm');
    else
      v_Periodo_Proc := null;
    end if;
    --
    -- Fin.Soli_5213
    --
    for j in c_tes_neto loop
      --
      v_Descri := nvl(j.intm_descri,'INTERFASE NUMERO :'||p_Numero);
      v_Mayo   := j.intm_mayo_P;
      v_Auxi   := j.intm_auxi_P;
      --
      if ( j.intm_tporan = 'C' ) then
        v_tporan := 'D';
      else
        v_tporan := 'C';
      end if;
      --
      if ( j.intm_inco_base_valor is not null ) then
        v_valor := j.intm_inco_base_valor;
      else
        v_valor := j.intm_valor;
      end if;
      --
      v_valor_orig := j.intm_vlrmone;             -- COMO058
      --
      v_Fecha   := nvl( p_Fecha, to_date(j.intm_fecha,'dd-mm-yyyy'));
      --
      if ( v_tporan = 'C' ) then
        v_valor := v_valor*-1;
        v_valor_orig := v_valor_orig*-1;          -- COMO058
      else
        v_valor := v_valor;
        v_valor_orig := v_valor_orig;             -- COMO058
      end if;
      --
      -- Partida Contable
      --
      if ( j.intm_Mayo_P is not null ) then           -- Soli_5570 (Nueva Condicion)
        --
        -- Mayor asociado a la Cuenta Bancaria
        --
        begin
          select enti_mayo
            into v_mayo_opc1
            from ge_tenti
           where enti_auxi   = v_auxi
             and nvl(enti_Status, 'A') = 'A'  --- Soli_1611
             and enti_cias+0 = p_cias;
        exception
          when others then
            v_mayo_opc1 := v_mayo;
        end;
        --
        --
        if ( v_valor <> 0 ) then                    /** NO CONTABILIZA VALORES EN CERO **/
          --
          -- Inicia COMO058
          v_reexp_mon  := null;
          v_mone := null;
          --
          open c_mayo ( p_cias_etct, nvl(v_mayo_opc1,v_mayo) );
             fetch c_mayo into v_reexp_mon, v_mone;
          close c_mayo;
          --
          if ( v_reexp_mon= 'S' ) then
             --
             if ( j.intm_vlrmone is null ) then
               --
               raise_application_error( -20679, 'SC_TMVCO: No Hay Valor Mon. Extranjera en Cuenta: '|| nvl(v_mayo_opc1,v_mayo) );
               --
             end if;
             --
             if ( nvl( j.intm_vlrmone, 0 ) <> 0 ) then
                 v_mone_apl  := j.intm_valor  / j.intm_vlrmone;
             else
                v_mone_apl  := null;
             end if;
             --
          else
            --
            v_reexp_mon  := null;
            v_mone := null;
            --
          end if;
          -- Termina COMO058
          --
           begin
             --
             update sc_tmvco
                set mvco_mtoren      = mvco_mtoren + v_valor,
                    mvco_mtoren_orig = nvl(mvco_mtoren_orig,0) + v_valor_orig   -- COMO058
              where mvco_cias   = p_cias
                and mvco_tpco   = p_tpco
                and mvco_nrocom = p_nrocom
                and mvco_fecmov = p_Periodo
                and mvco_auxi   = v_auxi
                and mvco_mayo||''   = nvl(v_mayo_opc1,v_mayo)
                and mvco_tporan = v_tporan
                and mvco_cheque = j.intm_cheque;
             --
             if (sql%RowCount = 0) then
                --
                v_rengln := nvl(v_rengln,0) + 1;
                --
                insert into sc_tmvco
                (
                    MVCO_CIAS,      MVCO_TPCO,      MVCO_NROCOM,
                    MVCO_FECMOV,    MVCO_RENGLN,    MVCO_MAYO,
                    MVCO_AUXI,      MVCO_DESCRI,
                    MVCO_FECDOC,
                    MVCO_MTOREN,    MVCO_TPORAN,    MVCO_ETCT,
                    MVCO_CHEQUE,
                    mvco_mone,                                           -- COMO058
                    mvco_vmone,     mvco_vmone_apl, mvco_mtoren_orig     -- COMO058
                )
                values
                (
                    p_cias,       p_tpco,      p_NROCOM,
                    p_Periodo,    v_rengln,    nvl(v_mayo_opc1,v_mayo),
                    v_auxi,       SUBSTR(v_DESCRI,1,1000),  -- sOLI 5584
                    v_fecha,
                    v_valor,      v_tporan,    p_cias_etct,
                    j.intm_cheque,
                    v_mone,                                               -- COMO058
                    null,         v_mone_apl,  v_valor_orig               -- COMO058
                );
                --
             end if;
             --
           --COMMIT; -- antes de 13712
             --
           exception  -- Cambio(1)
             when others then
               raise_application_error( -20609, 'SC_TMVCO. Cias='||p_Cias || ' TpCo='||p_TpCo || ' NroCom='||p_NroCom || ' Per='||p_Periodo || ' : ' ||sqlerrm);
           end;
           --
        end if;                           -- FIN DE NO CONTABILIZA VALORES EN CERO
        --
      end if;  -- Soli_5570 (Termina de procesar cuando INTM_MAYO_P es no nula)
      --
      --
      begin
        select enti_auxi, enti_mayo
          into v_enti, v_mayo_enti
          from ge_tenti, ge_tauxil
         where enti_auxi   = auxi_auxi
           and enti_cias+0 = p_cias
           and nvl(enti_Status, 'A') = 'A'  --- Soli_1611
           and auxi_nit    = j.intm_ncuenta;
      exception
        when others then
          raise_application_error( -20610, 'Cuenta Bancaria: ' || j.intm_NCuenta || ' : ' || sqlerrm );
      end;
      --
      if ( v_valor < 0 ) then
        v_valor  := v_valor;
      else
        v_valor  := v_valor*-1;
      end if;
      --
      v_tporan := 'C';
      --
      -- BUSCA CTA.MAYOR DE LA ENTIDAD
      --
      Begin
         Select enti_mayo
           into v_mayo_opc2
           from ge_tenti
          where enti_auxi   = v_enti
            and nvl(enti_Status, 'A') = 'A'  --- Soli_1611
            and enti_cias+0 = p_cias;
         exception
          when others then
           v_mayo_opc2 := v_mayo_enti;
       End;
       --
       --
       If ( v_Valor <> 0 ) Then                    -- NO CONTABILIZA VALORES EN CERO
          --
          Begin
            --
            Update Sc_tMvCo
               set mvco_mtoren = mvco_mtoren + v_valor
             where mvco_cias   = p_cias
               and mvco_tpco   = p_tpco
               and mvco_nrocom = p_nrocom
               and mvco_fecmov = nvl(v_Periodo_Proc, p_Periodo)
               and mvco_mayo||'' = nvl(v_mayo_opc2,v_mayo_enti)
               and mvco_auxi   = v_enti
               and mvco_tporan = v_tporan
               and mvco_cheque = j.intm_cheque;
            --
            If (sql%RowCount = 0) then
               --
               v_fecha  := nvl(p_Fecha, to_date(j.intm_fecha,'dd-mm-yyyy'));
               --
               v_rengln := nvl(v_rengln,0) + 1;
               --
               begin
                 --
                 insert into Sc_tMvCo
                   ( MVCO_CIAS,    MVCO_TPCO,     MVCO_NROCOM,   MVCO_FECMOV,
                     MVCO_RENGLN,  MVCO_MAYO,     MVCO_AUXI,     MVCO_DESCRI,
                     MVCO_FECDOC,  MVCO_MTOREN,   MVCO_TPORAN,   MVCO_ETCT,
                     mvco_cheque )
                 values
                   ( p_cias,      p_tpco,         p_nrocom,      nvl(v_Periodo_Proc, p_Periodo),
                     v_rengln,    nvl(v_mayo_opc2,v_mayo_enti), v_enti,
                     'EGRESO DE INTERFASE '||p_Numero||' CHEQUE:'||to_char(j.intm_cheque),
                     v_fecha,   v_valor, v_tporan,   p_cias_etct,
                     j.intm_cheque );
                 --
                 exception
                   when others then
                     raise_application_error( -20611, 'SC_TMVCO. Cias='||p_Cias || ' TpCo='||p_TpCo || ' NroCom='||p_NroCom || ' Per='||p_Periodo || ' : ' ||sqlerrm);
               end;
               --
             End if;
             --
           --COMMIT; -- antes de 13712
             --
          end;
          --
       End if;                           -- NO CONTABILIZA VALORES EN CERO
       --
       Begin
         --
         v_vigorpa := j.intm_vigorpa;
         v_orpa    := j.intm_orpa;
         --
         If ( v_VigOrPa is null ) and  ( v_OrPa is null ) then
            --
            begin
              select distinct
                     intm_vigorpa, intm_orpa
                into v_VigOrPa, v_OrPa
                from ge_tintm
               where intm_FecMov   = p_Periodo
                 and intm_numero   = p_Numero
                 and intm_Cias     = p_cias
                 and intm_TpCo     is not null
                 and intm_TpCoe    is not null
                 and intm_Cxp_Auxi = j.intm_Cxp_Auxi
                 and intm_VigOrPa  is not null
                 and intm_OrPa     is not null;
            exception
              when too_many_rows then
                --
                Begin
                  Select distinct intm_vigorpa, intm_orpa
                    into v_VigOrPa, v_OrPa
                    from ge_tintm
                   where intm_FecMov = p_Periodo
                     and intm_numero = p_numero
                     and intm_Cias   = p_cias
                     and intm_TpCo   is not null
                     and intm_TpCoe  is not null
                     and intm_Cxp_Auxi = j.intm_Cxp_Auxi
                     and intm_Cxp_TpMv in (Select TpMv_TpMv
                                             from Cp_tTpMv
                                            where TpMv_Pasivo = 'P'
                                              and TpMv_Ppto   = 'S')
                     and intm_VigOrPa is null
                     and intm_OrPa is null;
                exception
                  when others then
                   v_vigorpa := null;
                   v_OrPa := null;
                --
                end;

              when others then
                v_vigorpa := null;
                v_orpa := null;
            End;
            --
         End if;
         --
       End;
       --
       Trae_te_TpMv ( j.intm_te_tpmv, v_TpoNat, v_GenMvP );
       --
       v_fecha   := nvl( p_Fecha, to_date(j.intm_fecha,'dd-mm-yyyy') );
       --
       Begin
         --
         v_valor := (abs(v_valor)*-1);
         --
         --
         -- INSERTA EN LA TABLA TEMPORAL GE_TINTS.
         --
         -- Soli 5584 p_rengln_tmp := nvl(p_rengln_tmp,0)+1;
         --
         open  c_ge_tints;                     -- Soli 5584
         fetch c_ge_tints into p_rengln_tmp;   -- Soli 5584
         close c_ge_tints;                     -- Soli 5584
         --
         begin
           --
           insert into ge_tints
             (ints_infa,         ints_numero,        ints_rengln,
              ints_cias,         ints_tpco,          ints_nrocom,       ints_fecmov,
              ints_mayo,         ints_enti,          ints_tpmv,         ints_cheque,
              ints_benefi,       ints_tporan,        ints_valor,        ints_fecent,
              ints_fecpago,      ints_orpa,          ints_vigorpa,
              ints_feccre,       ints_fecmod,        ints_user,         ints_descri,
              ints_fecdoc,       ints_status,
              ints_etcf,         ints_fluj,          ints_etoe,         ints_oecj,
              ints_Dependencia,  ints_PgPr,                                                            -- Soli_1722
              ints_fmpg,  --COMO058
              ints_vlrmone,      ints_pref,          ints_nrodoc,       ints_fac_fecdoc,                   -- COMO058
              ints_valdoc                                                                              -- COMO058
              )
           values
             (p_Infa,             p_Numero,           p_rengln_tmp,
              p_cias,             p_tpco,             p_nrocom,         p_Periodo,
              v_mayo_enti,        v_enti,             j.intm_te_tpmv,   j.intm_cheque,
              j.intm_te_auxi,     v_TpoNat,           v_valor,          v_fecha,
              v_fecha,            v_orpa,             v_vigorpa,
              sysdate,            sysdate,            p_Usua_Gene,      'EGRESO INTERFASE '||p_Numero,
              v_fecha,            'I',
              j.intm_te_etcf,     j.intm_te_fluj,     j.intm_te_etoe,   j.intm_te_oecj,
              j.intm_Dependencia, j.intm_PgPr,                                            -- Soli_1722
              j.intm_fmpg,  --COMO058
              j.intm_vlrmone,     j.intm_pref,        j.intm_nrodoc,    j.intm_fecdoc,                  -- COMO058
              j.intm_valdoc                                                                             -- COMO058
              );
           --
           exception
             when others then
               raise_application_error( -20612, 'GE_TINTS : ' || sqlerrm );
         end;
         --
       --COMMIT; -- antes de 13712
         --
       end;
       --
     end loop c_tes_neto;
     --
  end CAR_TES_NETO;
  --
  --
  --
  procedure Car_Tes_No_Neto ( p_Infa              varchar2,
                              p_Periodo           integer,
                              p_Numero            varchar2,
                              p_cias              integer,
                              p_Fecha             date,
                              p_Usua_Gene         varchar2,
                              p_tpco              integer,
                              p_tpcoe             integer,
                              p_nrocom            integer,
                              p_Auxi_Agr          integer,
                              p_etct              integer,
                              p_rengln     in out integer,
                              p_rengln_tmp in out integer ) is
    --
    -- Modificaciones:
    -- 1. Almoto - 18 junio 2003 ( ITC ) - Solicitud 1611
    --    . Al validar cuentas bancarias se tiene en cuenta que esten A-ACTIVAS
    --
    -- 2. Almoto - 25 julio 2003 - Solicitud 1722
    --    . Cursor c_tesor, se modifico para que recupere intm_Dependencia, intm_PgPr.
    --      En la sentencia de insercion a la tabla ge_tints, se agregaron estas dos columnas.
    --
    -- 3. Almoto - 23 noviembre 2005 - Solicitud 5570
    --    . Se condiciona el procesamiento de la partida contable a que la columna
    --      INTM_MAYO_P no este nula.
    --
    v_descri     sc_tmvco.mvco_descri%type;
    v_mayo       sc_tmvco.mvco_mayo%type;
    v_mayo_opc1  sc_tmvco.mvco_mayo%type;
    v_mayo_opc2  sc_tmvco.mvco_mayo%type;
    v_tporan     sc_tmvco.mvco_tporan%type;
    v_auxi       sc_tmvco.mvco_auxi%type;
    v_valor      sc_tmvco.mvco_mtoren%type;
    v_fecha      sc_tmvco.mvco_fecdoc%type;
    v_rengln     sc_tmvco.mvco_rengln%type;
    v_enti       ge_tenti.enti_auxi%type;
    v_mayo_enti  sc_tmvco.mvco_mayo%type;
    v_tponat     te_ttpmv.tpmv_tporan%type;
    v_genmvp     te_ttpmv.tpmv_genmvp%type;
    --
    v_Periodo_Proc integer;    -- Soli_5213
    --
    cursor c_tesor is
    select intm_mayo_c,      intm_tporan,  intm_auxi_c,
           intm_mayo_P,      intm_auxi_P,  intm_descri,
           intm_fecha,       intm_ncuenta, intm_cheque,  intm_vigorpa, intm_orpa,
           intm_te_tpmv,     intm_tpliq,   intm_te_auxi, intm_te_etcf,
           intm_te_fluj,     intm_te_etoe, intm_te_oecj,
           intm_Dependencia, intm_PgPr,
           intm_fmpg,  --COMO058
           sum(intm_vlrmone) intm_vlrmone, intm_pref,    intm_nrodoc,  intm_fecdoc,     -- COMO058
           sum(intm_valdoc)  intm_valdoc,                                               -- COMO058
           SUM(intm_inco_base_valor) intm_inco_base_valor,
           SUM(intm_valor) intm_valor
      from ge_tintm
     where intm_fecmov = p_Periodo
       and intm_numero = p_numero
       and intm_cias   = p_Cias
       and intm_te_tpco  = p_tpco
       and intm_te_tpcoe = p_tpcoe
       and intm_tpliq  in ('P','B')
       and nvl(intm_auxi_Agr,1) = nvl(p_auxi_Agr,1)
       and intm_ncuenta is not null
     group by intm_mayo_c,      intm_tporan,      intm_auxi_c,  intm_mayo_P,
              intm_auxi_P,      intm_descri,
              intm_fecha,       intm_ncuenta,     intm_cheque,
              intm_vigorpa,     intm_orpa,        intm_te_tpmv, intm_tpliq,
              intm_te_auxi,     intm_te_etcf,     intm_te_fluj, intm_te_etoe,
              intm_te_oecj,     intm_Dependencia, intm_PgPr, /*COMO058*/intm_fmpg,/*COMO058*/
              intm_pref,        intm_nrodoc,      intm_fecdoc                                    -- COMO058
     order by intm_vigorpa, intm_orpa, intm_ncuenta, intm_cheque;
    --
    cursor c_ge_tints is                          -- Soli 5584
    select nvl(max(ints_rengln),0)+1              -- Soli 5584
    from   ge_tints                               -- Soli 5584
    where  ints_numero = p_numero   -- Soli 5584
    and    ints_infa = p_infa;                    -- Soli 5584
    --
    -- Inicia COMO058
    cursor c_mayo (pc_etct    integer, pc_mayo    varchar2 ) is
      select mayo_reexp_mon, mayo_mone
        from ge_tmayor
       where mayo_etct = pc_etct
         and mayo_mayo = pc_mayo;
    --
    v_mone              pi_tmone.mone_mone%type;
    v_valor_orig        sc_tmvco.mvco_mtoren%type;
    v_reexp_mon         ge_tmayor. mayo_reexp_mon%type;
    v_mone_apl          number;
    -- Termina COMO058
    --
  begin
    --
    -- Ini.Soli_5213
    --
    if ( p_Fecha is not null ) then
      v_Periodo_Proc := to_char(p_Fecha, 'yyyymm');
    else
      v_Periodo_Proc := null;
    end if;
    --
    -- Fin.Soli_5213
    --
    for j in c_tesor loop
      --
      v_descri := nvl(j.intm_descri,'INTERFASE NUMERO : '||p_Numero);
      --
      if ( j.intm_mayo_c is not null ) then
        v_mayo   := j.intm_mayo_c;
        v_tporan := j.intm_tporan;
        v_auxi   := j.intm_auxi_c;
      else
        v_mayo   := j.intm_mayo_P;
        v_auxi   := j.intm_auxi_P;
        --
        If j.intm_tporan = 'C' then
          v_tporan := 'D';
        else
          v_tporan := 'C';
        End if;
        --
      end if;
      --
      v_valor_orig := j.intm_vlrmone;             -- COMO058
      --
      if ( v_tporan = 'C' ) then
        v_valor      := j.intm_valor*-1;
        v_valor_orig := v_valor_orig*-1;          -- COMO058
      else
        v_valor      := j.intm_valor;
        v_valor_orig := v_valor_orig;             -- COMO058
      end if;
      --
      v_fecha   := nvl(p_Fecha,to_date(j.intm_fecha,'dd-mm-yyyy'));
      --
      if ( j.intm_inco_base_valor is not null ) then
        v_valor := j.intm_inco_base_valor;
      end if;
      --
      --
      if ( j.intm_Mayo_P is not null ) then                -- Soli_5570 (Nueva condicion)
        --
        -- Mayor asociado a la Cuenta Bancaria
        --
        begin
          select enti_mayo
            into v_mayo_opc1
            from ge_tenti
           where enti_auxi   = v_auxi
             and nvl(enti_Status, 'A') = 'A'  --- Soli_1611
             and enti_cias+0 = p_cias;
        exception
          when others then
            v_mayo_opc1 := v_mayo;
        end;
        --
        --
        if ( v_valor <> 0 ) then                    -- NO CONTABILIZA VALORES EN CERO
            --
            -- Inicia COMO058
            v_reexp_mon  := null;
            v_mone := null;
            --
            open c_mayo ( p_etct, nvl(v_mayo_opc1,v_mayo) );
               fetch c_mayo into v_reexp_mon, v_mone;
            close c_mayo;
            --
            if ( v_reexp_mon= 'S' ) then
               --
               if ( j.intm_vlrmone is null ) then
                 --
                 raise_application_error( -20680, 'SC_TMVCO: No Hay Valor Mon. Extranjera en Cuenta: '|| nvl(v_mayo_opc1,v_mayo) );
                 --
               end if;
               --
               if ( nvl( j.intm_vlrmone, 0 ) <> 0 ) then
                   v_mone_apl  := j.intm_valor  / j.intm_vlrmone;
               else
                  v_mone_apl  := null;
               end if;
               --
            else
              --
              v_reexp_mon  := null;
              v_mone := null;
              --
            end if;
            -- Termina COMO058
            --
            Update sc_tmvco
               set mvco_mtoren      = mvco_mtoren + v_valor,
                   mvco_mtoren_orig = nvl(mvco_mtoren_orig,0) + v_valor_orig    -- COMO058
             where mvco_cias   = p_cias
               and mvco_tpco   = p_tpco
               and mvco_nrocom = p_nrocom
               and mvco_fecmov = p_Periodo
               and mvco_auxi   = v_auxi
               and mvco_mayo||''   = nvl(v_mayo_opc1,v_mayo)
               and mvco_tporan = v_tporan
               and mvco_cheque = j.intm_cheque;
            --
            if (sql%rowcount = 0) then
              --
              v_rengln := nvl(v_rengln,0) + 1;
              --
              insert into sc_tmvco
                ( MVCO_CIAS,    MVCO_TPCO,      MVCO_NROCOM,
                  MVCO_FECMOV,  MVCO_RENGLN,    MVCO_MAYO,
                  MVCO_AUXI,    MVCO_DESCRI,    MVCO_FECDOC,
                  MVCO_MTOREN,  MVCO_TPORAN,    MVCO_ETCT,
                  mvco_cheque,
                  mvco_mone,                                            -- COMO058
                  mvco_vmone,   mvco_vmone_apl, mvco_mtoren_orig        -- COMO058
                  )
              values
                ( p_cias,       p_tpco,        p_NROCOM,
                  p_Periodo,    v_rengln,      nvl(v_mayo_opc1,v_mayo),
                  v_auxi,       v_DESCRI,      v_fecha,
                  v_valor,      v_tporan,      p_etct,
                  j.intm_cheque,
                  v_mone,                                               -- COMO058
                  null,         v_mone_apl,    v_valor_orig             -- COMO058
                  );
              --
            end if;
            --
          --COMMIT; -- antes de 13712
            --
        end if;                           -- FIN DE NO CONTABILIZA VALORES EN CERO
        --
      end if;               -- Soli_5570 (Termina de procesar cuando INTM_MAYO_P no es nula)
      --
      -- CREA MOV. TESORERIA
      --
      Begin
        --
        Select enti_auxi, enti_mayo
          into v_enti, v_mayo_enti
          from ge_tenti, ge_tauxil
         where enti_auxi   = auxi_auxi
           and enti_cias+0 = p_Cias
           and nvl(enti_Status, 'A') = 'A'  --- Soli_1611
           and auxi_nit    = j.intm_ncuenta;
      exception
          when others then
            raise_application_error( -20607, 'Cuenta Bancaria: ' || j.intm_NCuenta || ' : ' || sqlerrm );
        --
      End;
      --
      If v_valor < 0 then
         v_valor  := v_valor;
      else
         v_valor  := v_valor*-1;
      end if;
      v_tporan := 'C';
      --
      --
      -- BUSCA CTA.MAYOR DE LA ENTIDAD
      --
      Begin
       Select enti_mayo
         into v_mayo_opc2
         from ge_tenti
        where enti_auxi   = v_enti
          and nvl(enti_Status, 'A') = 'A'  --- Soli_1611
          and enti_cias+0 = p_Cias;
      exception
        when others then
         v_mayo_opc2 := v_mayo_enti;
      End;
      --
      --
      if ( v_valor <> 0 ) then
         --
         Update Sc_tMvCo
            set mvco_mtoren = mvco_mtoren + v_valor
          where mvco_cias   = p_cias
            and mvco_tpco   = p_tpco
            and mvco_nrocom = p_nrocom
            and mvco_fecmov = nvl( v_Periodo_proc, p_Periodo )
            and mvco_mayo||'' = nvl(v_mayo_opc2,v_mayo_enti)
            and mvco_auxi   = v_enti
            and mvco_tporan = v_tporan
            and mvco_cheque = j.intm_cheque;
         --
         If ( sql%rowcount = 0) then
            --
            v_descri := 'EGRESO DE INTERFASE '||p_Numero||' CHEQUE:'||to_char(j.intm_cheque);
            v_fecha  := nvl(p_Fecha,to_date(j.intm_fecha,'dd-mm-yyyy'));
            v_rengln := nvl(v_rengln,0) + 1;
            --
            insert into sc_tmvco
              ( mvco_CIAS,     MVCO_TPCO,     MVCO_NROCOM,   MVCO_FECMOV,
                MVCO_RENGLN,   MVCO_MAYO,     MVCO_AUXI,     MVCO_DESCRI,
                MVCO_FECDOC,   MVCO_MTOREN,   MVCO_TPORAN,   MVCO_ETCT,
                mvco_cheque )
            values
              ( p_cias,        p_tpco,                       p_nrocom,   nvl( v_Periodo_proc, p_Periodo ),
                v_rengln,      nvl(v_mayo_opc2,v_mayo_enti), v_enti,     v_descri,
                v_fecha,       v_valor,                      v_tporan,   p_etct,
                j.intm_cheque );
            --
       End if;
       --
     --COMMIT; -- antes de 13712
       --
      end if;
      --
      Trae_te_TpMv ( j.intm_te_tpmv, v_tponat, v_genmvp );
      --
      v_fecha   := nvl(p_Fecha, to_date(j.intm_fecha, 'dd-mm-yyyy'));
      --
      v_valor  := v_valor*-1;
      --
      -- INSERTA EN LA TABLA TEMPORAL GE_TINTS.
      --
      -- Soli 5584  p_rengln_tmp := nvl(p_rengln_tmp,0)+1;
      --
      open  c_ge_tints;                     -- Soli 5584
      fetch c_ge_tints into p_rengln_tmp;   -- Soli 5584
      close c_ge_tints;                     -- Soli 5584
      --
      begin
       insert into ge_tints
         (ints_infa,         ints_numero,        ints_rengln,
          ints_cias,         ints_tpco,          ints_nrocom,       ints_fecmov,
          ints_mayo,         ints_enti,          ints_tpmv,         ints_cheque,
          ints_benefi,       ints_tporan,        ints_valor,        ints_fecent,
          ints_fecpago,      ints_orpa,          ints_vigorpa,
          ints_feccre,       ints_fecmod,        ints_user,         ints_descri,
          ints_fecdoc,       ints_status,
          ints_etcf,         ints_fluj,          ints_etoe,         ints_oecj,
          ints_Dependencia,  ints_PgPr,                                            -- Soli_1722
          ints_fmpg, --COMO058
          ints_vlrmone,      ints_pref,          ints_nrodoc,       ints_fac_fecdoc,   -- COMO058
          ints_valdoc                                                              -- COMO058
          )
       values
         (p_Infa,             p_Numero,           p_rengln_tmp,
          p_cias,             p_tpco,             p_nrocom,          p_Periodo,
          v_mayo_enti,        v_enti,             j.intm_te_tpmv,    j.intm_cheque,
          j.intm_te_auxi,     v_tponat,           v_valor,           v_fecha,
          v_fecha,            j.intm_orpa,        j.intm_vigorpa,
          sysdate,            sysdate,            p_Usua_Gene,       'EGRESO INTERFASE '||p_Numero,
          v_fecha,            'I',
          j.intm_te_etcf,     j.intm_te_fluj,     j.intm_te_etoe,    j.intm_te_oecj,
          j.intm_Dependencia, j.intm_Pgpr,                                         -- Soli_1722
          j.intm_fmpg,
          j.intm_vlrmone,     j.intm_pref,        j.intm_nrodoc,     j.intm_fecdoc,  -- COMO058
          j.intm_valdoc                                                              -- COMO058
          );
       --
       exception
         when others then
           raise_application_error( -20608, 'GE_TINTS: ' || sqlerrm );
      end;
      --
    end loop c_tesor;
    --
    p_rengln := v_rengln;
    --
  end Car_Tes_No_Neto;
  --
  --
  ---------------------------------------------------------------------------------------------------------
  --                     Terminan Programas para el Procesamiento de la Interfase                        --
  ---------------------------------------------------------------------------------------------------------
  procedure DESHACE_INFA ( p_Infa       varchar2,
                           p_Periodo    integer,
                           p_Numero     varchar2,
                           p_Usua_Gene    varchar2   ) is
    --
    QReg  number := 0;
    --
  begin
    --
    -- BORRA TABLA TEMPORAL DE TESORERIA
    --
    loop
        --
        delete ge_tints
        where  ints_FecMov = p_Periodo
        and    ints_Infa   = p_Infa
        and    ints_numero = p_Numero
        and    rownum < 1000;
        --
        if ( sql%rowcount = 0 ) then
             exit;
        else
             commit;
        end if;
        --
    end loop;
    --
    dbms_output.PUT_LINE('Borrando ge_tints p_Usua_Gene'||p_Usua_Gene);
    -- BORRA CHEQUES
    --
    loop
      --
      -- Soli 5584 delete te_tcheq
      -- Soli 5584 where  cheq_user = p_Usua_Gene
      -- Soli 5584 and    to_char(cheq_FecCom, 'yyyymm') = p_Periodo
      -- Soli 5584 and    rownum < 1000;
      --                                                -- Soli 5584
      delete te_tcheq                                   -- Soli 5584
      where  cheq_inar_numero = p_numero  -- Soli 5584
      and    rownum < 1000;                             -- Soli 5584
      --
      if  (sql%rowcount = 0) then
        exit;
      else
        commit;
      end if;
      --
    end loop;
    --
    dbms_output.PUT_LINE('Borrando te_tcheq p_Usua_Gene'||p_Usua_Gene);
    --
    -- BORRA TESORERIA
    --
    Loop
      --
      -- Soli 5584 delete te_tmvte
      -- Soli 5584 where  mvte_user    = p_Usua_Gene
      -- Soli 5584 and    mvte_FecMov  = p_Periodo
      -- Soli 5584 and    rownum       < 500;
      --
      delete te_tmvte                      -- Soli 5584
      where  mvte_inar_numero = p_numero   -- Soli 5584
      and    rownum       < 500;           -- Soli 5584
      --
      if  (sql%rowcount = 0) then
           commit;
           exit;
      else
           commit;
      end if;
      --
    End loop;
    --
    dbms_output.PUT_LINE('Borrando te_tmvte p_Usua_Gene'||p_Usua_Gene);
    --
    -- BORRA CONTABILIDAD
    --
    declare
      --
      -- cursor mvco is
      -- select ctco_cias, ctco_tpco, ctco_nrocom, ctco_fecmov
      -- from   sc_tctco
      -- where  ctco_user   = p_Usua_Gene
      -- and    ctco_FecMov = p_Periodo;
      --
      cursor mvco is                                         -- Soli 5584
      select ctco_cias, ctco_tpco, ctco_nrocom, ctco_fecmov  -- Soli 5584
      from   sc_tctco                                        -- Soli 5584
      where  ctco_inar_numero = p_numero;      -- Soli 5584
      --
    Begin
      --
      for i in mvco loop
          --
          dbms_output.PUT_LINE('Borrando p_Usua_Gene='||p_Usua_Gene||' p_Periodo='||p_Periodo);
          --
          delete Ge_tAcre
          where  acre_cias   = i.ctco_cias
          and    acre_tpco   = i.ctco_tpco
          and    acre_nrocom = i.ctco_nrocom
          and    acre_fecmov = i.ctco_fecmov;
          --
          dbms_output.PUT_LINE('Borrando Ge_tAcre i.ctco_cias '||i.ctco_cias||
                               ' i.ctco_tpco '||i.ctco_tpco||
                               ' i.ctco_nrocom '||i.ctco_nrocom||
                               ' i.ctco_fecmov '||i.ctco_fecmov);
          --
          commit;
          --
          delete te_tmvte
          where  mvte_cias   = i.ctco_cias
          and    mvte_tpco   = i.ctco_tpco
          and    mvte_nrocom = i.ctco_nrocom
          and    mvte_fecmov = i.ctco_fecmov;
          --
          dbms_output.PUT_LINE('Borrando te_tmvte i.ctco_cias '||i.ctco_cias||
                               ' i.ctco_tpco '||i.ctco_tpco||
                               ' i.ctco_nrocom '||i.ctco_nrocom||
                               ' i.ctco_fecmov '||i.ctco_fecmov);
          commit;
          --
          delete sc_tmvco
          where  mvco_cias   = i.ctco_cias
          and    mvco_tpco   = i.ctco_tpco
          and    mvco_nrocom = i.ctco_nrocom
          and    mvco_fecmov = i.ctco_fecmov;
          --
          dbms_output.PUT_LINE('Borrando sc_tmvco i.ctco_cias '||i.ctco_cias||
                               ' i.ctco_tpco '||i.ctco_tpco||
                               ' i.ctco_nrocom '||i.ctco_nrocom||
                               ' i.ctco_fecmov '||i.ctco_fecmov);
          commit;
          --
      end loop mvco;
      --
      delete sc_tctco
      where  ctco_inar_numero = p_numero;
      --
      dbms_output.PUT_LINE('Borrando sc_tctco p_Usua_Gene '||p_Usua_Gene||
                           ' p_Periodo '||p_Periodo);
      commit;
      --
    end;
    --
    -- BORRA CXP
    --
    declare
      --
      v_orpa   cp_torpa.orpa_orpa%type;
      --
      -- Soli 5584 cursor orpa is
      -- Soli 5584 select orpa_cias, orpa_vigorpa, orpa_orpa
      -- Soli 5584 from   cp_torpa
      -- Soli 5584 where  orpa_user   = p_Usua_Gene
      -- Soli 5584 and    orpa_FecMov = p_Periodo;
      --
      cursor orpa is                                      -- Soli 5584
      select orpa_cias, orpa_vigorpa, orpa_orpa           -- Soli 5584
      from   cp_torpa                                     -- Soli 5584
      where  orpa_inar_numero = p_numero;   -- Soli 5584
      --
    begin
      for i in orpa loop
        --
        delete cp_torpv
        where  orpv_cias    = i.orpa_cias
        and    orpv_vigorpa = i.orpa_vigorpa
        and    orpv_orpa    = i.orpa_orpa;
        --

        commit;
        --
        delete cp_tpgpr
        where  pgpr_cias    = i.orpa_cias
        and    pgpr_vigorpa = i.orpa_vigorpa
        and    pgpr_orpa    = i.orpa_orpa;
        --
        commit;
        --
        loop
          --
          delete pp_tmovi
          where  movi_cias    = i.orpa_cias
          and    movi_vigorpa = i.orpa_vigorpa
          and    movi_orpa    = i.orpa_orpa
          and    rownum < 500;
          --
          if  (sql%rowcount = 0) then
            exit;
          else
            commit;
          end if;
          --
        End loop;
        --
        commit;
        --
        end loop orpa;
    end;
    --
    Loop
      --
      -- Soli 5584 delete cp_torpa
      -- Soli 5584 where  orpa_user   = p_Usua_Gene
      -- Soli 5584 and    orpa_FecMov = p_Periodo
      -- Soli 5584 and    rownum      < 1000;
      --
      delete cp_torpa
      where  orpa_inar_numero = p_numero
      and    rownum      < 1000;
      --
      if ( sql%rowcount = 0) then
           commit;
           exit;
      else
           commit;
      end if;
      --
    End loop;
    --
    -- Ini.Soli_5997
    --
    delete from pp_tmovi
     where movi_inar_Numero = p_Numero;
    --
    delete from pp_tdocu
     where docu_inar_Numero = p_Numero;
    --
    -- Fin.Soli_5997
    --
    --
    -- BORRA DET. PPTO
    --
    Declare
      --
      Cursor c_docu is
      select distinct inar_cias, inar_tpdo, inar_ppto_nrodoc, inar_ppto_acta
        from ge_tinarch
       where inar_infa   = p_Infa
         and inar_fecmov = p_Periodo
         and inar_numero = p_numero
         and inar_tpdo   is not null
         and inar_ppto_nrodoc is not null
      Union
      Select distinct inar_cias, inar_tpdo2 inar_tpdo, inar_ppto_nrodoc2 inar_ppto_nrodoc, inar_ppto_acta2 inar_ppto_acta
        from ge_tinarch
       where inar_infa   = p_Infa
         and inar_fecmov = p_Periodo
         and inar_numero = p_numero
         and inar_tpdo2   is not null
         and inar_ppto_nrodoc2 is not null;
      --
    Begin
      --
      --
      For i in c_docu loop
        --
        Loop
          --
          delete pp_tmovi
          where  movi_cias    = i.inar_cias
          and    movi_vigdocu = trunc(p_Periodo/100)
          and    movi_tpdo    = i.inar_tpdo
          and    movi_nrodoc  = i.inar_ppto_nrodoc
          and    movi_acta    = i.inar_ppto_acta
          and    rownum < 500;
          --
          if  (sql%rowcount = 0) then
            exit;
          else
            commit;
          end if;
          --
        End loop;
        --
        delete pp_tdocu
        where  docu_cias    = i.inar_cias
        and    docu_vigdocu = trunc(p_Periodo/100)
        and    docu_tpdo    = i.inar_tpdo
        and    docu_nrodoc  = i.inar_ppto_nrodoc
        and    docu_acta    = i.inar_ppto_acta;
        --
        commit;
        --
        Loop
          --
          delete Sc_tInPpto
          where  InPp_Cias   = i.inar_cias
          and    InPp_infa   = p_Infa
          and    InPp_numero = p_Numero
          and    rownum < 500;
          --
          if  (sql%rowcount = 0) then
            exit;
          else
            commit;
          end if;
          --
        End loop;
        --
      end loop;
      --
    End;
    --
    -- inicio 13335
    declare
      --
      cursor c_docu is
      select distinct inar_cias
        from ge_tinarch
       where inar_infa   = p_Infa
         and inar_fecmov = p_Periodo
         and inar_numero = p_numero;
       --     
    begin
      --  
      For i in c_docu loop
        --
        delete Sc_tInPpto
        where  InPp_Cias   = i.inar_cias
        and    InPp_infa   = p_Infa
        and    InPp_numero = p_Numero
        and    rownum < 500;
        --
        if  (sql%rowcount = 0) then
          exit;
        else
          commit;
        end if;
        --
      End loop;
      --
    end;  
    -- fin 13335
    -- ini 1046 lvgomez
    DECLARE
        --
        CURSOR c_tmtif IS
            SELECT mtif_mvif_nromov
                  ,mtif_cias         -- v. 1048 sbejarano
              FROM ge_tmtif
             WHERE mtif_infa = p_numero;
        -- ini v. 1048 sbejarano
        CURSOR c_cias_fond (pc_cias sf_tfond.fond_fond%TYPE) IS
            SELECT fond_fond
              FROM sf_tfond
             WHERE fond_cias = pc_cias
                   ;
        --
        v_fond sf_tfond.fond_fond%TYPE;
        -- fin v. 1048 sbejarano
        --
    BEGIN
        --
        Sf_Pins_Error('lvgomez deshacer: ');   
        FOR v_Indice IN c_tmtif LOOP
            --
            -- ini v. 1048 sbejarano
            -- Sf_Pins_Error('lvgomez deshacer - > v_Indice.mtif_mvif_nromov: '||v_Indice.mtif_mvif_nromov);
            OPEN  c_cias_fond(v_Indice.mtif_cias);
            FETCH c_cias_fond INTO v_fond;
            CLOSE c_cias_fond;
            -- fin v. 1048 sbejarano
            DELETE sf_tmvif
            -- ini v. 1048 sbejarano
             -- WHERE mvif_nromov = v_Indice.mtif_mvif_nromov;
             WHERE mvif_nromov = v_Indice.mtif_mvif_nromov
               AND mvif_fond   = v_fond
                   ;
            -- fin v. 1048 sbejarano
            --
             DELETE ge_tmtif
             -- ini v. 1048 sbejarano
              -- WHERE mtif_mvif_nromov = v_Indice.mtif_mvif_nromov;
              WHERE mtif_mvif_nromov = v_Indice.mtif_mvif_nromov
                AND mtif_cias        = v_Indice.mtif_cias
                    ;
              -- fin v. 1048 sbejarano
            --
        END LOOP;
        --
    END;
    -- fin 1046 lvgomez
    exception
      when others then
        raise_application_error( -20606, 'Deshaciendo: ' || sqlerrm );
    --
  end Deshace_INFA;
  ------------------------------------------------------------------------------------------------
  --
  --
  procedure Inicializa_Estado ( p_Infa           varchar2,
                                p_Periodo        integer,
                                p_Numero         varchar2,
                                p_Cias           integer   ) is
  begin
    --
    update Ge_tInarch
    set    Inar_Estado = null
    where  Inar_Infa   = p_Infa
    and    Inar_fecmov = p_Periodo
    and    inar_numero = p_Numero
    and    Inar_cias   = p_Cias;
    --
    commit;
    --
  end Inicializa_Estado;
  --
  --
  --
  procedure Mayo_Pide_Area_CeCo( p_Etct            integer,
                                 p_Mayo            varchar2,
                                 p_Pide_Area  out  varchar2,
                                 p_Pide_CeCo  out  varchar2   ) IS
  begin
    --
    select mayo_area, mayo_ceco
    into   p_Pide_Area, p_Pide_Ceco
    from   Ge_tMayor
    where  Mayo_Etct = p_Etct
    and    Mayo_Mayo = p_Mayo;
  Exception
    When others then
      null;
  end Mayo_Pide_Area_CeCo;
  --
  --
  --
  procedure Nro_Doc_Ppto ( p_Infa           varchar2,
                           p_Periodo        integer,
                           p_Numero         varchar2,
                           p_Cias           integer,
                           p_tpdo           varchar2,
                           p_tpnr           varchar2,
                           p_nrodoc  out    varchar2,
                           p_Acta    out    integer   ) is
    --
    v_docnumera   ge_ttpdo.tpdo_docnumera%type;
    v_docconsec   ge_ttpdo.tpdo_docconsec%type;
    v_vigdocu     integer;
    v_mes         integer;
    v_nrodoc      pp_tdocu.docu_nrodoc%type;
    v_acta        pp_tdocu.docu_acta%type;
    Qcant         integer;
    v_cico        ge_tcias.cias_cias%type;
    --
    cursor c_tpdo is
    select tpdo_docnumera, tpdo_docconsec
      from ge_ttpdo
     where tpdo_tpdo = p_tpdo;
    --
  begin
    --
    open c_tpdo;
    fetch c_tpdo into v_DocNumera, v_DocConsec;
    if ( c_tpdo%NotFound ) then
      close c_tpdo;
      raise_application_error( -20605, 'No existe Tipo de Documento Presupuestal : ' || p_TpDo );
    end if;
    close c_tpdo;
    --
    --
    v_VigDocu := trunc(p_Periodo/100);
    v_Mes     := (p_Periodo-(v_vigdocu*100));
    --
    --
    If ( v_docnumera = 'A' ) then
       --
       If    ( v_docconsec = 'E' ) then
          --
          Gen_NroDoc_Ppto( p_Infa, p_Periodo, p_Numero, p_Cias, v_vigdocu, p_tpdo, v_nrodoc, v_acta );
          --
          p_nrodoc := v_nrodoc;
          p_acta   := v_acta;
          --
       elsif ( v_docconsec = 'C' ) then
          --
          Begin
            Select cons_cias
              into v_cico
              from pp_tcons
             where p_cias between cons_ciades
                              and cons_ciahas;
          exception
            when others then
            v_cico := p_cias;
          End;
          --
          Gen_NroDoc_Ppto( p_Infa, p_Periodo, p_Numero, v_cico, v_vigdocu, p_tpdo, v_nrodoc, v_acta );
          --
          p_nrodoc := v_nrodoc;
          p_acta   := v_acta;
          --
       else
          --
          p_nrodoc := p_Infa || p_Periodo || '-' || p_Numero;
          p_acta   := 0;
          --
       end if;
       --
    else
       --
       p_nrodoc := p_Infa || p_Periodo || '-' || p_Numero;
       p_acta   := 0;
       --
    end if;
    --
  exception
    --
    when others then
      p_nrodoc := p_Infa || p_Periodo || '-' || p_Numero;
    --
  end Nro_Doc_Ppto;
  --
  --
  --
  procedure Gen_NroDoc_Ppto ( p_Infa           varchar2,
                              p_Periodo        integer,
                              p_Numero         varchar2,
                              p_Cias           integer,
                              p_Vigencia       integer,
                              p_TpDo           varchar2,
                              p_NroDoc    out  varchar2,
                              p_Acta      out  integer   ) is
    --
    v_NroDoc  Pp_tDcTm.DcTm_NroDoc%type;
    --
  begin
    --
    /*
    PP_PNumerar_Docu(p_Cias,
                     p_TpDo,
                     p_Vigencia,
                     v_NroDoc);
    --
    If ( v_NroDoc is null ) then
      v_NroDoc := 1;
    End if;
    */
    --
    v_nrodoc := p_Infa || p_Periodo || '-' || p_Numero;
    --
    p_NroDoc := v_NroDoc;
    p_Acta   := 0;
    --
  end Gen_NroDoc_Ppto;
  --
  --
  --
  function Trae_Mayo_Pasivo_Neto ( p_Cias     integer,
                                   p_Infa     varchar2,
                                   p_Periodo  integer,
                                   p_Numero   varchar2 ) RETURN VARCHAR2 IS
    --
    -- Modificaciones:
    -- 1. Almoto - 14 septiembre 2006 - Solicitud 6304
    --    . Se reemplaza lo relacionado con la tabla GE_TINARCH por GE_TINTM
    --    . Se eliminaron sentencias que sobraban, mas sin embargo queda pendiente
    --      verificar con que fin se recupera la cuenta mayor de INTM_MAYO_C, ya que
    --      no se esta utilizando.
    --
    v_mayo       ge_tmayor.mayo_mayo%type;
    v_cont_mayo  ge_tmayor.mayo_mayo%type;
    --
    cursor c_intm is
    select intm_Mayo_C, intm_Mayo_P
      from ge_tintm
     where intm_numero = p_Numero
       and intm_fecmov = p_Periodo
       and intm_cias   = p_cias
       and intm_tpliq  = 'N';       -- revisar las condiciones de la consulta
    --
  begin
    --
    open c_intm;
    fetch c_intm into v_cont_mayo, v_mayo;
    close c_intm;
    --
    RETURN(v_mayo);
    --
  end Trae_Mayo_Pasivo_Neto;
  --
  --
  --
  procedure Trae_Cpto_Suce( p_Infa                varchar2,
                            p_inco                varchar2,
                            p_Inco_Base_Suce  out varchar2  ) is
    --
    cursor c_cpto_suce is
    select inco_inco_sucesor
      from ge_tinconceptos
     where inco_infa = p_Infa
       and inco_inco = p_inco;
    --
  begin
    --
    open c_cpto_suce;
    Fetch c_cpto_suce into p_Inco_Base_Suce;
    if ( c_cpto_suce%notfound ) then
      p_Inco_Base_suce := null;
    end if;
    Close c_cpto_suce;
    --
  end Trae_Cpto_Suce;
  --
  --
  --
  Procedure Trae_Dat_Cia( p_cias  in   integer,
                          p_inrq  in   integer,
                          p_nivel out  varchar2,
                          p_etct  out  integer,
                          p_etcf  out  integer  ) is
    --
    --  MODIFICACION
    --  1. EJ2H.  21-DEC-2005 -- Soli 5584
    --     . Se valida que la compania pertenezca al requerimiento
    --
		cursor c_Cias is
    select b.cias_nivel, b.cias_etct, b.cias_etcf
    from   ge_vinrq a, ge_vcias b
    where  b.cias_cias = a.inrq_cias
    and    a.inrq_cias = p_cias;
    --
  begin
    --
    open c_Cias;
    fetch c_Cias into p_Nivel, p_EtCt, p_EtCF;
    if ( c_Cias%NotFound ) then
         close c_Cias;
         raise_application_error( -20602, 'La expresa no pertenece al requerimiento. '||p_Cias );
    end if;
    close c_Cias;
    --
  end Trae_Dat_Cia;
  --
  --
  --
  procedure Trae_te_TpMv ( p_TpMv    in   integer,
                           p_Natu    out  varchar2,
                           p_pp_TpMv out  varchar2 ) is
    --
    cursor c_tpmv is
    select tpmv_tporan, tpmv_genmvp
      from te_ttpmv
     where tpmv_tpmv = p_TpMv;
    --
  begin
    --
    open c_tpmv;
    fetch c_tpmv into p_Natu, p_pp_TpMv;
    if ( c_tpmv%NotFound ) then
      close c_tpmv;
      raise_application_error( -20603, 'Tipo de Movimiento de Tesoreria NO EXISTE: ' || p_TpMv );
    end if;
    close c_tpmv;
    --
  end Trae_te_TpMv;
  ------------------------------------------------------------------------------------------------------------
  ------------------------------------------------------------------------------------------------------------
  --
  Procedure Validar ( p_Infa           varchar2,
                      p_inrq           integer,
                      p_Periodo        integer,
                      p_Numero         varchar2,
                      p_Opcion     out varchar2,
                      p_Msg        out varchar2  ) is
    --
    --
    -- -- Codigos del estado del archivo de importacion
    -- B - Estan bien los codigos      R - Error de recurso
    -- I - Error de Imputacion         A - Area de respons equivocada
    -- T - Tercero equivocado          N - Nit asociado equivocado       G    - Nit agrupa equivocado
    -- Q - Banco-Sucursal equivocados  M - Cta mayor errada              F    - Referencia sin equivalente
    -- E - No hay equivalente en param W - Varios param cumplen          VrBs - Concepto base Sin Valor
    --
    --
    v_senal number;
    --
    cursor c_inar_Cias is
    select distinct inar_cias
    from   ge_tinarch
    where  inar_numero = p_Numero
    order by inar_cias;
    --
    v_cias_cias ge_tcias.cias_cias%type;
    --
    cursor c_tctrl ( pc_cias ge_tcias.cias_cias%type ) is
    select cias_cias
    from   ge_tcias
    where  cias_cias = pc_cias;
    --
    cursor c_Cias (pc_cias ge_tcias.cias_cias%type)  is                                             -- Soli 5584
    select cias_cias, cias_descri, cias_auxi, cias_nit, cias_periodo_actual, cias_ciud, cias_etct,  -- Soli 5584
           cias_etco, cias_etcf, cias_etpp, cias_etre, cias_etar, cias_etrq, cias_etci, cias_etoe,  -- Soli 5584
           cias_etde, cias_etpy, cias_etfd, cias_nivel, cias_status                                 -- Soli 5584
    from   ge_vinrq, ge_vcias                                                                       -- Soli 5584
    where  cias_cias = inrq_cias                                                                    -- Soli 5584
    and    inrq_cias = pc_cias                                                                      -- Soli 5584
    and    inrq_inrq = p_inrq;                                                                      -- Soli 5584
    --
    r_Ci   c_Cias%RowType;  --1049
    --
    --smcalderon ini 1039 rfc 39471
    cursor c_fpag (v_cias number) is
    select DISTINCT(inar_formato) from ge_tinarch,GE_TINPL
    where  inar_infa   = p_Infa
    and    inar_fecmov = p_Periodo
    and    inar_numero = p_Numero
    and    inar_cias   = v_cias
    and    inar_formato = INPL_INFR 
    and    inpl_campo = 'INAR_FMPG';
    v_existe_fpag number(10);
    --smcalderon fin 1039 rfc 39471
  Begin
    --
    for r in c_inar_Cias loop
      --
      Inicializa_Estado ( p_Infa, p_Periodo, p_Numero, r.inar_cias ); -- 1012775
      --
      p_Opcion := null;
      v_senal  := 1;
      --
      Valida_Ge_Tcias ( p_Infa,  p_inrq, p_Periodo, p_Numero, r.inar_cias, p_Opcion, p_Msg, v_senal ); -- Soli 5584
      --
      if ( v_senal = 1 ) then   -- OK
        --
        open  c_Cias (r.inar_cias);
        fetch c_Cias into r_Ci;
        close c_Cias;
        --
        update ge_tinarch
        set    inar_valor = -abs(inar_valor),
               inar_signo = null,
             inar_vlrmone = -abs(inar_vlrmone)   -- COMO058
        where  inar_infa   = p_Infa
        and    inar_fecmov = p_Periodo
        and    inar_numero = p_Numero
        and    inar_cias   = r.inar_cias                 -- Soli 5584
        and    inar_signo  = '-';
        --
        -- Actualiza Numero de Renglon si este se encuentra NULO
        --
        update ge_tinarch
        set   inar_Rengln  =  rownum
        where inar_infa    =  p_Infa
        and   inar_fecmov  =  p_Periodo
        and   inar_numero  =  p_Numero
        and   inar_Rengln  is null;
        --
        commit;
        --
        Verifica_TpCo( p_Infa,  p_inrq, r.inar_cias, p_Opcion, p_Msg );
        --
        Valida_Cheques( p_Infa, r.inar_cias, p_Periodo, p_Numero, p_Opcion, p_Msg );
        --
        Valida_Codigos( p_Infa, p_inrq, r.inar_cias, p_Periodo, p_Numero, p_Opcion, p_Msg );
        --
        Valida_Te_Tctrl ( p_Infa,  p_inrq, p_Periodo, p_Numero, r.inar_cias );
        --
        Valida_Cp_Tctrl ( p_Infa,  p_inrq, p_Periodo, p_Numero, r.inar_cias );
        --
        Valida_Pp_Tctrl ( p_Infa,  p_inrq, p_Periodo, p_Numero, r.inar_cias );
        --
        Valida_Fecha_Periodo( p_Infa, r.inar_cias, p_Periodo, p_Numero );
        --
        Valida_Terceros( p_Infa, r.inar_cias, p_Periodo, p_Numero );
        --
        Valida_NCuenta( p_Infa, r.inar_cias, p_Periodo, p_Numero );
        --
        Valida_Bancos( p_Infa, p_inrq, r.inar_cias, p_Periodo, p_Numero );
        --
        dbms_output.put_line('Valida_Impu. Cias='||r.inar_cias|| ' EtPp='||r_ci.cias_EtPp);
        --
        Valida_Impu( p_Infa, r.inar_cias, p_Periodo, p_Numero, r_Ci.cias_EtPp );
        --
        dbms_output.put_line('Valida_Recu. Cias='||r.inar_cias|| ' EtPp='||r_ci.cias_EtRe);
        --
        Valida_Recurso( p_Infa, r.inar_cias, p_Periodo, p_Numero, r_Ci.cias_EtRe );
        --
        Valida_Area( p_Infa, p_inrq, r.inar_cias, p_Periodo, p_Numero, r_Ci.cias_EtAr );
        --
        Valida_CeCo( p_Infa, p_inrq, r.inar_cias, p_Periodo, p_Numero, r_Ci.cias_EtCo );
        --
        Valida_Mayo( p_Infa, r.inar_cias, p_Periodo, p_Numero, r_Ci.cias_EtCt );
        --
        Valida_Cpto_Sucesor( p_Infa, p_inrq, r.inar_cias, p_Periodo, p_Numero );
        --
        Valida_tpmv ( p_Infa, r.inar_cias, p_Periodo, p_Numero, r_Ci.cias_EtCt); -- 1046 lvgomez
        --ini smcalderon 1039 rfc 39471
        open c_fpag(r.inar_cias);
        fetch c_fpag into v_existe_fpag;
        if ( c_fpag%Found ) then
        --INI.COMO058
        Valida_fpag( p_Infa, r.inar_cias, p_Periodo, p_Numero );
        --FIN.COMO058
        sf_pins_error('SMCALDERON p_Infa = '||p_Infa||' r.inar_cias = '||r.inar_cias||' p_Periodo = '||p_Periodo||' p_Numero = ' ||p_Numero);
        end if;
        close c_fpag;
        --fin smcalderon 1039 rfc 39471        
        Valida_MonedaMy( p_Infa, p_inrq , r.inar_cias, p_Periodo, p_Numero );       -- COMO058
        --
        Valida_Factura( p_Infa, r.inar_cias, p_Periodo, p_Numero );                 -- COMO058
        --
        Valida_Aica( p_Infa, p_inrq , r.inar_cias, p_Periodo, p_Numero );   -- 1012484.  ovcaceres.  01/03/2012
        --
        Valida_Impuestos( p_Infa, p_inrq , r.inar_cias, p_Periodo, p_Numero );   -- 1012484.  ovcaceres.  01/03/2012
		--
		--Ini soli_1044 pmp
		--
		VALIDA_CUENTA_BANCO_DESTINO (p_Infa,      --p_Infa,           varchar2,
									 r.inar_cias, --p_cias            integer,
									 p_Periodo,   --p_Periodo         integer,
									 p_Numero     --p_Numero          varchar2   
									 );
		--Fin soli_1044 pmp
		--
        --**    Val_Bases;
        --
        --  Marca como Errados aquellos registros con Valor NULO.
        --
        begin
            update ge_tinarch
            set    inar_Estado = inar_Estado || '(Sin_Vr)'
            where  inar_infa   = p_Infa
            and    inar_fecmov = p_Periodo
            and    inar_numero = p_Numero
            and    inar_cias   = r.inar_cias
            and    inar_Valor  is null;
        end;
        --
        update ge_tinfases
        set    infa_ultfecval = sysdate
        where  infa_infa = p_Infa;
        --
        commit;
        --
      end if;
      --
    end loop;
    --
    Verifica_Errados( p_Infa, p_Periodo, p_Numero, p_Opcion, p_Msg );
    --
  end Validar;
  --
  ------------------------------------------------------------------------------------------------------------
  ------------------------------------------------------------------------------------------------------------
  Procedure Valida_Ge_Tcias (
                             p_Infa           varchar2,
                             p_inrq           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_Cias           integer,
                             p_Opcion     out varchar2,
                             p_Msg        out varchar2,
                             p_senal      out number
                            ) is
    --
    -- Observaciones:
    -- 1. EJ2H- 17-ENE-2006 - Solicitud 5584
    --    . Se valida que la empresa exista y que pertenezca al requerimiento
    --
    v_cias_cias ge_tcias.cias_cias%type;
    --
    cursor c_Cias is
    select cias_cias
    from   ge_tcias
    where  cias_cias = p_cias;
    --
    v_inrq_inrq  ge_vinrq.inrq_inrq%type;
    --
    cursor c_Inrq (
                   pc_cias ge_tcias.cias_cias%type
                  )  is
    select inrq_inrq
    from   ge_vinrq, ge_vcias
    where  cias_cias = inrq_cias
    and    inrq_cias = pc_cias
    and    inrq_inrq = p_inrq;
    --
    v_salida number;
  BEGIN
    --
    v_salida := 1;
    --
    open  c_Cias;
    fetch c_Cias into v_cias_cias;
    if ( c_Cias%notfound ) then
      --
      v_cias_cias := null;
      --
      p_Opcion := 'ERROR';
      p_Msg    := '(Cia) '||p_cias||' no existe';
      v_salida := 0;
      --
      update ge_tinarch
      set    inar_estado = inar_estado||'(Cia)='||p_cias||' No existe.'
      where  inar_infa   = p_Infa
      and    inar_fecmov = p_Periodo
      and    inar_numero = p_Numero
      and    inar_cias   = p_Cias;
      --
      commit;
      --
    end if;
    close c_Cias;
    --

    if ( v_cias_cias is not null ) then
      --
      open  c_Inrq ( v_cias_cias );
      fetch c_Inrq into v_inrq_inrq;
      if ( c_Inrq%notfound ) then
        --
        p_Opcion := 'ERROR';
        p_Msg    := '(Cia) '||p_cias||' no pertenece al requerimiento='||p_inrq;
        v_salida := 0;
        --
        update ge_tinarch
        set    inar_estado = inar_estado||'(Cia)='||p_cias||' No pertenece al requerimiento.'
        where  inar_infa   = p_Infa
        and    inar_fecmov = p_Periodo
        and    inar_numero = p_Numero
        and    inar_cias   = p_Cias;
        --
        commit;
        --
      end if;
      close c_Inrq;
      --
    end if;
    --
    if ( v_salida = 0 ) then
      p_senal := 0;
    else
      p_senal := 1;
    end if;
    --
  End Valida_Ge_Tcias;
  ------------------------------------------------------------------------------------------------------------
  ------------------------------------------------------------------------------------------------------------
  Procedure Valida_Te_Tctrl (
                             p_Infa           varchar2,
                             p_inrq           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_Cias           integer
                            ) is
    --
    -- Observaciones:
    -- 1. EJ2H- 17-ENE-2006 - Solicitud 5584
    --    . Se valida que la empresa exista en tesoreria si la parametrizacion de interfases GE_TINPA
    --      maneja TpMV de Tesoreia INPA_TESOR_TPMV
    --
    --
    v_inar_tesor_tpmv ge_tinarch.inar_tesor_tpmv%type;
    --
    cursor c_inar_tesor_tpmv is
    select inar_tesor_tpmv
    from   ge_tinarch
    where  inar_numero = p_numero
    and    inar_infa   = p_infa
    and    inar_fecmov = p_periodo
    and    inar_cias   = p_cias
    and    inar_tesor_tpmv is not null;
    --
    v_ctrl_cias te_tctrl.ctrl_cias%type;
    --
    cursor c_tctrl is
    select ctrl_cias
    from   te_tctrl
    where  ctrl_cias = p_Cias;
    --
  BEGIN
    --
    open  c_inar_tesor_tpmv;
    fetch c_inar_tesor_tpmv into v_inar_tesor_tpmv;
    if ( c_inar_tesor_tpmv%notfound ) then
      v_inar_tesor_tpmv := null;
    end if;
    close c_inar_tesor_tpmv;
    --
    if ( v_inar_tesor_tpmv is not null ) then
      --
      open  c_tctrl;
      fetch c_tctrl into v_ctrl_cias;
      if ( c_tctrl%notfound ) then
        update ge_tinarch
        set    inar_estado = inar_estado||'(Cia)='||p_cias||' No parametrizada en Tesoreria.'
        where  inar_infa   = p_Infa
        and    inar_fecmov = p_Periodo
        and    inar_numero = p_Numero
        and    inar_cias   = p_Cias;
      end if;
      close c_tctrl;
      --
      commit;
      --
    end if;
    --
  End Valida_Te_Tctrl;
  ------------------------------------------------------------------------------------------------------------
  ------------------------------------------------------------------------------------------------------------
  Procedure Valida_Cp_Tctrl (
                             p_Infa           varchar2,
                             p_inrq           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_Cias           integer
                            ) is
    --
    -- Observaciones:
    -- 1. EJ2H- 17-ENE-2006 - Solicitud 5584
    --    . Se valida que la empresa exista en Cuentas por Pagar si la parametrizacion de interfases GE_TINPA
    --      maneja TpMV de CXP INPA_CXP_TPMV
    --
    --
    v_inar_cxp_tpmv ge_tinarch.inar_cxp_tpmv%type;
    --
    cursor c_inar_cxp_tpmv is
    select inar_cxp_tpmv
    from   ge_tinarch
    where  inar_numero = p_numero
    and    inar_infa   = p_infa
    and    inar_fecmov = p_periodo
    and    inar_cias   = p_cias
    and    inar_cxp_tpmv is not null;

    v_ctrl_cias cp_tctrl.ctrl_cias%type;
    --
    cursor c_tctrl is
    select ctrl_cias
    from   cp_tctrl
    where  ctrl_cias = p_Cias;
    --
  BEGIN
    --
    open  c_inar_cxp_tpmv;
    fetch c_inar_cxp_tpmv into v_inar_cxp_tpmv;
    if ( c_inar_cxp_tpmv%notfound ) then
      v_inar_cxp_tpmv := null;
    end if;
    close c_inar_cxp_tpmv;
    --
    if ( v_inar_cxp_tpmv is not null ) then
      open  c_tctrl;
      fetch c_tctrl into v_ctrl_cias;
      if ( c_tctrl%notfound ) then
        update ge_tinarch
        set    inar_estado = inar_estado||'(Cia)='||p_cias||' No parametrizada en CxP.'
        where  inar_infa   = p_Infa
        and    inar_fecmov = p_Periodo
        and    inar_numero = p_Numero
        and    inar_cias   = p_Cias;
      end if;
      close c_tctrl;
      --
      commit;
      --
    end if;
    --
  End Valida_Cp_Tctrl;
  ------------------------------------------------------------------------------------------------------------
  ------------------------------------------------------------------------------------------------------------
  Procedure Valida_Pp_Tctrl (
                             p_Infa           varchar2,
                             p_inrq           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_Cias           integer
                            ) is
    --
    -- Observaciones:
    -- 1. EJ2H- 17-ENE-2006 - Solicitud 5584
    --    . Se valida que la empresa exista en Presupuesto si la parametrizacion de interfases GE_TINPA
    --      maneja TpMV de PPTO INPA_CXP_TPMV
    --
    --
    v_inar_ppto_tpmv ge_tinarch.inar_ppto_tpmv%type;
    --
    cursor c_inar_ppto_tpmv is
    select inar_ppto_tpmv
    from   ge_tinarch
    where  inar_numero = p_numero
    and    inar_infa   = p_infa
    and    inar_fecmov = p_periodo
    and    inar_cias   = p_cias
    and    inar_tesor_tpmv is not null;
    --

    cursor c_ge_tinpa is
    select inpa_ppto_tpmv
    from   ge_tinpa
    where  inpa_infa = p_infa
    and    inpa_inrq = p_inrq
    and    inpa_ppto_tpmv is not null;
    --
    v_ctrl_cias cp_tctrl.ctrl_cias%type;
    --
    cursor c_tctrl is
    select ctrl_cias
    from   pp_tctrl
    where  ctrl_cias = p_Cias;
    --
  BEGIN
    --
    open  c_inar_ppto_tpmv;
    fetch c_inar_ppto_tpmv into v_inar_ppto_tpmv;
    if ( c_inar_ppto_tpmv%notfound ) then
      v_inar_ppto_tpmv := null;
    end if;
    close c_inar_ppto_tpmv;
    --
    if ( v_inar_ppto_tpmv is not null ) then
      open  c_tctrl;
      fetch c_tctrl into v_ctrl_cias;
      if ( c_tctrl%notfound ) then
        update ge_tinarch
        set    inar_estado = inar_estado||'(Cia)='||p_cias||' No parametrizada en PPTO.'
        where  inar_infa   = p_Infa
        and    inar_fecmov = p_Periodo
        and    inar_numero = p_Numero
        and    inar_cias   = p_Cias;
	      --
	      commit;
	      --
      end if;
      close c_tctrl;
    end if;
    --
  End Valida_Pp_Tctrl;
  ------------------------------------------------------------------------------------------------------------
  ------------------------------------------------------------------------------------------------------------
  procedure Valida_Area ( p_Infa           varchar2,
                          p_inrq           integer,
                          p_Cias           integer,
                          p_Periodo        integer,
                          p_Numero         varchar2,
                          p_EtAr           integer   ) is
    --
    Estado       ge_tinarch.inar_Estado%Type;
    Area_Nueva   ge_tinarch.inar_Ppto_Area%Type;
    Cont_Ceco    ge_tinarch.inar_Cont_CeCo%Type;
    TpImpu       ge_tinarch.inar_TpImpu%Type;
    TpCta        ge_tinarch.inar_TpCta%Type;
    TpCta_Area   ge_tinarch.inar_TpCta_Area%Type;
    Mayo_costo   varchar2(16);
    v_Area       Ge_tArea.Area_Area%type;
    v2_Area      Ge_tArea.Area_Area%type;
    v3_Area      Ge_tArea.Area_Area%type;
    v4_Area      Ge_tArea.Area_Area%type;
    --
    Cursor c_Area_Ppto is
      select distinct Inar_Area_Ppto
      from   Ge_tInarch
      where  Inar_Infa   = p_Infa
      and    Inar_FecMov = p_Periodo
      and    inar_numero = p_Numero
      and    Inar_Cias   = p_Cias
      and    Inar_Ppto_Area is not null;
    --
    Cursor c_Area_Equi is
      select distinct Inar_Area
      from   Ge_tInarch
      where  Inar_Infa   = p_Infa
      and    Inar_FecMov = p_Periodo
      and    inar_numero = p_Numero
      and    Inar_Cias   = p_Cias
      and    Inar_Area is not null;
    --
    Cursor c_Plan_Area is
      select Area_Area
      from   Ge_tArea
      where  Area_Etct   = p_EtAr
      and    Area_TpoMay = 'M'
      and    Area_Area   = v_Area;
    --
    Cursor c_Equi is
      select InEq_Area_Ppto, InEq_Area
      from   Ge_tInEq
      where  InEq_Inrq   = p_inrq
      and    InEq_Infa   = p_Infa
      and    InEq_Dpto   = v_Area;
    --
  BEGIN
    --
    --  VALIDACION DE AREAS CARGADAS POR EL ARCHIVO O EQUIVALENCIAS.
    --
    For i in c_Area_Ppto loop
      --
      Estado := NULL;
      --
      v_Area := i.InAr_Area_Ppto;
      --
      Open c_Plan_Area;
      Fetch c_Plan_Area into v_Area;
      If ( c_Plan_Area%notfound ) then
        --
        Estado := '(Area)';
        --
      End if;
      Close c_Plan_Area;
      --
      If ( Estado is not null ) then
        --
        update Ge_tInarch
        set    Inar_Estado    = Inar_Estado||ESTADO
        where  Inar_Infa      = p_Infa
        and    Inar_FecMov    = p_Periodo
        and    inar_numero    = p_Numero
        and    Inar_Cias      = p_Cias
        and    Inar_Ppto_Area = i.Inar_Area_Ppto;
        --
      End if;
      --
      commit;
      --
    end loop c_Area_Ppto;
    --
    --
    --  VALIDACION DE AREAS DEL ARCHIVO VS EQUIVALENCIAS.
    --
    --
    for i in c_Area_Equi loop
      --
      Estado := NULL;
      --
      v_Area := i.Inar_Area;
      --
      Open c_Plan_Area;
      Fetch c_Plan_Area into v2_Area;
      If ( c_Plan_Area%notfound ) then
        --
        Open c_Equi;
        Fetch c_Equi into v3_Area, v4_Area;
        if ( c_Equi%notfound ) then
          --
          Estado := '(AreaEq)';
          --
        end if;
        Close c_Equi;
        --
      End if;
      Close c_Plan_Area;
      --
      If ( Estado is not null ) then
        --
        update Ge_tInArch
        set    InAr_Estado = Inar_Estado||ESTADO
        where  InAr_Infa   = p_Infa
        and    InAr_FecMov = p_Periodo
        and    inar_numero = p_Numero
        and    InAr_Cias   = p_Cias
        and    InAr_Area   = i.InAr_Area;
        --
      End if;
      --
      commit;
      --
    end loop c_Area_Equi;
    --
  end Valida_Area;
  --
  --
  --
  procedure Valida_Bancos ( p_Infa           varchar2,
                            p_inrq           integer,
                            p_Cias           integer,
                            p_Periodo        integer,
                            p_Numero         varchar2   ) is
    --
    -- Modificaciones:
    -- 1. Almoto - 18 junio 2003 ( ITC ) - Solicitud 1611
    --    . Al validar cuentas bancarias se tiene en cuenta que esten A-ACTIVAS
    --
    Nit     number(15);
    Mayo    varchar2(16);
    Estado  varchar2(6);        -- rbermudez -- soli 1042
    Descri  varchar2(120);
    --
    v_inpa_Campo1  varchar2(20);
    --
    cursor c_inpa is
    select distinct inpa_Campo1, inpa_Campo2, inpa_Campo3, inpa_Campo4, inpa_Campo5,
                    inpa_Campo6, inpa_Campo7, inpa_Campo8, inpa_Campo9, inpa_Campo10
      from ge_tinpa, te_ttpmv
     where INPA_INFA      = p_Infa
       and inpa_inrq      = p_inrq
       and inpa_cont_tpco is not null
       and inpa_cont_mayo is null
       and tpmv_tpmv      = inpa_tesor_Tpmv
       and tpmv_Solicita_Enti = 'S';
    --
    cursor c_inar ( pc_Ca1 varchar2, pc_Ca2 varchar2, pc_Ca3 varchar2, pc_Ca4 varchar2, pc_Ca5  varchar2,
                    pc_Ca6 varchar2, pc_Ca7 varchar2, pc_Ca8 varchar2, pc_Ca9 varchar2, pc_Ca10 varchar2 ) is
    select distinct inar_nit_asociado
      from ge_tinarch
     where inar_infa              = p_Infa
       and inar_fecmov            = p_Periodo
       and inar_numero            = p_Numero
       and inar_cias              = p_Cias
       and INAR_CAMPO1            = pc_Ca1
       and nvl(INAR_CAMPO2,'*-*') = nvl(pc_Ca2, '*-*')
       and nvl(INAR_CAMPO3,'*-*') = nvl(pc_Ca3, '*-*')
       and nvl(INAR_CAMPO4,'*-*') = nvl(pc_Ca4, '*-*')
       and nvl(INAR_CAMPO5,'*-*') = nvl(pc_Ca5, '*-*')
       and nvl(INAR_CAMPO6,'*-*') = nvl(pc_Ca6, '*-*')
       and nvl(INAR_CAMPO7,'*-*') = nvl(pc_Ca7, '*-*')
       and nvl(INAR_CAMPO8,'*-*') = nvl(pc_Ca8, '*-*')
       and nvl(INAR_CAMPO9,'*-*') = nvl(pc_Ca9, '*-*')
       and nvl(INAR_CAMPO10,'*-*') = nvl(pc_Ca10, '*-*');
    --
  Begin
    --
    for i in c_inpa loop
      --
      open c_inar( i.inpa_Campo1, i.inpa_Campo2, i.inpa_Campo3, i.inpa_Campo4, i.inpa_Campo5,
                   i.inpa_Campo6, i.inpa_Campo7, i.inpa_Campo8, i.inpa_Campo9, i.inpa_Campo10 );
      loop
        fetch c_inar into nit;
        exit when c_inar%notfound;
        --
        Begin
          select enti_mayo, auxi_descri
            into mayo, descri
            from ge_tenti, ge_tauxil
           where enti_auxi = auxi_auxi
             and nvl(enti_Status, 'A') = 'A'   --- Soli_1611
             and auxi_nit  = nit;
          --
          Estado := '';
          Exception
            when no_data_found then
              Estado := '(Enti)';
        End;
        --
        update ge_tinarch
           set INAR_ESTADO = INAR_ESTADO||Estado,
               inar_cont_mayo = mayo
         where inar_infa   = p_Infa
           and inar_fecmov = p_Periodo
           and inar_numero = p_numero
           and inar_cias   = p_Cias
           and INAR_CAMPO1 = i.inpa_Campo1
           and nvl(INAR_CAMPO2,'*-*') = nvl(i.inpa_Campo2,'*-*')
           and nvl(INAR_CAMPO3,'*-*') = nvl(i.inpa_Campo3,'*-*')
           and nvl(INAR_CAMPO4,'*-*') = nvl(i.inpa_Campo4,'*-*')
           and nvl(INAR_CAMPO5,'*-*') = nvl(i.inpa_Campo5,'*-*')
           and nvl(INAR_CAMPO6,'*-*') = nvl(i.inpa_Campo6,'*-*')
           and nvl(INAR_CAMPO7,'*-*') = nvl(i.inpa_Campo7,'*-*')
           and nvl(INAR_CAMPO8,'*-*') = nvl(i.inpa_Campo8,'*-*')
           and nvl(INAR_CAMPO9,'*-*') = nvl(i.inpa_Campo9,'*-*')
           and nvl(INAR_CAMPO10,'*-*') = nvl(i.inpa_Campo10,'*-*')
           and inar_nit_asociado = nit;
        --
        commit;
        --
      end loop;
      close c_inar;
      --
    end loop c_inpa;
    --
    commit;
    --
  end Valida_Bancos;
  --
  --
  --
  Procedure Valida_Ceco ( p_Infa           varchar2,
                          p_inrq           integer,
                          p_Cias           integer,
                          p_Periodo        integer,
                          p_Numero         varchar2,
                          p_EtCo           integer   ) is
    --
    Estado       ge_tinarch.inar_Estado%Type;
    Area_Nueva   ge_tinarch.inar_Ppto_Area%Type;
    Cont_Ceco    ge_tinarch.inar_Cont_CeCo%Type;
    TpImpu       ge_tinarch.inar_TpImpu%Type;
    TpCta        ge_tinarch.inar_TpCta%Type;
    TpCta_Area   ge_tinarch.inar_TpCta_Area%Type;
    Mayo_costo   varchar2(16);
    v_ceco       Ge_tcecos.ceco_ceco%type;
    v2_ceco      Ge_tcecos.ceco_ceco%type;
    v3_ceco      Ge_tcecos.ceco_ceco%type;
    v4_ceco      Ge_tcecos.ceco_ceco%type;
    --
    Cursor c_Ceco is
      select distinct Inar_cont_ceco
      from   Ge_tInarch
      where  Inar_Infa   = p_Infa
      and    Inar_FecMov = p_Periodo
      and    inar_numero = p_Numero
      and    Inar_Cias   = p_Cias
      and    Inar_cont_ceco is not null;
    --
    Cursor c_Plan_ceco (pc_ceco Ge_tcecos.ceco_Ceco%type )is
      select ceco_Ceco
      from   Ge_tcecos
      where  ceco_Etct   = p_etco
      and    Ceco_TpoMay = 'M'
      and    Ceco_Ceco   = pc_Ceco;
    --
    Cursor c_Equi is
      select InEq_Area_Ppto, InEq_Area
      from   Ge_tInEq
      where  InEq_Inrq   = p_inrq
      and    InEq_Infa   = p_Infa
      and    InEq_Dpto   = v_Ceco;

    --
  BEGIN
    --
    --  VALIDACION DE CENTROS DE COSTO CARGADAS POR EL ARCHIVO O EQUIVALENCIAS.
    --
    --
    For i in c_Ceco loop
      --
      Estado := NULL;
      --
      --v_Ceco := i.InAr_cont_ceco;
      --
      Open c_Plan_ceco (i.InAr_cont_ceco);
      Fetch c_Plan_ceco into v_ceco;
      If ( c_Plan_ceco%notfound ) then
        --
        Estado := '(Ceco)='||i.InAr_cont_ceco||' etco='||p_etco;
        --
      End if;
      Close c_Plan_Ceco;
      --
      If ( Estado is not null ) then
        --
        update Ge_tInarch
        set    Inar_Estado    = Inar_Estado||ESTADO
        where  Inar_Infa      = p_Infa
        and    Inar_FecMov    = p_Periodo
        and    inar_numero    = p_Numero
        and    Inar_Cias      = p_Cias
        and    Inar_cont_ceco = i.Inar_cont_ceco;
        --
      End if;
      --
      commit;
      --
    end loop c_CeCo;
    --
  end Valida_CeCo;
  --
  --
  --
  PROCEDURE Valida_Cheques ( p_Infa           varchar2,
                             p_Cias           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_Opcion     out varchar2,
                             p_Msg        out varchar2  ) is
    --
    -- Modificaciones:
    -- 1. Almoto - 18 junio 2003 ( ITC ) - Solicitud 1611
    --    . Al validar cuentas bancarias se tiene en cuenta que esten A-ACTIVAS
    --
    -- 2. Geovanni 01/07/2003  (ITC) - Solicitud 1597
    --    . Al validar el numero del cheque se tiene en cuenta desde el Ultimo cheque Usado(chra_ultimo)
    --      Hasta el Ultimo numero de cheque (chra_chehas). Esto en el primer Select.
    --
    v_Qcant_cheq  number;
    v_enti        ge_tenti.enti_auxi%type;
    v_estado       varchar2(10);
    qcant            number;
    v_max            number;
    v_min            number;
    --
    cursor Cheque is
    select inar_ncuenta, min(inar_cheque) minimo, max(inar_cheque) maximo, count(*) Cont
      from ge_tinarch
     where inar_infa   = p_Infa
       and inar_fecmov = p_Periodo
       and inar_numero = p_numero
       and inar_cias   = p_Cias
       and inar_ncuenta is not null
       and inar_cheque  is not null
       and not exists ( select 'c'
                          from ge_tauxil, ge_tenti, te_tchra
                         where chra_cias   = p_Cias
                           and chra_enti   = enti_auxi
                           and enti_auxi   = auxi_auxi
                           and enti_cias+0 = p_Cias
                           and nvl(enti_Status, 'A') = 'A'   --- Soli_1611
                           and auxi_nit    = inar_ncuenta
                           and inar_cheque between nvl(chra_ultimo,0)+1 and chra_chehas
                       )
     group by inar_ncuenta;
    --
  BEGIN
    --
    --
    For i in Cheque loop
      --
      If i.Cont <> 0 then
         --
         p_Opcion := 'ERROR';
         p_Msg    := 'Existen : '||i.cont||' cheques sin Chequera Para la cuenta Nro. '||i.inar_ncuenta|| ' ARCHIVO Desde Cheque '||i.minimo||' Hasta cheque: '||i.maximo;
         --
         return;
         --
      End If;
    end loop;
    --
    if ( p_Opcion = 'ERROR' ) then
      p_Msg := 'Por ahora no pasaria por aqui.  Esta parte es util se por ejemplo si se maneja una tabla temporal.';
    end if;
    --
    --
  end Valida_Cheques;
  --
  --
  --
  Procedure Valida_Codigos ( p_Infa           varchar2,
                             p_inrq           integer,
                             p_Cias           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_Opcion     out varchar2,
                             p_Msg        out varchar2  ) is
    --
    v_Procesa     ge_tinpa.inpa_Procesa%Type;
    v_Estado      varchar2(20);
    --
    cursor c_inar is
    select distinct inar_Campo1, inar_Campo2, inar_Campo3, inar_Campo4, inar_Campo5, inar_Campo6,
                    inar_Campo7, inar_Campo8, inar_Campo9, inar_Campo10
      from ge_tinarch
     where inar_infa   = p_Infa
       and inar_fecmov = p_Periodo
       and inar_numero = p_numero
       and inar_cias   = p_Cias;
    --
    v_actualiza         varchar2(1) := 'N';     --1011740 24/01/2012 ymoreno
    --
  BEGIN
    --
    p_Opcion := 'OK';
    --
    for i in c_inar loop
      --
      v_Estado := '';
      --
      Begin
        select inpa_Procesa
        into   v_Procesa
        from   ge_tinpa
        where  INPA_INFA =  p_Infa
        and    inpa_inrq =  p_inrq
        and    INPA_CAMPO1  = i.inar_Campo1
        and    nvl(INPA_CAMPO2,'*-*') = nvl(i.inar_Campo2,'*-*')
        and    nvl(INPA_CAMPO3,'*-*') = nvl(i.inar_Campo3,'*-*')
        and    nvl(INPA_CAMPO4,'*-*') = nvl(i.inar_Campo4,'*-*')
        and    nvl(INPA_CAMPO5,'*-*') = nvl(i.inar_Campo5,'*-*')
        and    nvl(INPA_CAMPO6,'*-*') = nvl(i.inar_Campo6,'*-*')
        and    nvl(INPA_CAMPO7,'*-*') = nvl(i.inar_Campo7,'*-*')
        and    nvl(INPA_CAMPO8,'*-*') = nvl(i.inar_Campo8,'*-*')
        and    nvl(INPA_CAMPO9,'*-*') = nvl(i.inar_Campo9,'*-*')
        and    nvl(INPA_CAMPO10,'*-*') = nvl(i.inar_Campo10,'*-*');
        --
        v_Estado := 'B';
        --
        Exception
          when no_data_found then
            v_Estado := 'E';
            --
            --ini.1011740 24/01/2012 ymoreno
            v_actualiza := 'S';
            --
            update ge_tinarch
              set inar_estado  = v_Estado||'(Codigo Oblig.) '
             where inar_infa   = p_Infa
             and inar_fecmov   = p_Periodo
             and inar_numero   = p_numero
             and inar_cias     = p_Cias
             and inar_Campo1   = i.inar_Campo1
             and nvl(inar_Campo2,'*-*') = nvl(i.inar_Campo2,'*-*')
             and nvl(inar_Campo3,'*-*') = nvl(i.inar_Campo3,'*-*')
             and nvl(inar_Campo4,'*-*') = nvl(i.inar_Campo4,'*-*')
             and nvl(inar_Campo5,'*-*') = nvl(i.inar_Campo5,'*-*')
             and nvl(inar_Campo6,'*-*') = nvl(i.inar_Campo6,'*-*')
             and nvl(inar_Campo7,'*-*') = nvl(i.inar_Campo7,'*-*')
             and nvl(inar_Campo8,'*-*') = nvl(i.inar_Campo8,'*-*')
             and nvl(inar_Campo9,'*-*') = nvl(i.inar_Campo9,'*-*')
             and nvl(inar_Campo10,'*-*') = nvl(i.inar_Campo10,'*-*');
            --
            --fin.1011740 24/01/2012 ymoreno
            --
          when too_many_rows then
            p_Msg := 'Codigos estan parametrizados dobles. CAMPO 1:'||i.inar_Campo1||' CAMPO 2:'||i.inar_Campo2 ||' CAMPO 3:'||i.inar_Campo3;
            p_Opcion := 'ERROR';
            return;
      end;
      --
      if ( v_Procesa = 'N' ) then
        --
        delete ge_tinarch
        where  INAR_INFA    = p_Infa
        and    INAR_FECMOV  = p_Periodo
        and    inar_numero  = p_Numero
        and    inar_cias    = p_Cias
        and    inar_Campo1  = i.inar_Campo1
        and    nvl(inar_Campo2,'*-*') = nvl(i.inar_Campo2,'*-*')
        and    nvl(inar_Campo3,'*-*') = nvl(i.inar_Campo3,'*-*')
        and    nvl(inar_Campo4,'*-*') = nvl(i.inar_Campo4,'*-*')
        and    nvl(inar_Campo5,'*-*') = nvl(i.inar_Campo5,'*-*')
        and    nvl(inar_Campo6,'*-*') = nvl(i.inar_Campo6,'*-*')
        and    nvl(inar_Campo7,'*-*') = nvl(i.inar_Campo7,'*-*')
        and    nvl(inar_Campo8,'*-*') = nvl(i.inar_Campo8,'*-*')
        and    nvl(inar_Campo9,'*-*') = nvl(i.inar_Campo9,'*-*')
        and    nvl(inar_Campo10,'*-*') = nvl(i.inar_Campo10,'*-*');
        --
      else
        --
        if v_actualiza = 'N' then                                   --1011740 24/01/2012 ymoreno
          update ge_tinarch
          set    inar_estado  = v_Estado
          where  INAR_INFA    = p_Infa
          and    INAR_FECMOV  = p_Periodo
          and    inar_numero  = p_Numero
          and    inar_cias    = p_Cias
          and    inar_Campo1  = i.inar_Campo1
          and    nvl(inar_Campo2,'*-*') = nvl(i.inar_Campo2,'*-*')
          and    nvl(inar_Campo3,'*-*') = nvl(i.inar_Campo3,'*-*')
          and    nvl(inar_Campo4,'*-*') = nvl(i.inar_Campo4,'*-*')
          and    nvl(inar_Campo5,'*-*') = nvl(i.inar_Campo5,'*-*')
          and    nvl(inar_Campo6,'*-*') = nvl(i.inar_Campo6,'*-*')
          and    nvl(inar_Campo7,'*-*') = nvl(i.inar_Campo7,'*-*')
          and    nvl(inar_Campo8,'*-*') = nvl(i.inar_Campo8,'*-*')
          and    nvl(inar_Campo9,'*-*') = nvl(i.inar_Campo9,'*-*')
          and    nvl(inar_Campo10,'*-*') = nvl(i.inar_Campo10,'*-*');
        --
        end if;
        --
      end if;
      --
      commit;
      --
    end loop c_inar;
    --
    commit;
    --
  end Valida_Codigos;
  --
  --
  --
  procedure Valida_Fecha_Periodo ( p_Infa           varchar2,
                                   p_Cias           integer,
                                   p_Periodo        integer,
                                   p_Numero         varchar2   ) is
    --
    Fecha    ge_tinarch.inar_Fecha%Type;
    Estado   ge_tinarch.inar_Estado%Type;
    Periodo  number;
    Fecha2   date;
    --
    Cursor inar is
      select distinct inar_Fecha
      from   ge_tinarch
      where  inar_infa   = p_Infa
      and    inar_fecmov = p_Periodo
      and    inar_numero = p_Numero
      and    inar_cias   = p_Cias;
    --
  BEGIN
    for i in inar loop
      Estado  := null;
      Fecha   := i.inar_Fecha;
      begin
        Fecha2  := to_date(Fecha, 'dd/mm/yyyy');
        exception
          when others then
            Estado := '(Mal.Formato.Fcha)';
      end;
      if (Estado is null) then
        Periodo := to_char(Fecha2, 'yyyymm');
        if (Periodo <> p_Periodo) then
          Estado := '(Fch.<>Periodo)';
        end if;
      end if;
      --
      if (Estado is not null) then
        update ge_tinarch
        set    inar_Estado = inar_Estado||Estado
        where  inar_infa   = p_Infa
        and    inar_fecmov = p_Periodo
        and    inar_numero = p_Numero
        and    inar_cias   = p_Cias
        and    inar_Fecha  = i.inar_Fecha;
      end if;
    end loop;
    --
  end Valida_Fecha_Periodo;
  --
  --
  --
  procedure Valida_Impu ( p_Infa           varchar2,
                          p_Cias           integer,
                          p_Periodo        integer,
                          p_Numero         varchar2,
                          p_EtPp           integer   ) is
    --
    Estado varchar2(1);
    Impu   Pp_tImpu.Impu_Impu%type;
    --
    cursor C1 is
      select distinct INAR_impu
      from   ge_tinarch
      where  inar_infa   = p_Infa
      and    inar_fecmov = p_Periodo
      and    inar_numero = p_Numero
      and    inar_cias   = p_Cias;
  --
  BEGIN
    --
    open c1;
    loop
      Fetch c1 into impu;
      exit when c1%notfound;
      --
      Estado := '';
      --
      Begin
        select ''
        into   estado
        from   PP_TIMPU
        where  IMPU_IMPU = IMPU
        and    IMPU_ETCT = p_EtPp;
        --
        Exception
          when no_data_found then
            estado := 'I';
          WHEN TOO_MANY_ROWS THEN
            estado := '';
      End;
      --
      IF ESTADO = 'I' THEN
        update ge_tinarch
        set    inar_estado = INAR_ESTADO||'(Impu)'
        where  inar_infa   = p_Infa
        and    inar_fecmov = p_Periodo
        and    inar_numero = p_Numero
        and    inar_cias   = p_Cias
        and    INAR_IMPU   = IMPU;
        --
        commit;
        --
      END IF;
    End loop;
    Close c1;
    commit;
    --
  end Valida_Impu;
  --
  --
  --
  procedure Valida_Mayo ( p_Infa           varchar2,
                          p_Cias           integer,
                          p_Periodo        integer,
                          p_Numero         varchar2,
                          p_EtCt           integer   ) is
    --*
    --*    inar_mayo  -------> lo trae el archivo
    --*    inar_cont_mayo ---> lo crea
    --*
    Estado             varchar2(1);
    etad               number(3);
    Cont_Mayo          ge_tinarch.inar_Cont_Mayo%Type;
    MayoDescri         ge_tmayor.mayo_Descri%Type;
    Tiene_Area         ge_tmayor.mayo_Area%Type;
    Tiene_CeCo         ge_tmayor.mayo_CeCo%Type;
    --
    cursor C1 is
      select distinct INAR_CONT_mayo
      from   ge_tinarch
      where  inar_infa   = p_Infa
      and    inar_fecmov = p_Periodo
      and    inar_numero = p_Numero
      and    inar_cias   = p_Cias;
    --
  BEGIN
    --
    open c1;
    loop
      --
      Fetch c1 into cont_Mayo;
      exit when c1%notfound;
      --
      --
      Estado := null;
      --
      Begin
        select mayo_etad, mayo_Area, mayo_Ceco
        into   etad, Tiene_Area, Tiene_CeCo
        from   ge_tmayor
        where  mayo_etct   = p_EtCt
        and    mayo_mayo   = cont_mayo
        and    mayo_TpoMay = 'M';
        --
        update ge_tinarch
        set    inar_etad            = etad,
               inar_mayo_tiene_Area = Tiene_Area,
               inar_mayo_tiene_ceco = Tiene_ceco
        where  inar_infa   = p_Infa
        and    inar_fecmov = p_Periodo
        and    inar_numero = p_Numero
        and    inar_cias   = p_Cias
        and    INAR_mayo   = cont_mayo;
        --
        Exception
          when no_data_found then
            estado := 'M';
          WHEN TOO_MANY_ROWS THEN
            estado := null;
      End;
      --
      IF ESTADO = 'M' THEN
        --
        update ge_tinarch
        set    inar_estado = INAR_ESTADO||'(My:' || Cont_Mayo ||')'
        where  inar_infa   = p_Infa
        and    inar_fecmov = p_Periodo
        and    inar_numero = p_Numero
        and    inar_cias   = p_Cias
        and    INAR_mayo   = cont_mayo;
        --
        commit;
        --
      END IF;
      --
    End loop;
    --
    Close c1;
    commit;
    --
  end Valida_Mayo;
  --
  --
  --
  PROCEDURE Valida_NCuenta ( p_Infa           varchar2,
                             p_Cias           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2   ) is
    --
    -- Modificaciones:
    -- 1. Almoto - 18 junio 2003 ( ITC ) - Solicitud 1611
    --    . Al validar cuentas bancarias se tiene en cuenta que esten A-ACTIVAS
    --
    --
    v_QRegi        integer;
    v_inar_Campo1  varchar2(20);
    --
    cursor ncuenta is
    select distinct inar_campo1, inar_ncuenta
      from ge_tinarch
     where inar_infa   = p_Infa
       and inar_fecmov = p_Periodo
       and inar_numero = p_numero
       and inar_cias   = p_Cias
       and inar_ncuenta is not null;
    --
  BEGIN
    --
    --
    for i in ncuenta loop
      --
      v_inar_Campo1 := i.inar_campo1;
      --
      Begin
        select count(*)
          into v_QRegi
          from ge_tenti, ge_tauxil
         where enti_auxi   = auxi_auxi
           and enti_cias+0 = p_Cias
           and nvl(enti_Status, 'A') = 'A'   --- Soli_1611
           and auxi_nit    = i.inar_ncuenta;
      End;
      --
      if ( v_QRegi = 0 ) then
        --
        update ge_tinarch
        set    inar_estado = inar_estado||'(NCta)'||i.inar_ncuenta||'(Cias)='||p_cias
        where  inar_infa   = p_Infa
        and    inar_fecmov = p_Periodo
        and    inar_numero = p_Numero
        and    inar_cias   = p_Cias
        and    inar_campo1 = v_inar_Campo1
        and    inar_ncuenta is not null;
        --
      end if;
      --
    end loop;
    --
    commit;
    --
  end Valida_NCuenta;
  --
  --
  --
  procedure Valida_Recurso ( p_Infa           varchar2,
                             p_Cias           integer,
                             p_Periodo        integer,
                             p_Numero         varchar2,
                             p_EtRe           integer   ) is
    --
    v_Estado   varchar2(1);
    v_Recu     pp_tRecu.Recu_Recu%Type;
    --
    cursor c_Recu is
      select distinct INAR_Recu
      from   ge_tinarch
      where  inar_infa   = p_Infa
      and    inar_fecmov = p_Periodo
      and    inar_numero = p_Numero
      and    inar_cias   = p_Cias;
    --
    cursor c_Recu_Fuente is
      select distinct inar_Recu_Fuente
      from   ge_tinarch
      where  inar_infa   = p_Infa
      and    inar_fecmov = p_Periodo
      and    inar_numero = p_Numero
      and    inar_cias   = p_Cias
      and    inar_Recu_Fuente is not null;
    --
  BEGIN
    --
    --
    open c_Recu;
    loop
      Fetch c_Recu into v_Recu;
      exit when c_Recu%notfound;
      --
      v_Estado := '';
      --
      Begin
        select ''
        into   v_Estado
        from   PP_TRecu
        where  Recu_Recu = v_Recu
        and    Recu_etct = p_EtRe;
        Exception
          when no_data_found then
            v_Estado := 'R';
          WHEN TOO_MANY_ROWS THEN
            v_Estado := '';
      End;
      --
      IF v_Estado = 'R' THEN
        --
        update ge_tinarch
        set    inar_Estado = INAR_Estado||'(Recu)'
        where  inar_infa   = p_Infa
        and    inar_fecmov = p_Periodo
        and    inar_numero = p_Numero
        and    inar_cias   = p_Cias
        and    INAR_Recu   = v_Recu;
        --
        commit;
        --
      END IF;
    End loop;
    Close c_Recu;
    commit;
    --
    --
    open c_Recu_Fuente;
    loop
      Fetch c_Recu_Fuente into v_Recu;
      exit when c_Recu_Fuente%notfound;
      --
      v_Estado := '';
      --
      Begin
        select ''
        into   v_Estado
        from   PP_TRecu
        where  Recu_Recu = v_Recu
        and    Recu_etct = p_EtRe;
        Exception
          when no_data_found then
            v_Estado := 'R';
          WHEN TOO_MANY_ROWS THEN
            v_Estado := '';
      End;
      --
      IF v_Estado = 'R' THEN
        --
        update ge_tinarch
        set    inar_Estado      = INAR_Estado||'(RecuFuente)'
        where  inar_infa        = p_Infa
        and    inar_fecmov      = p_Periodo
        and    inar_numero      = p_Numero
        and    inar_cias        = p_Cias
        and    INAR_Recu_Fuente = v_Recu;
        --
        commit;
        --
      END IF;
    End loop;
    Close c_Recu_Fuente;
    commit;
    --
  end Valida_Recurso;
  --
  --
  --
  procedure Valida_Terceros ( p_Infa           varchar2,
                              p_Cias           integer,
                              p_Periodo        integer,
                              p_Numero         varchar2 ) is
    --
    TERCERO   NUMBER(15);
    ASOCIADO  NUMBER(15);
    AGRUPA    NUMBER(15);
    Status    varchar2(1);
    Tipo      varchar2(2);
    Auxi      number;
    Mayo      varchar2(16);
    --
    cursor C1 is
    select distinct INAR_TERCERO
      from ge_tinarch
     where inar_infa    =  p_Infa
       and inar_fecmov  =  p_Periodo
       and inar_numero  =  p_Numero
       and inar_tercero is not null;
    --
    cursor C2 is
    select distinct INAR_NIT_ASOCIADO
      from ge_tinarch
     where inar_infa    =  p_Infa
       and inar_fecmov  =  p_Periodo
       and inar_numero  =  p_Numero
       and inar_nit_asociado is not null;
    --
    cursor C3 is
    select distinct INAR_NIT_AGRUPA
      from ge_tinarch
     where inar_infa   = p_Infa
       and inar_fecmov = p_Periodo
       and inar_numero = p_numero
       and inar_nit_agrupa is not null;
    --
  BEGIN
    --
    update ge_tinarch
    set    inar_tercero = 1
    where  inar_Infa    = p_Infa
    and    inar_FecMov  = p_Periodo
    and    inar_numero  = p_Numero
    and    inar_cias    = p_Cias
    and    nvl(inar_tercero, 0) = 0;
    --
    commit;
    --
    update ge_tinarch
    set    inar_nit_asociado = 1
    where  inar_Infa    = p_Infa
    and    inar_FecMov  = p_Periodo
    and    inar_numero  = p_Numero
    and    inar_cias    = p_Cias
    and    nvl(inar_nit_asociado, 0) = 0;
    --
    commit;
    --
    update ge_tinarch
    set    inar_nit_agrupa = 1
    where  inar_Infa    = p_Infa
    and    inar_FecMov  = p_Periodo
    and    inar_numero  = p_Numero
    and    inar_cias    = p_Cias
    and    nvl(inar_nit_agrupa, 0) = 0;
    --
    commit;
    --
    Open c1;
    loop
      --
      Fetch c1 into tercero;
      exit when c1%notfound;
      --
      -- Valida tercero
      --
      begin
        --
        select auxi_auxi
        into   auxi
        from   ge_tauxil
        where  auxi_nit = tercero;
        --
        exception
          when no_data_found then
            update ge_tinarch
            set    INAR_ESTADO  = INAR_ESTADO||'(Terc)'
            where  inar_Infa    = p_Infa
            and    inar_FecMov  = p_Periodo
            and    inar_numero  = p_Numero
            and    inar_tercero = tercero;
            --
            commit;
            --
      End;
    end loop;
    close c1;
    commit;
    --
    --
    -- Valida nit asociado
    --
    Open c2;
    loop
      Fetch c2 into asociado;
      exit when c2%notfound;
      --
      Begin
        select auxi_auxi, auxi_tipo
        into   auxi, tipo
        from   ge_tauxil
        where  auxi_nit = ASOCIADO;
        --
        Exception
          when no_data_found then
            update ge_tinarch
            set    INAR_ESTADO = INAR_ESTADO||'(Asoc)'
            where  inar_Infa    = p_Infa
            and    inar_FecMov  = p_Periodo
            and    inar_numero  = p_Numero
            and    inar_cias    = p_Cias
            and    inar_nit_asociado = asociado;
            --
            commit;
            --
      End;
    end loop;
    close c2;
    commit;
    --
    --
    -- Valida Nit agrupacion
    --
    --
    open c3;
    loop
      Fetch c3 into agrupa;
      exit when c3%notfound;
      --
      --
      begin
        select 'G'
        into   status
        from   ge_tauxil
        where  auxi_nit = AGRUPA;
        --
        Exception
          when no_data_found then
            update ge_tinarch
            set    INAR_ESTADO = INAR_ESTADO ||'(Agru)'
            where  inar_Infa       = p_Infa
            and    inar_FecMov     = p_Periodo
            and    inar_numero     = p_Numero
            and    inar_cias       = p_Cias
            and    inar_nit_Agrupa = agrupa;
            --
            commit;
            --
      End;
    end loop;
    close c3;
    commit;
    --
  end Valida_Terceros;
  --
  --
  --
  procedure Verifica_Tpco ( p_Infa           varchar2,
                            p_inrq           integer,
                            p_Cias           integer,
                            p_Opcion     out varchar2,
                            p_Msg        out varchar2  ) is
    --
    v_tpco     ge_ttpco.tpco_tpco%type;
    v_tpcoe    ge_ttpco.tpco_tpco%type;
    v_tpco_x   ge_ttpco.tpco_tpco%type;
    v_tpcoe_x  ge_ttpco.tpco_tpco%type;
    --
    cursor c_TpCo is
    select distinct inpa_cont_tpco tpco, inpa_cont_tpcoe tpcoe
      from ge_tinpa
     where inpa_infa = p_Infa
       and inpa_inrq = p_inrq
       and inpa_cont_tpco is not null
    union
    select distinct inpa_tesor_tpco tpco, inpa_tesor_tpcoe tpcoe
      from ge_tinpa
     where inpa_inrq = p_inrq
       and inpa_infa = p_Infa
       and inpa_tesor_tpco is not null;
    --
    cursor c_ge_ttpco is
    select tpco_tpco
      from ge_ttpco
     where tpco_tpco = v_tpco
       and tpco_clase is null;
    --
    cursor c_ge_ttpcoe is
    select tpco_tpco
      from ge_ttpco
     where tpco_tpco  = v_tpcoe
       and tpco_clase = v_tpco;
    --
  begin
    --
    For i in c_tpco loop
      --
      v_tpco  := i.tpco;
      v_tpcoe := i.tpcoe;
      --
      open c_ge_ttpco;
      Fetch c_ge_ttpco into v_tpco_x;
      if ( c_ge_ttpco%notfound ) then
        --
        close c_ge_ttpco;
        p_Msg    := 'Tpo.Comprob.Generico '|| v_tpco || ' NO EXISTE';
        p_Opcion := 'ERROR';
        return;
        --
      end if;
      close c_ge_ttpco;
      --
      --
      open c_ge_ttpcoe;
      fetch c_ge_ttpcoe into v_tpcoe_x;
      if ( c_ge_ttpcoe%notfound ) then
        --
        close c_ge_ttpcoe;
        p_Msg    := 'Tpo.Comprob.Especifico ' || v_tpcoe || ' NO EXISTE o NO PERTENECE al Generico '|| v_tpco;
        p_Opcion := 'ERROR';
        return;
        --
      end if;
      close c_ge_ttpcoe;
      --
    end loop c_tpco;
    --
  end Verifica_Tpco;
  --
  --
  --
  procedure VERIFICA_CIERRES ( p_Infa           varchar2,
                               p_inrq           integer,
                               p_Periodo        integer,
                               p_Numero         varchar2,
                               p_Fech_Proc      date,
                               p_Opcion     out varchar2,
                               p_Msg        out varchar2  ) is
    --
    v_fecha   date;
    v_period  number;
    --
    cursor c_inar is
    select distinct inar_cias, inar_fecha
      from ge_tinarch
     where inar_infa   = p_Infa
       and inar_fecmov = p_Periodo
       and inar_numero = p_numero;
    --
    cursor c_pp_ctrl ( pc_Cias  integer ) is
    select ctrl_fecha_cierre, ctrl_vigci, ctrl_mesci, ctrl_tipo_cierre
      from pp_tctrl
     where ctrl_cias =  pc_Cias;
    --
    cursor c_cias ( pc_Cias integer ) is
    select cias_periodo_actual, /* 1012992 */ cias_cndpre
      from ge_vcias
     where cias_cias =  pc_Cias;
    --
    v_Per_Actual   integer;       -- Soli_6023
	v_cias_cndpre           ge_vcias.cias_cndpre %type;         -- 1012992
    v_cias_periodo_actual   ge_vcias.cias_periodo_actual %type; -- 1012992
    --
  BEGIN
    --
    p_Opcion := 'OK';
    --
    for i in c_inar loop
      --
      v_fecha := nvl(p_Fech_Proc, Car_a_Fecha( i.inar_fecha ));

    -- incio 1012992
      open c_cias ( i.inar_Cias );
      fetch c_cias into  v_cias_periodo_actual, v_cias_cndpre;
      close c_cias;
      --
      if v_cias_cndpre in ('S','P') then
     -- fin 1012992
      for j in c_pp_ctrl ( i.inar_Cias ) loop
        --
        if ( j.ctrl_tipo_cierre = 'M' ) then
          --
          v_period := j.ctrl_vigci * 100 + j.ctrl_mesci;
          --
          if ( to_char(v_fecha,'YYYYMM') <= v_period ) then
            --
            p_Opcion := 'PPTO';
            p_Msg    := 'Periodo ' || to_char(v_fecha, 'YYYYMM' ) ||' YA CERRADO EN PRESUPUESTO';
            return;
            --
          end if;
          --
        else
          --
          if ( v_fecha <= j.ctrl_fecha_cierre ) then
            --
            p_Opcion := 'PPTO';
            p_Msg    := 'El Dia ' || v_fecha || ' YA CERRADO EN PRESUPUESTO';
            return;
            --
          end if;
          --
        end if;
        --
      end loop c_pp_ctrl;

   end if; -- 1012992
      --
      -- Siempre va a procesar una sola Empresa
      --
      for k in c_cias ( i.inar_Cias ) loop
        --
        -- Ini.Soli_5997B - 17 julio 2006
        --
        if ( substr(to_char(k.cias_periodo_actual), 5, 2) = '14' ) then
          v_Per_Actual := trunc(k.cias_periodo_actual/100) * 100 + 6.5;   -- 200514 se convierte en 200506.5, que sera posterior
        else                                                              -- a 200506, pero anterior a 200507
          v_Per_Actual := k.cias_periodo_actual;
        end if;
        --
        -- Fin.Soli_5997B
        --
        --
        --if ( to_char(v_fecha,'YYYYMM') < k.cias_periodo_actual ) then   -- Soli_6023 (Se reemplaza)
        --
        if ( to_char(v_fecha,'YYYYMM') < v_Per_Actual ) then              -- Soli_6023 (Se tiene en cuenta la variable V_PER_ACTUAL)
          --
          p_Opcion := 'CONTAB';
          p_Msg    := 'Periodo ' || to_char(v_fecha, 'YYYYMM') || ' YA CERRADO EN CONTABILIDAD';
          return;
          --
        end if;
        --
      end loop c_cias;
      --
    end loop c_inar;
    --
  end VERIFICA_CIERRES;
  --
  --
  procedure VALIDA_CPTO_SUCESOR ( p_Infa          varchar2,
                                  p_inrq          integer,
                                  p_Cias          integer,
                                  p_Periodo       integer,
                                  p_Numero        varchar2  ) is
    --
    v_Sucesor      ge_tinconceptos.inco_inco%type;
    v_Error        varchar2(20);
    --
    cursor c_Bases is
    select distinct inpa_inco_base
      from ge_tinpa
     where inpa_infa      =  p_Infa
       and inpa_inrq      =  p_inrq
       and inpa_inco_base is not null;
    --
    cursor c_Sucesor ( pc_Inco  varchar2 ) is
    select inco_inco_Sucesor
      from ge_tinconceptos
     where inco_infa         =  p_Infa
       and inco_inco         =  pc_Inco
       and inco_inco_Sucesor is not null;
    --
  begin
    --
    for i in c_Bases loop
      --
      open c_Sucesor( i.inpa_inco_Base );
      fetch c_Sucesor into v_Sucesor;
      if ( c_Sucesor%notfound ) then
        v_Error := '(ECpto_Suce)';        --  'ECptSc';
      end if;
      close c_Sucesor;
      --
      update ge_tinarch
         set inar_estado = inar_estado||v_Error
       where inar_infa   = p_Infa
         and inar_fecmov = p_Periodo
         and inar_numero = p_numero
         and inar_cias   = p_Cias
         and inar_campo1 = i.inpa_inco_base;
      --
      commit;
      --
    end loop c_Bases;
    --
  end VALIDA_CPTO_SUCESOR;
  --
  --
  ----------------------------------------------------------------------------------------------------
  procedure Verifica_Errados ( p_Infa          varchar2,
                               p_Periodo       integer,
                               p_Numero        varchar2,
                               p_Consulta  out varchar2,
                               p_Msg       out varchar2  ) is
    --
    v_Cuantos   integer := 0;
    --
  begin
    --
    -- Verifica si Existen Registros con estado diferente a B-BIEN
    --
    select count(*)
      into v_Cuantos
      from ge_tinarch
     where inar_infa = p_Infa
       and inar_fecmov = p_Periodo
       and inar_numero = p_numero
       and NVL(inar_estado,'*') <>  'B'
       and inar_estado <>  'P';
    --
    if ( v_Cuantos > 0 ) then
      --
      p_Consulta := 'ERROR';
      p_Msg := 'Errados Encontrados ' || v_Cuantos;
      --
      return;
      --
    end if;
    --
    p_Consulta := 'OK';
    --
    -- Deben Existir Registros con Estado igual a B-BIEN para poder Continuar con el Procesamiento
    --
    select count(*)
      into v_Cuantos
      from ge_tinarch
     where inar_infa   = p_Infa
       and inar_fecmov = p_Periodo
       and inar_numero = p_numero
       and inar_estado = 'B';
    --
    if ( v_Cuantos = 0 ) then
      p_Msg      := 'No Existen datos para procesar .. favor verificar ';
      p_Consulta := 'NO_DATOS';
    end if;
    --
  end Verifica_Errados;
  ----------------------------------------------------------------------------------------------------
  --
  --
  function Car_a_Fecha ( p_Fecha  varchar2 ) return date is
    --
    v_Fecha date;
    --
  begin
    --
    v_Fecha := to_date( p_Fecha, 'dd-mm-yyyy');
    --
    return( v_Fecha );
    --
    exception
      when others then
        raise_application_error( -20601, 'Error Convirtiendo a Fecha con formato DD-MM-YYYY: ' || p_Fecha );
    --
  end Car_a_Fecha;
  --
  --
  ----------------------------------------------------------------------------------------------------
  procedure CONFIRMA_INFA ( p_Infa           varchar2,
                            p_Periodo        integer,
                            p_Numero         varchar2,
                            p_Usuario        varchar2    ) is
    --
    -- Observaciones:
    --
    -- 1. EJ2H  19-DEC-2005 -- Soli 2005
    --    . Lee las compa?ia que relaciona el cargue, para luego hacer el llamado al metodo original
    --      CONFIRMA_INFA con el parametro de la compa?ia

    cursor c_ge_tinarch is
    select distinct inar_cias
    from   ge_tinarch
    where  inar_numero = p_numero;
    --
    v_inrq ge_vinrq.inrq_inrq%type;   -- Soli 5584
    --
    cursor c_ge_vinrq ( pc_cias ge_vinrq.inrq_inrq%type) is
    select inrq_inrq
    from   ge_vinrq
    where  inrq_cias = pc_cias;
    --
  begin
    --
    for r in c_ge_tinarch loop
        --
        v_inrq := trae_inad_inrq( p_infa, p_numero); -- 13291
        --
        if v_inrq is null then -- 13291
          --         
          open  c_ge_vinrq (r.inar_cias);
          fetch c_ge_vinrq into v_inrq;
          if ( c_ge_vinrq%notfound ) then
               v_inrq := -1;
          end if;
          close c_ge_vinrq;
          --
        end if; -- 13291
        --
        if ( v_inrq > 0 ) then
          Confirma_INFA ( p_Infa, v_inrq, r.inar_cias, p_Periodo, p_Numero, p_Usuario);
        end if;
        --
    end loop c_ge_tinarch;
    --
  end Confirma_INFA;
  --
  --
  --
  procedure Confirma_INFA ( p_Infa           varchar2,
                            p_inrq           integer,
                            p_Cias           integer,
                            p_Periodo        integer,
                            p_Numero         varchar2,
                            p_Usuario        varchar2    ) is
    --
    -- Modificaciones:
    --
    -- 1. Almoto - 4 y 5 octubre 2002 ( ITC y APTO ).
    --    . Se modifico totalmente, ya que se elimino el uso del paquete FORMS_DDL, y se
    --      reemplazo por el uso del paquete DBMS_SQL.  Se hace llamado a nuevos procedimientos
    --      Ejecuta_Sentencia, Ins_Tmp_NroCom, Upd_Tmp_NroCom, Ins_Tmp_OrPa, Upd_Tmp_OrPa.
    --
    -- 2. Almoto - 24 enero 2003 ( ITC ) - Solicitud 1102
    --    . Solicitud de Teletulua.  Actualiza Movimientos de Flujo de Caja y de Operaciones
    --      Efectivas de Caja.
    --
    -- 3. Almoto - 25 julio 2003 - Solicitud 1722
    --    . Se hicieron los ajustes necesarios para permitir actualizar el movimiento de
    --      tesoreria, en lo concerniente al numero del pago parcial.  Se crearon nuevas variables,
    --      y llamado al nuevo procedimiento Upd_MVTE_PgPr.
    --
    -- 4. Almoto - 2 marzo 2004 - Solicitud 5046
    --    . Se agrego sentencia para cerrar Cursor.
    --
    -- 5. EJ2H - 22 DEC-2005- Solicitud 5584
    --    . Se incluye el parametro de requerimiento
    --

    v_Usua_Gene   varchar2(20);
    --
    v_FecMovG    integer;
    v_Vigencia   integer;
    v_NroCom     integer;
    --
    v_OrPa       integer;
    --
    v_Tmp_CTCO   varchar2(30);
    v_Tmp_ACRE   varchar2(30);
    v_Tmp_ORPA   varchar2(30);
    v_tmp_MVTE   varchar2(30);
    --
    v_Sen_Crea_CTCO  varchar2(400);
    v_Sen_Crea_ACRE  varchar2(400);
    v_Sen_Crea_ORPA  varchar2(400);
    v_Sen_Crea_MVTE  varchar2(400);
    --
    v_Sen_Ins_CTCO   varchar2(400);
    v_Sen_Ins_ACRE   varchar2(400);
    v_Sen_Ins_ORPA   varchar2(400);
    v_Sen_Ins_MVTE   varchar2(400);
    --
    v_Sen_Upd_CTCO       varchar2(400);
    v_Sen_Upd_ACRE       varchar2(100);
    v_Sen_Upd_ORPA       varchar2(100);
    v_Sen_Upd_MVTE       varchar2(100);
    v_Sen_Upd_MVTE_PgPr  varchar2(500);
    --
    v_Cur_Ins_Tmp_CTCO  integer;
    v_Cur_Ins_Tmp_ACRE  integer;
    v_Cur_Ins_Tmp_ORPA  integer;
    v_Cur_Ins_Tmp_MVTE  integer;
    --
    v_Cur_Upd_Tmp_CTCO  integer;
    v_Cur_Upd_Tmp_ACRE  integer;
    v_Cur_Upd_Tmp_ORPA  integer;
    v_Cur_Upd_Tmp_MVTE  integer;
    v_Cur_Upd_MVTE      integer;
    --
    v_Nada       integer;
    --
    v_Hizo_Algo  boolean;
    --
    cursor c_ctco is
  	select ctco_TpCo, ctco_NroCom, ctco_FecMov, incd_tpco_Def tpco_Esp_Def, tpco_Clase tpco_Gen_Def
  	from   sc_tctco, ge_tincd, ge_ttpco
  	where  tpco_tpco        = incd_TpCo_def
  	and    incd_Infa        = p_Infa
  	and    incd_inrq        = p_inrq
  	and    incd_TpCo_Tmp    = ctco_TpCoG
  	and    ctco_inar_numero = p_numero
  	and    ctco_cias        = p_cias
    order by ctco_NroCom desc;
    --
    -- Soli 5584 cursor c_ctco is
    -- Soli 5584 select ctco_TpCo, ctco_NroCom, ctco_FecMov, intc_tpco_Def tpco_Esp_Def, tpco_Clase tpco_Gen_Def
    -- Soli 5584   from sc_tctco, ge_tintc_def, ge_ttpco
    -- Soli 5584  where ctco_Cias      =  p_Cias
    -- Soli 5584    and ctco_FecMov    =  p_Periodo
    -- Soli 5584    and ctco_User      =  v_Usua_Gene
    -- Soli 5584    and intc_Infa      =  p_Infa
    -- Soli 5584    and intc_Cias      =  p_Cias
    -- Soli 5584    and intc_TpCo_Tmp  =  ctco_TpCoG
    -- Soli 5584    and tpco_TpCo      =  intc_TpCo_Def
    -- Soli 5584  order by ctco_NroCom desc;
    --
    --
		cursor c_mvco ( pc_TpCo integer,  pc_NroCom integer, pc_Period integer ) is
		select sum(mvco_MtoRen) Valor
		from   sc_tmvco
		where  mvco_cias   = p_Cias
		and    mvco_tpco   = pc_TpCo
		and    mvco_nrocom = pc_NroCom
		and    mvco_fecmov = pc_Period;
    --
    --
    --		cursor c_orpa is
    --		select orpa_OrPa, orpa_VigOrPa
    --		from   cp_torpa
    --		where  orpa_Cias    =  p_Cias
    --		and    orpa_VigOrPa =  v_Vigencia
    --		and    orpa_OrPa    >  90000000
    --		and    orpa_User    =  v_Usua_Gene
    --		order by orpa_OrPa desc;
    --
		cursor c_orpa is
		select orpa_OrPa, orpa_VigOrPa
		from   cp_torpa
		where  orpa_OrPa    >  90000000
		and    orpa_inar_numero = p_numero
		order by orpa_OrPa desc;
    --
    --ini.COMO034 ymoreno
    cursor c_reserva is
    select orpa_OrPa, orpa_VigOrPa, orpa_valneto, orpa_fpag, orpa_auxi
		from   cp_torpa
		where  orpa_inar_numero = to_number(p_numero)
		order by orpa_OrPa desc;    
    --fin.COMO034 ymoreno
    --
    v_Valor       number;
    v_Hay_Error   boolean := false;
    --
  begin
    --
    --
    --Soli 5584 v_Usua_Gene := 'AUTO_' || p_Infa || p_Numero;
    v_Usua_Gene := p_usuario;    -- Soli 5584
    --
    v_Hizo_Algo := false;
    --
    -- Validando Comprobantes Contables
    --
    for i in c_ctco loop
	      --
	      open c_mvco( i.ctco_TpCo, i.ctco_NroCom, i.ctco_FecMov );
	      fetch c_mvco into v_Valor;
	      close c_mvco;
	      --
	      if ( v_Valor is null ) then
						 --
						 raise_application_error(-20692, 'Comprobante Sin Detalle. Cias='||p_Cias || ' TpCo='||i.ctco_TpCo || ' NroCom='||i.ctco_NroCom || ' Per='||i.ctco_FecMov);
						 --
						 --Ins_Observacion('Comprobante Sin Detalle. Cias='||p_Cias || ' TpCo='||i.ctco_TpCo || ' NroCom='||i.ctco_NroCom || ' Per='||i.ctco_FecMov);
						 --
	      elsif ( v_Valor <> 0 ) then
	           --
	           raise_application_error(-20693, 'Comprobante Descuadrado. Cias='||p_Cias || ' TpCo='||i.ctco_TpCo || ' NroCom='||i.ctco_NroCom || ' Per='||i.ctco_FecMov);
	           --
	           --Ins_Observacion('Comprobante Descuadrado. Cias='||p_Cias || ' TpCo='||i.ctco_TpCo || ' NroCom='||i.ctco_NroCom || ' Per='||i.ctco_FecMov);
	           --
	      end if;
	      --
    end loop c_ctco;
    --
    -- Inicializa Variables.
    --
    v_Vigencia  := trunc( p_Periodo / 100 );
    --
    v_Tmp_CTCO  := 'sc_tctco_fase_' || p_usuario;
    v_Tmp_ACRE  := 'ge_tacre_fase_' || p_usuario;
    v_Tmp_ORPA  := 'cp_torpa_fase_' || p_usuario;
    v_Tmp_MVTE  := 'te_tmvte_fase_' || p_usuario;
    --
    v_Sen_Crea_CTCO := 'create table ' || v_Tmp_CTCO || ' as select * from sc_tctco where rownum < 1';
    v_Sen_Crea_ACRE := 'create table ' || v_Tmp_ACRE || ' as select * from ge_tacre where rownum < 1';
    v_Sen_Crea_ORPA := 'create table ' || v_Tmp_ORPA || ' as select * from cp_torpa where rownum < 1';
    v_Sen_Crea_MVTE := 'create table ' || v_Tmp_MVTE || ' as select * from te_tmvte where rownum < 1';
    --
    v_Sen_Ins_CTCO  :=
      'insert into ' || v_Tmp_CTCO || '
       select * from sc_tctco
         where ctco_Cias   = :Cias
           and ctco_TpCo   = :TpCo
           and ctco_NroCom = :NroCom
           and ctco_FecMov = :FecMov';
    --
    v_Sen_Ins_ACRE  :=
      'insert into ' || v_Tmp_ACRE || '
       select * from ge_tacre
        where acre_Cias   = :Cias
          and acre_TpCo   = :TpCo
          and acre_NroCom = :NroCom
          and acre_FecMov = :FecMov';
    --
    v_Sen_Ins_ORPA  :=
      'insert into ' || v_Tmp_ORPA || '
       select * from cp_torpa
        where orpa_Cias    = :Cias
          and orpa_VigOrPa = :VigOrPa
          and orpa_OrPa    = :OrPa';
    --
    v_Sen_Ins_MVTE  :=                   -- Soli_1722
      'insert into ' || v_Tmp_MVTE || '
       select * from te_tmvte
         where mvte_Cias    = :Cias
           and mvte_VigOrPa = :VigOrPa
           and mvte_OrPa    = :OrPa';
    --
    v_Sen_Upd_CTCO  :=
      'update '||v_Tmp_CTCO||'
          set ctco_NroCom      = :NroCom,
              ctco_TpCo        = :TpCo_Gen,
              ctco_TpCoG       = :TpCo_Esp,
              ctco_inar_numero = '||p_numero;
    --
    v_Sen_Upd_ACRE :=
      'update '||v_Tmp_ACRE||
      '   set acre_NroCom = :NroCom,
              acre_TpCo   = :TpCo_Gen';
    --
    v_Sen_Upd_ORPA :=
      'update '||v_Tmp_ORPA||
      '   set orpa_OrPa = :OrPa, '||
      '       orpa_inar_numero = '||p_numero;
    --
    v_Sen_Upd_MVTE  :=
      'update '||v_Tmp_MVTE||
      '   set mvte_OrPa = :OrPa, '||
      '       mvte_inar_numero = '||p_numero;
    --
    v_Sen_Upd_MVTE_PgPr :=
      'declare
         cursor c_mvte is
         select mvte_Rengln, mvte_Pgpr
         from  '||v_tmp_MVTE||';'||'
       begin
         for i in c_mvte loop
           update te_tmvte
              set mvte_PgPr    = i.mvte_PgPr
           where mvte_Cias     = :Cias
              and mvte_VigOrPa = :VigOrPa
              and mvte_OrPa    = :OrPa
              and mvte_Rengln  = i.mvte_Rengln;
         end loop c_mvte;
       end;';
    --
    v_Sen_Ins_CTCO := Limpia_Sentencia( v_Sen_Ins_CTCO );
    v_Sen_Ins_ACRE := Limpia_Sentencia( v_Sen_Ins_ACRE );
    v_Sen_Ins_ORPA := Limpia_Sentencia( v_Sen_Ins_ORPA );
    v_Sen_Ins_MVTE := Limpia_Sentencia( v_Sen_Ins_MVTE );
    --
    v_Sen_Upd_CTCO      := Limpia_Sentencia( v_Sen_Upd_CTCO );
    v_Sen_Upd_ACRE      := Limpia_Sentencia( v_Sen_Upd_ACRE );
    v_Sen_Upd_ORPA      := Limpia_Sentencia( v_Sen_Upd_ORPA );
    v_Sen_Upd_MVTE      := Limpia_Sentencia( v_Sen_Upd_MVTE );
    v_Sen_Upd_MVTE_PgPr := Limpia_Sentencia( v_Sen_Upd_MVTE_PgPr );
    --
    --
    -- Elimina Tablas Temporales creadas en proceso anterior
    --
    Ejecuta_Sentencia ( 'drop table ' || v_Tmp_CTCO );
    Ejecuta_Sentencia ( 'drop table ' || v_Tmp_ACRE );
    Ejecuta_Sentencia ( 'drop table ' || v_Tmp_ORPA );
    Ejecuta_Sentencia ( 'drop table ' || v_Tmp_MVTE );
    --
    -- Creando Nuevas Tablas Temporales
    --
    Ejecuta_Sentencia ( v_Sen_Crea_CTCO );
    Ejecuta_Sentencia ( v_Sen_Crea_ACRE );
    Ejecuta_Sentencia ( v_Sen_Crea_ORPA );
    Ejecuta_Sentencia ( v_Sen_Crea_MVTE );
    --
    dbms_output.put_line(v_Sen_Crea_CTCO);
    dbms_output.put_line(v_Sen_Crea_ACRE);
    dbms_output.put_line(v_Sen_Crea_ORPA);
    dbms_output.put_line(v_Sen_Crea_MVTE);
    --
    -- Abre Cursores Necesarios
    --
    v_Cur_Ins_Tmp_CTCO := dbms_sql.open_cursor;
    v_Cur_Ins_Tmp_ACRE := dbms_sql.open_cursor;
    v_Cur_Ins_Tmp_ORPA := dbms_sql.open_cursor;
    v_Cur_Ins_Tmp_MVTE := dbms_sql.open_cursor;
    --
    v_Cur_Upd_Tmp_CTCO := dbms_sql.open_cursor;
    v_Cur_Upd_Tmp_ACRE := dbms_sql.open_cursor;
    v_Cur_Upd_Tmp_ORPA := dbms_sql.open_cursor;
    v_Cur_Upd_Tmp_MVTE := dbms_sql.open_cursor;
    v_Cur_Upd_MVTE     := dbms_sql.open_cursor;
    --
    --
    -- Realiza un recorrido por el Bloque de Contabilidad.
    --
    --
    for i in c_ctco loop
      --
      dbms_output.put_line('TpCo='||i.ctco_TpCo || ' NroCom='||i.ctco_NroCom || ' TpCo_Gen_Def='||i.tpco_Gen_Def || ' TpCo_Esp_Def='||i.tpco_Esp_Def);
      --
      if ( i.tpco_Gen_Def is null ) then
        --
        raise_application_error( -20672, 'TpCo "especifico" no esta asociado a un Generico: '||i.tpco_Esp_Def);
        --
      end if;
      --
      --
      --  Inserta en Temporal Encabezado del Comprobante.
      --
      Ins_Tmp_NROCOM ( v_Cur_Ins_Tmp_CTCO, v_Sen_Ins_CTCO, p_Cias, i.ctco_TpCo, i.ctco_NroCom, i.ctco_FecMov );
      --
      --
      --  Inserta en Temporal Acumulados y Retenciones.
      --
      Ins_Tmp_NROCOM ( v_Cur_Ins_Tmp_ACRE, v_Sen_Ins_ACRE, p_Cias, i.ctco_TpCo, i.ctco_NroCom, i.ctco_FecMov );
      --
      --  Genera Nuevo Numero de Comprobante
      --
      dbms_output.put_line('Confirma_INFA.1. Cias='||p_Cias || ' TpCoDef='||i.tpco_Gen_Def || ' Per='||p_Periodo || ' NroCom='||v_NroCom || ' FecMovG='||v_FecMovG);
      --
      Numerar_Comp ( p_Cias, i.tpco_Gen_Def, p_Periodo, v_NroCom, v_FecMovG);
      --
      dbms_output.put_line('Confirma_INFA.2. Cias='||p_Cias || ' TpCoDef='||i.tpco_Gen_Def || ' Per='||p_Periodo || ' NroCom='||v_NroCom || ' FecMovG='||v_FecMovG);
      --
      --  Actualiza Temporal Encabezado del Comprobante
      --
      dbms_output.put_line('Confirma_INFA.3. Sen_Upd_CTCO='||v_Sen_Upd_CTCO || ' TpCoDef='||i.tpco_Gen_Def || ' EspDef='||i.tpco_Esp_Def );
      --
      Upd_Tmp_NROCOM ( v_Cur_Upd_Tmp_CTCO, v_Sen_Upd_CTCO, v_NroCom, i.tpco_Gen_Def, i.tpco_Esp_Def );
      --
      dbms_output.put_line('Confirma_INFA.4. sqlerrm='||sqlerrm );
      --
      --  Actualiza Temporal Acumulados de Retencion (Tributarios).
      --
      Upd_Tmp_NROCOM ( v_Cur_Upd_Tmp_ACRE, v_Sen_Upd_ACRE, v_NroCom, i.tpco_Gen_Def );
      --
      --  Inserta Nuevo Encabezado del Comprobante
      --
      Ejecuta_Sentencia( 'insert into sc_tctco select * from ' || v_Tmp_CTCO );
      --
      --  Borra de GE_TACRE Registros anteriores.
      --
      begin
        --
        delete from ge_tacre
         where acre_Cias   = p_Cias
           and acre_TpCo   = i.ctco_TpCo
           and acre_NroCom = i.ctco_NroCom
           and acre_FecMov = i.ctco_FecMov;
        --
        exception
          when others then
            raise_application_error( -20673, 'Borrando de GE_TACRE: ' || sqlerrm );
      end;
      --
      --  Actualiza Detalle del Comprobante
      --
      begin
        --
        update sc_tmvco
           set mvco_NroCom = v_NroCom,
               mvco_TpCo   = i.tpco_Gen_Def
         where mvco_Cias   = p_Cias
           and mvco_TpCo   = i.ctco_TpCo
           and mvco_NroCom = i.ctco_NroCom
           and mvco_FecMov = i.ctco_FecMov;
        --
        exception
          when others then
            raise_application_error( -20674, 'Actualizando SC_TMVCO: ' || sqlerrm );
      end;
      --
      --  Actualiza Mov. Tesoreria - TE_TMVTE.
      --
      begin
        --
        update te_tmvte
           set mvte_NroCom = v_NroCom,
               mvte_TpCo   = i.tpco_Gen_Def
         where mvte_Cias   = p_Cias
           and mvte_TpCo   = i.ctco_TpCo
           and mvte_NroCom = i.ctco_NroCom
           and mvte_FecMov = i.ctco_FecMov;
        --
        exception
          when others then
            raise_application_error( -20675, 'Actualizando TE_TMVTE: ' || sqlerrm );
      end;
      --
      --  Actualiza Mov. de Flujos de Caja - TE_TMVFL                  ------ Soli_1102
      --
      begin
        --
        update te_tmvfl
           set mvfl_NroCom = v_NroCom,
               mvfl_TpCo   = i.tpco_Gen_Def
         where mvfl_Cias   = p_Cias
           and mvfl_TpCo   = i.ctco_TpCo
           and mvfl_NroCom = i.ctco_NroCom
           and mvfl_FecMov = i.ctco_FecMov;
        --
        exception
          when others then
            raise_application_error( -20676, 'Actualizando TE_TMVFL: ' || sqlerrm );
      end;
      --
      --  Actualiza Mov. de Operaciones Efectivas de Caja - TE_TMVOE   ------ Soli_1102
      --
      begin
        --
        update te_tmvoe
           set mvoe_NroCom = v_NroCom,
               mvoe_TpCo   = i.tpco_Gen_Def
         where mvoe_Cias   = p_Cias
           and mvoe_TpCo   = i.ctco_TpCo
           and mvoe_NroCom = i.ctco_NroCom
           and mvoe_FecMov = i.ctco_FecMov;
        --
        exception
          when others then
            raise_application_error( -20677, 'Actualizando TE_TMVOE: ' || sqlerrm );
      end;
      --
      --  Inserta en GE_TACRE registros actualizados.
      --
      Ejecuta_Sentencia ( 'insert into ge_tacre select * from ' || v_Tmp_ACRE );
      --
      --  Actualiza Nro. de Comprobante en Orden de Pago - CP_TORPA.
      --
      begin
        --
        update cp_torpa
           set orpa_TpCo   = i.tpco_Gen_Def,
               orpa_NroCom = v_NroCom
         where orpa_Cias   = p_Cias
           and orpa_TpCo   = i.ctco_TpCo
           and orpa_NroCom = i.ctco_NroCom
           and orpa_FecMov = p_Periodo;
        --
        exception
          when others then
            raise_application_error( -20678, 'Actualizando CP_TORPA: ' || sqlerrm );
      end;
      --
      --  Borra de Temporal Encabezado Contable.
      --
      Ejecuta_Sentencia ( 'delete from ' || v_Tmp_CTCO );
      --
      --
      --  Borra de Temporal Acumulados de Retencion.
      --
      Ejecuta_Sentencia ( 'delete from ' || v_Tmp_ACRE );
      --
      --  Borra Encabezado Anterior del Comprobante.
      --
      begin
        --
        delete from sc_tctco
         where ctco_Cias   = p_Cias
           and ctco_TpCo   = i.ctco_TpCo
           and ctco_NroCom = i.ctco_NroCom
           and ctco_FecMov = i.ctco_FecMov;
        --
        exception
          when others then
            raise_application_error( -20679, 'Borrando de SC_TCTCO: ' || sqlerrm );
      end;
      --
      --**dbms_output.put_line('CONFIRMA_INFA.10. No esta confirmando. OJO OJO.  HABILITAR  ** COMMIT **.');
      --
      --**
      COMMIT;
      --
      v_Hizo_Algo := true;
      --
    end loop c_ctco;
    --
    --
    --
    --  Realiza un recorrido por el Bloque de Ordenes de Pago.
    --
    for i in c_orpa loop
        --
        --  Inserta en Temporal Ordenes de Pago.
        --
        Ins_Tmp_ORPA ( v_Cur_Ins_Tmp_ORPA, v_Sen_Ins_ORPA, p_Cias, i.orpa_VigOrPa, i.orpa_OrPa );
        --
        --  Inserta en Temporal Movimiento de Tesoreria.
        --
        Ins_Tmp_ORPA ( v_Cur_Ins_Tmp_MVTE, v_Sen_Ins_MVTE, p_Cias, i.orpa_VigOrPa, i.orpa_OrPa );   -- Soli_1722
        --
        --  Genera Nuevo Numero de Orden de Pago
        --
        Numerar_OrPa ( p_Cias, i.orpa_VigOrPa, p_Periodo, v_OrPa );
        --
        --  Actualiza Temporal Ordenes de Pago.
        --
        Upd_Tmp_ORPA ( v_Cur_Upd_Tmp_ORPA, v_Sen_Upd_ORPA, v_OrPa );
        --
        --  Actualiza Temporal Movimiento de Tesoreria.
        --
        Upd_Tmp_ORPA ( v_Cur_Upd_Tmp_MVTE, v_Sen_Upd_MVTE, v_OrPa );
        --
        --  Actualiza Movimiento Original de Tesoreria, suprimiendo Pago Parcial
        --
        begin             -- Soli_1722
           --
           update te_tmvte
              set mvte_Pgpr  = null
            where mvte_Cias    = p_Cias
              and mvte_VigOrPa = i.orpa_VigOrPa
              and mvte_OrPa    = i.orpa_OrPa;
          --
          exception
            when others then
              raise_application_error( -20680, 'Actualizando TE_TMVTE: ' || sqlerrm );
           --
         end;
        --
        --  Inserta Nuevo Encabezado Orden de Pago..
        --
        Ejecuta_Sentencia( 'insert into cp_torpa select * from ' || v_Tmp_ORPA );
        --
        --  Actualiza Liquidacion Orden de Pago - CP_TORPV.
        --
        begin
          --
          update cp_torpv
             set orpv_OrPa  =  v_OrPa
           where orpv_Cias    = p_Cias
             and orpv_VigOrPa = i.orpa_VigOrPa
             and orpv_OrPa    = i.orpa_OrPa;
          --
          exception
            when others then
              raise_application_error( -20681, 'Actualizando CP_TORPV: ' || sqlerrm );
        end;
        --
        --
        --  Actualiza Acumulados de Retencion. GE_TACRE                                                    --(1)
        --
        begin
          --
          update ge_tacre
             set acre_orpa   =  v_OrPa
           where acre_Cias    = p_Cias
             and acre_VigOrPa = i.orpa_VigOrPa
             and acre_OrPa    = i.orpa_OrPa;
          --
          exception
            when others then
              raise_application_error( -20682, 'Actualizando GE_TACRE: ' || sqlerrm );
        end;
        --
        --
        --  Actualiza Tablas Interfases Orden de Pago - GE_TINTM
        --
        begin
          --
          -- Soli_6304
          -- Se reemplaza lo relacionado con la tabla GE_TINARCH por GE_TINTM
          --
          update ge_tintm
             set intm_OrPa = v_OrPa
           where intm_fecmov  = p_Periodo
             and intm_numero  = p_Numero
             and intm_cias    = p_Cias
             and intm_VigOrPa = i.orpa_VigOrPa
             and intm_OrPa    = i.orpa_OrPa;
          --
          exception
            when others then
              raise_application_error( -20683, 'Actualizando GE_TINTM: ' || sqlerrm );
        end;
        --
        --  Actualiza Movimiento de Presupuesto - PP_TMOVI.
        --
        begin
          --
          update pp_tmovi
             set movi_OrPa  = v_OrPa
           where movi_Cias    = p_Cias
             and movi_VigOrPa = i.orpa_VigOrPa
             and movi_OrPa    = i.orpa_OrPa;
          --
          exception
            when others then
              raise_application_error( -20684, 'Actualizando PP_TMOVI: ' || sqlerrm );
        end;
        --
        --  Actualiza Pagos Parciales - CP_TPGPR.
        --
        begin
          --
          update cp_tpgpr
             set pgpr_OrPa = v_OrPa
           where pgpr_Cias    = p_Cias
             and pgpr_VigOrPa = i.orpa_VigOrPa
             and pgpr_OrPa    = i.orpa_OrPa;
          --
          exception
            when others then
              raise_application_error( -20685, 'Actualizando CP_TPGPR: ' || sqlerrm );
        end;
        --
        --  Actualiza Mov. Tesoreria - TE_TMVTE.
        --
        begin
          --
          update te_tmvte
             set mvte_OrPa = v_OrPa
           where mvte_Cias    = p_Cias
             and mvte_VigOrPa = i.orpa_VigOrPa
             and mvte_OrPa    = i.orpa_OrPa;
          --
          exception
            when others then
              raise_application_error( -20686, 'Actualizando TE_TMVTE: ' || sqlerrm );
        end;
        --
        -- Actualiza Pagos Parciales en el Movimiento de Tesoreria
        --
        Upd_MVTE_PgPr( v_Cur_Upd_MVTE, v_Sen_Upd_MVTE_PgPr, p_Cias, i.orpa_VigOrPa, v_OrPa );
        --
        --  Borra de Temporal Ordenes de Pago.
        --
        Ejecuta_Sentencia( 'delete from ' || v_Tmp_ORPA );
        --
        --  Borra de Temporal de Tesoreria.
        --
        Ejecuta_Sentencia ( 'delete from ' || v_Tmp_MVTE );
        --
        --  Borra Encabezado Anterior Orden de Pago.
        --
        begin
          --
          delete from cp_torpa
           where orpa_Cias    = p_Cias
             and orpa_VigOrPa = i.orpa_VigOrPa
             and orpa_OrPa    = i.orpa_Orpa;
          --
          exception
            when others then
              raise_application_error( -20694, 'Borrando de CP_TORPA: ' || sqlerrm );
        end;
        --
        --**dbms_output.put_line('CONFIRMA_INFA.20. No esta confirmando. OJO OJO.  HABILITAR  ** COMMIT **.');
        --
        --**
        COMMIT;
        --
        --
        v_Hizo_Algo := true;
        --
    end loop c_orpa;
    --
    --ini.COMO034 ymoreno
    --Crea reservas de las ordenes de pago
    for j in c_reserva
    loop
      Crea_Reserva  (p_Cias , j.orpa_VigOrPa , j.orpa_OrPa , j.orpa_valneto ,	j.orpa_fpag	, j.orpa_auxi, p_usuario );
    end loop;
    --fin.COMO034 ymoreno
    --
    if ( v_Hizo_Algo ) then
      --
      Update ge_tinad                        -- Soli_6304 (Se cambia GE_TINADMIN)
         set inad_ult_accion = 'CF',
             inad_ult_fecha  = sysdate
       where inad_infa   = p_Infa
         and inad_numero = p_Numero;
      --
      --
      --**dbms_output.put_line('CONFIRMA_INFA.30. No esta confirmando. OJO OJO.  HABILITAR  ** COMMIT **.');
      --
      --**
      COMMIT;
      --
    end if;
    --
    --**
    /*
    NOTA('OBSERVACIONES');
    FOR I IN C_TEMP LOOP
      NOTA('RENG='||I.MVTE_RENGLN || ' PGPR='||I.MVTE_PGPR);
    END LOOP C_TEMP;
    */
    -- Cierra Cursores
    --
    dbms_sql.Close_Cursor( v_Cur_Ins_Tmp_CTCO );
    dbms_sql.Close_Cursor( v_Cur_Ins_Tmp_ACRE );
    dbms_sql.Close_Cursor( v_Cur_Ins_Tmp_ORPA );
    dbms_sql.Close_Cursor( v_Cur_Ins_Tmp_MVTE );  -- Soli_5046 - 2 marzo 2004
    --
    dbms_sql.Close_Cursor( v_Cur_Upd_Tmp_CTCO );
    dbms_sql.Close_Cursor( v_Cur_Upd_Tmp_ACRE );
    dbms_sql.Close_Cursor( v_Cur_Upd_Tmp_ORPA );
    dbms_sql.Close_Cursor( v_Cur_Upd_Tmp_MVTE );
    dbms_sql.Close_Cursor( v_Cur_Upd_MVTE );
    --
  end Confirma_INFA;
  ----------------------------------------------------------------------------------------------------
  --
  --
  FUNCTION Limpia_Sentencia ( p_Sentencia varchar2 ) return varchar2 IS
    --
    v_Sentencia varchar2(500) := p_Sentencia;
    --
  BEGIN
    --
    --
    while instr(v_Sentencia, chr(10)) > 0 loop
      --
      v_Sentencia := replace(v_Sentencia, chr(10), ' ');
      --
    end loop;
   --
   --
    while instr(v_Sentencia, '  ') > 0 loop
      --
      v_Sentencia := replace(v_Sentencia, '  ', ' ');
      --
    end loop;
    --
    --
    return( upper(v_Sentencia) );
    --
  END Limpia_Sentencia;
  --
  --
  --
  PROCEDURE Ins_Tmp_NROCOM ( p_Cursor     integer,
                             p_Sentencia  varchar2,
                             p_Cias       integer,
                             p_TpCo       integer,
                             p_NroCom     integer,
                             p_FecMov     integer  ) IS
    --
    v_Nada  integer;
    --
  BEGIN
    --
    dbms_sql.parse( p_Cursor, p_Sentencia, DBMS_SQL.native );
    --
    dbms_sql.bind_variable( p_Cursor, 'CIAS', p_Cias );
    dbms_sql.bind_variable( p_Cursor, 'TPCO', p_TpCo );
    dbms_sql.bind_variable( p_Cursor, 'NROCOM', p_NroCom );
    dbms_sql.bind_variable( p_Cursor, 'FECMOV', p_FecMov );
    --
    v_Nada  := dbms_sql.execute( p_Cursor );
    --
  exception
   when others then
     dbms_output.put_line('Error 20687: Cursor='||p_Cursor || ' : ' || p_Sentencia );
     raise_application_error(-20687, sqlerrm);
     --raise_application_error(-20687, 'Error ejecutando sentencia : ' || p_Sentencia);
  END Ins_Tmp_NROCOM;
  --
  --
  --
  PROCEDURE Ins_Tmp_ORPA   ( p_Cursor     integer,
                             p_Sentencia  varchar2,
                             p_Cias       integer,
                             p_VigOrPa    integer,
                             p_OrPa       integer   ) IS
    --
    v_Nada  integer;
    --
  BEGIN
   --
    dbms_sql.parse( p_Cursor, p_Sentencia, DBMS_SQL.native );
    --
    dbms_sql.bind_variable( p_Cursor, 'CIAS', p_Cias );
    dbms_sql.bind_variable( p_Cursor, 'VIGORPA', p_VigOrPa );
    dbms_sql.bind_variable( p_Cursor, 'ORPA', p_OrPa );
    --
    v_Nada  := dbms_sql.execute( p_Cursor );
    --
  exception
   when others then
     raise_application_error(-20688, 'Error ejecutando sentencia : ' || p_Sentencia);
  END Ins_Tmp_ORPA;
  --
  --
  --
  PROCEDURE Upd_MVTE_PgPr ( p_Cursor     integer,
                            p_Sentencia  varchar2,
                            p_Cias       integer,
                            p_VigOrPa    integer,
                            p_OrPa       integer  ) IS
    --
    -- Almoto - 23 julio 2003 - Solicitud 1722
    --
    v_Nada  integer;
    --
  BEGIN
   --
   --nOTA('UPD_MVTE_PGPR='||P_SENTENCIA);
   --
    dbms_sql.parse( p_Cursor, p_Sentencia, DBMS_SQL.native );
    --
    dbms_sql.bind_variable( p_Cursor, 'Cias', p_Cias );
    dbms_sql.bind_variable( p_Cursor, 'VigOrPa', p_VigOrPa );
    dbms_sql.bind_variable( p_Cursor, 'OrPa', p_OrPa );
    --
    v_Nada  := dbms_sql.execute( p_Cursor );
    --
  exception
   when others then
     raise_application_error(-20689, 'Error ejecutando sentencia : ' || p_Sentencia);
  END Upd_MVTE_PgPr;
  --
  --
  --
  PROCEDURE Upd_Tmp_NROCOM ( p_Cursor     integer,
                             p_Sentencia  varchar2,
                             p_NroCom     integer,
                             p_TpCo_Gen   integer,
                             p_TpCo_Esp   integer  default null ) IS
    --
    v_Nada  integer;
    --
  BEGIN
   --
    dbms_sql.parse( p_Cursor, p_Sentencia, DBMS_SQL.native );
    --
    dbms_sql.bind_variable( p_Cursor, 'NroCom', p_NroCom );
    dbms_sql.bind_variable( p_Cursor, 'tpco_Gen', p_TpCo_Gen );
    --
    if ( p_TpCo_Esp is not null ) then
      dbms_sql.bind_variable( p_Cursor, 'tpco_Esp', p_TpCo_Esp );
    end if;
    --
    v_Nada  := dbms_sql.execute( p_Cursor );
    --
  exception
   when others then
     raise_application_error(-20690, 'Error ejecutando sentencia : ' || p_Sentencia);
  END Upd_Tmp_NROCOM;
  --
  --
  --
  PROCEDURE Upd_Tmp_ORPA ( p_Cursor     integer,
                           p_Sentencia  varchar2,
                           p_OrPa       integer   ) IS
    --
    v_Nada  integer;
    --
  BEGIN
   --
    dbms_sql.parse( p_Cursor, p_Sentencia, DBMS_SQL.native );
    --
    dbms_sql.bind_variable( p_Cursor, 'OrPa', p_OrPa );
    --
    v_Nada  := dbms_sql.execute( p_Cursor );
    --
  exception
   when others then
     raise_application_error(-20691, 'Error ejecutando sentencia : ' || p_Sentencia);
  END Upd_Tmp_ORPA;
  --
  --
  --
  PROCEDURE Ejecuta_Sentencia ( p_Sentencia  varchar2 ) IS
    --
    -- Modificaciones:
    -- 1. Almoto - 2 marzo 2004 - Solicitud 5046
    --    . Se agrego sentencia para cerrar Cursor.
    --
    v_Cursor  integer;
    v_Nada    integer;
    --
  BEGIN
    --
    --
    v_Cursor := dbms_sql.open_cursor;
    --
    dbms_output.put_line('Ejecuta_Sentencia. Cursor='||v_Cursor || ' : ' || p_Sentencia);
    --
    dbms_sql.parse( v_Cursor, p_Sentencia, DBMS_SQL.native );
    --
    dbms_output.put_line('Ejecuta_Sentencia. '||p_Sentencia);
    --
    v_Nada  := dbms_sql.execute( v_Cursor );
    --
    dbms_output.put_line('Ejecuta_Sentencia. v_Nada='||v_Nada);
    --
    dbms_sql.close_cursor(v_Cursor);
    --
  exception
   when others then
     --
     dbms_sql.close_cursor(v_Cursor);
     --
     if ( substr(upper(p_Sentencia), 1, 4) <> 'DROP' ) then
       raise_application_error(-20695, 'Error Ejecuta_Sentencia:' || sqlerrm);
     end if;
     --
  END Ejecuta_Sentencia;
  --
  PROCEDURE VALIDA_FPAG ( p_Infa	in varchar2,
                          p_Cias	in integer,
                          p_Periodo	in integer,
                          p_Numero	in varchar2 ) is

   Begin
    --
    update ge_tinarch
    set    inar_estado = inar_estado||'(Fpago Oblig.)'
    where  inar_infa   = p_Infa
    and    inar_fecmov = p_Periodo
    and    inar_numero = p_Numero
    and    inar_cias   = p_Cias
    and    inar_fmpg is null;
    --
    update ge_tinarch
    set    inar_estado = inar_estado||'(Fpago No Existe)'
    where  inar_infa   = p_Infa
    and    inar_fecmov = p_Periodo
    and    inar_numero = p_Numero
    and    inar_cias   = p_Cias
    and    inar_fmpg is not null
    and    not exists ( select 'x'
                        from ge_tfpago
                        where fpag_fpag = inar_fmpg
                      );
    --
    update ge_tinarch
    set    inar_estado = inar_estado||'(Fpago No V�lido)'
    where  inar_infa   = p_Infa
    and    inar_fecmov = p_Periodo
    and    inar_numero = p_Numero
    and    inar_cias   = p_Cias
    and    inar_fmpg is not null
    and    exists ( select 'x'
                    from ge_tfpago
                    where fpag_fpag = inar_fmpg
                  --and   fpag_origina in ( 'TR', 'FX', 'NA' ) -- antes de 1012552
                  --and   fpag_origina in ( 'FX', 'NA' )       -- 1012552 -- antes de 16230
                    and   fpag_origina in ( 'FX' )             -- 1012552 -- 16230
                   );
    --
    commit;
    --

  END VALIDA_FPAG;
  ---------------------------------------------------------------------
  /* 109973
  * Valida que los Comprobantes Contables no se Encuentren Descuadrados
  *
  * @p_cias      Empresa que Genera el Comprobante
  * @p_TpCo      Tipo de comprobante
  * @p_NroCom    Numero de comprobante
  * @p_Periodo   Periodo contable AAAAMM
  * @p_proceso   Proceso que realiza la Contabilidad
  *
  */
  FUNCTION val_cuadre_comp ( p_cias      in  sc_tctco.ctco_cias%type,
                             p_TpCo      in  sc_tctco.ctco_tpco%type,
                             p_NroCom    in  sc_tctco.ctco_nrocom%type,
                             p_Periodo   in  sc_tctco.ctco_fecmov%type,
                             p_proceso   in  varchar2,
                             p_Infa      in  varchar2,
                             p_numero    in  varchar2,
                             p_usua_gene in  varchar2
                            ) return varchar2 Is
    v_suma      Number;
    v_conteo    Number;
    v_mensaje   Varchar2(300);

  Begin
    Select nvl(Sum(mvco_mtoren) ,0), nvl(count(mvco_rengln) ,0)
      Into v_suma, v_conteo
      From sc_tmvco
     Where mvco_cias = p_cias
       And mvco_tpco = p_TpCo
       And mvco_nrocom = p_NroCom
       And mvco_fecmov = p_Periodo;
    If  v_suma  <> 0 Then

    	ge_qinfa.deshace_infa( p_Infa, p_Periodo, p_Numero, p_Usua_Gene);

      v_mensaje := 'El Comprobante Contable Cenerado Ce encuentra Descuadrado en: '||to_char(v_suma,'999,999,999,999.99')||', proceso: '||p_proceso;
      return v_mensaje;

    End If;
    If  v_conteo = 0 Then
      v_mensaje := 'El comprobante se gener� sin detalles '||p_proceso;
      return v_mensaje;
    End If;

    v_mensaje := 'OK';
    return v_mensaje;

  End val_cuadre_comp;
  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  /* Inicia COMO058 */
  PROCEDURE Valida_Factura ( p_Infa	   in varchar2,
                             p_Cias	   in integer,
                             p_Periodo in integer,
                             p_Numero	 in varchar2 ) is
    --
    --
    v_QRegi        integer;
    v_inar_Campo1  varchar2(20);
    --
    cursor c_nrodoc  is
      select inar_pref, inar_nrodoc
        from ge_tinarch
       where inar_infa   = p_Infa
         and inar_fecmov = p_Periodo
         and inar_numero = p_numero
         and inar_cias   = p_Cias
       group by inar_pref, inar_nrodoc
       having count(*) > 1;
    --
  Begin
    --
    for i in c_nrodoc loop
      --
      update ge_tinarch
      set    inar_estado = inar_estado||'(NoDoc Existe.)'
      where  inar_infa   = p_Infa
      and    inar_fecmov = p_Periodo
      and    inar_numero <> p_Numero
      and    inar_cias   = p_Cias
      and    inar_pref = i.inar_pref
      and    inar_nrodoc = i.inar_nrodoc;
      --
    end loop c_nrodoc;
    --
    commit;
    --
  end Valida_Factura;
  --

  ---------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  PROCEDURE Valida_MonedaMy( p_Infa	   in varchar2,
                             p_inrq    in integer,
                             p_Cias	   in integer,
                             p_Periodo in integer,
                             p_Numero	 in varchar2 )is
    --
    cursor c_inpa is
    select distinct inpa_Campo1, inpa_Campo2, inpa_Campo3, inpa_Campo4, inpa_Campo5,
                    inpa_Campo6, inpa_Campo7, inpa_Campo8, inpa_Campo9, inpa_Campo10,
                    inpa_cont_mayo, Inpa_Etct
      from ge_tinpa, ge_tmayor
     where inpa_infa       = p_Infa
       and inpa_inrq       = p_inrq
       and inpa_cont_tpco is not null
       and mayo_etct       = inpa_etct
       and mayo_mayo       = inpa_cont_mayo
       and mayo_reexp_mon  = 'S';
    --
    cursor c_inar ( pc_Ca1 varchar2, pc_Ca2 varchar2, pc_Ca3 varchar2, pc_Ca4 varchar2, pc_Ca5  varchar2,
                    pc_Ca6 varchar2, pc_Ca7 varchar2, pc_Ca8 varchar2, pc_Ca9 varchar2, pc_Ca10 varchar2 ) is
    select distinct inar_nit_asociado
      from ge_tinarch
     where inar_infa              = p_Infa
       and inar_fecmov            = p_Periodo
       and inar_numero            = p_Numero
       and inar_cias              = p_Cias
       and INAR_CAMPO1            = pc_Ca1
       and nvl(INAR_CAMPO2,'*-*') = nvl(pc_Ca2, '*-*')
       and nvl(INAR_CAMPO3,'*-*') = nvl(pc_Ca3, '*-*')
       and nvl(INAR_CAMPO4,'*-*') = nvl(pc_Ca4, '*-*')
       and nvl(INAR_CAMPO5,'*-*') = nvl(pc_Ca5, '*-*')
       and nvl(INAR_CAMPO6,'*-*') = nvl(pc_Ca6, '*-*')
       and nvl(INAR_CAMPO7,'*-*') = nvl(pc_Ca7, '*-*')
       and nvl(INAR_CAMPO8,'*-*') = nvl(pc_Ca8, '*-*')
       and nvl(INAR_CAMPO9,'*-*') = nvl(pc_Ca9, '*-*')
       and nvl(INAR_CAMPO10,'*-*') = nvl(pc_Ca10, '*-*')
       and inar_vlrmone   is null;
      --
  Begin
    --
    for i in c_inpa loop
        --
        For j in  c_inar ( i.inpa_Campo1, i.inpa_Campo2, i.inpa_Campo3, i.inpa_Campo4, i.inpa_Campo5,
                   i.inpa_Campo6, i.inpa_Campo7, i.inpa_Campo8, i.inpa_Campo9, i.inpa_Campo10 ) loop
             --
             update ge_tinarch
             set inar_estado = inar_estado||'(Sin_Vr_Ext)'
             where inar_infa   = p_Infa
             and inar_fecmov = p_Periodo
             and inar_numero = p_numero
             and inar_cias   = p_Cias
             and inar_campo1 = i.inpa_Campo1
             and nvl(INAR_CAMPO2,'*-*') = nvl(i.inpa_Campo2,'*-*')
             and nvl(INAR_CAMPO3,'*-*') = nvl(i.inpa_Campo3,'*-*')
             and nvl(INAR_CAMPO4,'*-*') = nvl(i.inpa_Campo4,'*-*')
             and nvl(INAR_CAMPO5,'*-*') = nvl(i.inpa_Campo5,'*-*')
             and nvl(INAR_CAMPO6,'*-*') = nvl(i.inpa_Campo6,'*-*')
             and nvl(INAR_CAMPO7,'*-*') = nvl(i.inpa_Campo7,'*-*')
             and nvl(INAR_CAMPO8,'*-*') = nvl(i.inpa_Campo8,'*-*')
             and nvl(INAR_CAMPO9,'*-*') = nvl(i.inpa_Campo9,'*-*')
             and nvl(INAR_CAMPO10,'*-*') = nvl(i.inpa_Campo10,'*-*')
             and inar_nit_asociado = j.inar_nit_asociado;
             --
             commit;
             --
        end loop c_inar;
        --
    end loop c_inpa;
    --
  end Valida_MonedaMy;
  --
  --  inicio 1012484.  ovcaceres.  01/03/2012
  PROCEDURE Valida_Aica( p_Infa	   in varchar2,
                             p_inrq    in integer,
                             p_Cias	   in integer,
                             p_Periodo in integer,
                             p_Numero	 in varchar2 )is
    --
    cursor c_inpa is
    select distinct inpa_Campo1, inpa_Campo2, inpa_Campo3, inpa_Campo4, inpa_Campo5,
                    inpa_Campo6, inpa_Campo7, inpa_Campo8, inpa_Campo9, inpa_Campo10,
                    inpa_cont_mayo, Inpa_Etct
      from ge_tinpa, ge_tdere
     where inpa_infa       = p_Infa
       and inpa_inrq       = p_inrq
       and dere_clase      = 'IK'
       and dere_etct       = inpa_etct
       and dere_rete       = inpa_rete;
    --
    cursor c_inar1 ( pc_Ca1 varchar2, pc_Ca2 varchar2, pc_Ca3 varchar2, pc_Ca4 varchar2, pc_Ca5  varchar2,
                    pc_Ca6 varchar2, pc_Ca7 varchar2, pc_Ca8 varchar2, pc_Ca9 varchar2, pc_Ca10 varchar2 ) is
    select distinct inar_nit_asociado
      from ge_tinarch
     where inar_infa              = p_Infa
       and inar_fecmov            = p_Periodo
       and inar_numero            = p_Numero
       and inar_cias              = p_Cias
       and inar_campo1            = pc_Ca1
       and nvl(INAR_CAMPO2,'*-*') = nvl(pc_Ca2, '*-*')
       and nvl(INAR_CAMPO3,'*-*') = nvl(pc_Ca3, '*-*')
       and nvl(INAR_CAMPO4,'*-*') = nvl(pc_Ca4, '*-*')
       and nvl(INAR_CAMPO5,'*-*') = nvl(pc_Ca5, '*-*')
       and nvl(INAR_CAMPO6,'*-*') = nvl(pc_Ca6, '*-*')
       and nvl(INAR_CAMPO7,'*-*') = nvl(pc_Ca7, '*-*')
       and nvl(INAR_CAMPO8,'*-*') = nvl(pc_Ca8, '*-*')
       and nvl(INAR_CAMPO9,'*-*') = nvl(pc_Ca9, '*-*')
       and nvl(INAR_CAMPO10,'*-*') = nvl(pc_Ca10, '*-*')
       and inar_aica is null;
      --
    cursor c_inar2 ( pc_Ca1 varchar2, pc_Ca2 varchar2, pc_Ca3 varchar2, pc_Ca4 varchar2, pc_Ca5  varchar2,
                    pc_Ca6 varchar2, pc_Ca7 varchar2, pc_Ca8 varchar2, pc_Ca9 varchar2, pc_Ca10 varchar2 ) is
    select distinct inar_nit_asociado
      from ge_tinarch
     where inar_infa              = p_Infa
       and inar_fecmov            = p_Periodo
       and inar_numero            = p_Numero
       and inar_cias              = p_Cias
       and inar_campo1            = pc_Ca1
       and nvl(INAR_CAMPO2,'*-*') = nvl(pc_Ca2, '*-*')
       and nvl(INAR_CAMPO3,'*-*') = nvl(pc_Ca3, '*-*')
       and nvl(INAR_CAMPO4,'*-*') = nvl(pc_Ca4, '*-*')
       and nvl(INAR_CAMPO5,'*-*') = nvl(pc_Ca5, '*-*')
       and nvl(INAR_CAMPO6,'*-*') = nvl(pc_Ca6, '*-*')
       and nvl(INAR_CAMPO7,'*-*') = nvl(pc_Ca7, '*-*')
       and nvl(INAR_CAMPO8,'*-*') = nvl(pc_Ca8, '*-*')
       and nvl(INAR_CAMPO9,'*-*') = nvl(pc_Ca9, '*-*')
       and nvl(INAR_CAMPO10,'*-*') = nvl(pc_Ca10, '*-*')
       and inar_ciud is null;
      --
    cursor c_inar3 ( pc_Ca1 varchar2, pc_Ca2 varchar2, pc_Ca3 varchar2, pc_Ca4 varchar2, pc_Ca5  varchar2,
                    pc_Ca6 varchar2, pc_Ca7 varchar2, pc_Ca8 varchar2, pc_Ca9 varchar2, pc_Ca10 varchar2,
                    pc_Etct    integer) is
    select distinct inar_nit_asociado
      from ge_tinarch
     where inar_infa              = p_Infa
       and inar_fecmov            = p_Periodo
       and inar_numero            = p_Numero
       and inar_cias              = p_Cias
       and inar_campo1            = pc_Ca1
       and nvl(INAR_CAMPO2,'*-*') = nvl(pc_Ca2, '*-*')
       and nvl(INAR_CAMPO3,'*-*') = nvl(pc_Ca3, '*-*')
       and nvl(INAR_CAMPO4,'*-*') = nvl(pc_Ca4, '*-*')
       and nvl(INAR_CAMPO5,'*-*') = nvl(pc_Ca5, '*-*')
       and nvl(INAR_CAMPO6,'*-*') = nvl(pc_Ca6, '*-*')
       and nvl(INAR_CAMPO7,'*-*') = nvl(pc_Ca7, '*-*')
       and nvl(INAR_CAMPO8,'*-*') = nvl(pc_Ca8, '*-*')
       and nvl(INAR_CAMPO9,'*-*') = nvl(pc_Ca9, '*-*')
       and nvl(INAR_CAMPO10,'*-*') = nvl(pc_Ca10, '*-*')
       and inar_aica is not null
       and not exists ( select 'x'
                       from ge_taica
                       where inar_ciud = aica_ciud
                       and inar_aica = aica_aica
                       and pc_Etct = aica_etct
                     )
       ;
      --
  Begin
    --
    for i in c_inpa loop
        --
        For j in  c_inar1 ( i.inpa_Campo1, i.inpa_Campo2, i.inpa_Campo3, i.inpa_Campo4, i.inpa_Campo5,
                   i.inpa_Campo6, i.inpa_Campo7, i.inpa_Campo8, i.inpa_Campo9, i.inpa_Campo10 ) loop
             --
             update ge_tinarch
             set inar_estado = inar_estado||'(Sin_Aica)'
             where inar_infa   = p_Infa
             and inar_fecmov = p_Periodo
             and inar_numero = p_numero
             and inar_cias   = p_Cias
             and inar_campo1 = i.inpa_Campo1
             and nvl(INAR_CAMPO2,'*-*') = nvl(i.inpa_Campo2,'*-*')
             and nvl(INAR_CAMPO3,'*-*') = nvl(i.inpa_Campo3,'*-*')
             and nvl(INAR_CAMPO4,'*-*') = nvl(i.inpa_Campo4,'*-*')
             and nvl(INAR_CAMPO5,'*-*') = nvl(i.inpa_Campo5,'*-*')
             and nvl(INAR_CAMPO6,'*-*') = nvl(i.inpa_Campo6,'*-*')
             and nvl(INAR_CAMPO7,'*-*') = nvl(i.inpa_Campo7,'*-*')
             and nvl(INAR_CAMPO8,'*-*') = nvl(i.inpa_Campo8,'*-*')
             and nvl(INAR_CAMPO9,'*-*') = nvl(i.inpa_Campo9,'*-*')
             and nvl(INAR_CAMPO10,'*-*') = nvl(i.inpa_Campo10,'*-*')
             and inar_nit_asociado = j.inar_nit_asociado
             and inar_aica is null;         -- 1012484.  ovcaceres.  28/03/2012.  Se tiene en cuenta condici�n de ICA
             --
        end loop c_inar1;
        --
        For j in  c_inar2 ( i.inpa_Campo1, i.inpa_Campo2, i.inpa_Campo3, i.inpa_Campo4, i.inpa_Campo5,
                   i.inpa_Campo6, i.inpa_Campo7, i.inpa_Campo8, i.inpa_Campo9, i.inpa_Campo10 ) loop
            --
             update ge_tinarch
             set inar_estado = inar_estado||'(Sin_Ciud)'
             where inar_infa   = p_Infa
             and inar_fecmov = p_Periodo
             and inar_numero = p_numero
             and inar_cias   = p_Cias
             and inar_campo1 = i.inpa_Campo1
             and nvl(INAR_CAMPO2,'*-*') = nvl(i.inpa_Campo2,'*-*')
             and nvl(INAR_CAMPO3,'*-*') = nvl(i.inpa_Campo3,'*-*')
             and nvl(INAR_CAMPO4,'*-*') = nvl(i.inpa_Campo4,'*-*')
             and nvl(INAR_CAMPO5,'*-*') = nvl(i.inpa_Campo5,'*-*')
             and nvl(INAR_CAMPO6,'*-*') = nvl(i.inpa_Campo6,'*-*')
             and nvl(INAR_CAMPO7,'*-*') = nvl(i.inpa_Campo7,'*-*')
             and nvl(INAR_CAMPO8,'*-*') = nvl(i.inpa_Campo8,'*-*')
             and nvl(INAR_CAMPO9,'*-*') = nvl(i.inpa_Campo9,'*-*')
             and nvl(INAR_CAMPO10,'*-*') = nvl(i.inpa_Campo10,'*-*')
             and inar_nit_asociado = j.inar_nit_asociado
             and inar_ciud is null;                      -- 1012484.  ovcaceres.  28/03/2012.  Se tiene en cuenta condici�n de ciudad
             --
        end loop c_inar2;
        --
        For j in  c_inar3 ( i.inpa_Campo1, i.inpa_Campo2, i.inpa_Campo3, i.inpa_Campo4, i.inpa_Campo5,
                   i.inpa_Campo6, i.inpa_Campo7, i.inpa_Campo8, i.inpa_Campo9, i.inpa_Campo10, i.inpa_etct ) loop
            --
             update ge_tinarch
             set inar_estado = inar_estado||'(ICA_No_Existe)'
             where inar_infa   = p_Infa
             and inar_fecmov = p_Periodo
             and inar_numero = p_numero
             and inar_cias   = p_Cias
             and inar_campo1 = i.inpa_Campo1
             and nvl(INAR_CAMPO2,'*-*') = nvl(i.inpa_Campo2,'*-*')
             and nvl(INAR_CAMPO3,'*-*') = nvl(i.inpa_Campo3,'*-*')
             and nvl(INAR_CAMPO4,'*-*') = nvl(i.inpa_Campo4,'*-*')
             and nvl(INAR_CAMPO5,'*-*') = nvl(i.inpa_Campo5,'*-*')
             and nvl(INAR_CAMPO6,'*-*') = nvl(i.inpa_Campo6,'*-*')
             and nvl(INAR_CAMPO7,'*-*') = nvl(i.inpa_Campo7,'*-*')
             and nvl(INAR_CAMPO8,'*-*') = nvl(i.inpa_Campo8,'*-*')
             and nvl(INAR_CAMPO9,'*-*') = nvl(i.inpa_Campo9,'*-*')
             and nvl(INAR_CAMPO10,'*-*') = nvl(i.inpa_Campo10,'*-*')
             and inar_nit_asociado = j.inar_nit_asociado
             --  inicio 1012484.  ovcaceres.  28/03/2012.  Se tiene en cuenta condici�n 
             and inar_aica is not null
             and not exists ( select 'x'
                             from ge_taica
                             where inar_ciud = aica_ciud
                             and inar_aica = aica_aica
                             and i.inpa_etct = aica_etct
                           );
             --  fin 1012484.  ovcaceres.  28/03/2012.  Se tiene en cuenta condici�n 
             commit;
             --
        end loop c_inar3;
        --
    end loop c_inpa;
    --
  end Valida_Aica;
  --
  PROCEDURE Valida_Impuestos( p_Infa	   in varchar2,
                             p_inrq    in integer,
                             p_Cias	   in integer,
                             p_Periodo in integer,
                             p_Numero	 in varchar2 )is
    --
    cursor c_inpa is
    select distinct inpa_Campo1, inpa_Campo2, inpa_Campo3, inpa_Campo4, inpa_Campo5,
                    inpa_Campo6, inpa_Campo7, inpa_Campo8, inpa_Campo9, inpa_Campo10,
                    inpa_cont_mayo, Inpa_Etct
      from ge_tinpa, ge_tdere
     where inpa_infa       = p_Infa
       and inpa_inrq       = p_inrq
       and dere_clase      in ( 'IK', 'RF', 'RV', 'IT', 'IV' )
       and inpa_tpliq      = 'D'
       and dere_etct       = inpa_etct
       and dere_rete       = inpa_rete;
    --
    cursor c_inar1 ( pc_Ca1 varchar2, pc_Ca2 varchar2, pc_Ca3 varchar2, pc_Ca4 varchar2, pc_Ca5  varchar2,
                    pc_Ca6 varchar2, pc_Ca7 varchar2, pc_Ca8 varchar2, pc_Ca9 varchar2, pc_Ca10 varchar2 ) is
    select distinct inar_nit_asociado
      from ge_tinarch
     where inar_infa              = p_Infa
       and inar_fecmov            = p_Periodo
       and inar_numero            = p_Numero
       and inar_cias              = p_Cias
       and inar_campo1            = pc_Ca1
       and nvl(INAR_CAMPO2,'*-*') = nvl(pc_Ca2, '*-*')
       and nvl(INAR_CAMPO3,'*-*') = nvl(pc_Ca3, '*-*')
       and nvl(INAR_CAMPO4,'*-*') = nvl(pc_Ca4, '*-*')
       and nvl(INAR_CAMPO5,'*-*') = nvl(pc_Ca5, '*-*')
       and nvl(INAR_CAMPO6,'*-*') = nvl(pc_Ca6, '*-*')
       and nvl(INAR_CAMPO7,'*-*') = nvl(pc_Ca7, '*-*')
       and nvl(INAR_CAMPO8,'*-*') = nvl(pc_Ca8, '*-*')
       and nvl(INAR_CAMPO9,'*-*') = nvl(pc_Ca9, '*-*')
       and nvl(INAR_CAMPO10,'*-*') = nvl(pc_Ca10, '*-*')
       and inar_inco_base_valor is null;
      --
  Begin
    --
    for i in c_inpa loop
        --
        For j in  c_inar1 ( i.inpa_Campo1, i.inpa_Campo2, i.inpa_Campo3, i.inpa_Campo4, i.inpa_Campo5,
                   i.inpa_Campo6, i.inpa_Campo7, i.inpa_Campo8, i.inpa_Campo9, i.inpa_Campo10 ) loop
             --
             update ge_tinarch
             set inar_estado = inar_estado||'(Sin_Base)'
             where inar_infa   = p_Infa
             and inar_fecmov = p_Periodo
             and inar_numero = p_numero
             and inar_cias   = p_Cias
             and inar_campo1 = i.inpa_Campo1
             and nvl(INAR_CAMPO2,'*-*') = nvl(i.inpa_Campo2,'*-*')
             and nvl(INAR_CAMPO3,'*-*') = nvl(i.inpa_Campo3,'*-*')
             and nvl(INAR_CAMPO4,'*-*') = nvl(i.inpa_Campo4,'*-*')
             and nvl(INAR_CAMPO5,'*-*') = nvl(i.inpa_Campo5,'*-*')
             and nvl(INAR_CAMPO6,'*-*') = nvl(i.inpa_Campo6,'*-*')
             and nvl(INAR_CAMPO7,'*-*') = nvl(i.inpa_Campo7,'*-*')
             and nvl(INAR_CAMPO8,'*-*') = nvl(i.inpa_Campo8,'*-*')
             and nvl(INAR_CAMPO9,'*-*') = nvl(i.inpa_Campo9,'*-*')
             and nvl(INAR_CAMPO10,'*-*') = nvl(i.inpa_Campo10,'*-*')
             and inar_nit_asociado = j.inar_nit_asociado;
             --
        end loop c_inar1;
        --
    end loop c_inpa;
    --
  end Valida_Impuestos;
  --  fin 1012484.  ovcaceres.  01/03/2012
  --  fin 1012484.  ovcaceres.  01/03/2012
  ---------------------------------------------------------------------------------------------------------
  /* Termina COMO058 */
  Procedure Actualiza_Inad_inrq ( p_Numero varchar2, p_inrq number ) is
  begin
    --
    update ge_tinad
       set inad_inrq = p_inrq
     where inad_numero = p_Numero;
    --
    commit;
    --
  exception
    when others then
         raise_application_error( -20700, 'Error actualizando el requerimiento en GE_TINAD. '||sqlerrm );
  end Actualiza_Inad_inrq;
  ---------------------------------------------------------------------------------------------------------
  function trae_inad_inrq( p_infa      varchar2,
                           p_numero    varchar2) return number is
  --
  cursor c_inad is
	  select inad_inrq
	  from   ge_tinad
	  where  inad_infa   = p_infa
    and    inad_numero = p_numero;
  --
  v_inrq   ge_tinad.inad_inrq%type;
  -- 
  begin
    --
    open c_inad;
    fetch c_inad into v_inrq;
    close c_inad;
    --
    return v_inrq;
    --
  end trae_inad_inrq;                           
  ---------------------------------------------------------------------------------------------------------
  -- Ini COMO034 ymoreno
  PROCEDURE Crea_Reserva   (p_Cias       number, 
				  									p_VigOrPa    number,										
				  									p_OrPa       number,										
				  									p_VNeto    	number,
														P_fpag	      varchar2,              --  vers.1031.gap.-.18297 ovcaceres.07/11/2012
														p_auxi			  number,
														p_usuario    varchar2)
  IS
  	cursor c_orpv is
  	select nvl(sum(orpv_Valor), 0) VDsctos 
  	from  cp_torpv, ge_tdere 
  	where orpv_tpvl 	  = dere_rete (+)           --1013809 ymoreno
  	and   orpv_etct 	  = dere_etct (+)           --1013809 ymoreno
  	--and   nvl(dere_clase,'ZZ') <> 'OT' Antes de .Maaguilera(24018)vers_1035
    and   nvl(dere_clase,'ZZ') not in('OT','IT') --Maaguilera(24018)vers_1035
  	and   orpv_TpLiq in ( 'A', 'D')
  	and   orpv_cias 	 = p_Cias
  	and   orpv_vigorpa = p_VigOrPa
  	and   orpv_orpa 	 = p_OrPa;
  	--
  	cursor c_cuenta is
  	select enti_nrocta, enti_banc 
  	from  ge_tenti
  	where enti_auxi =  	(	SELECT  ctrl_enti_auxi
    											FROM cp_tctrl
    											WHERE ctrl_cias = p_Cias);
  	--
  	cursor cur_control is 
  	SELECT ctrl_tras_soc, ctrl_fte_instr, ctrl_fuente, ctrl_fond, ctrl_plan, ctrl_enti_auxi
    FROM  cp_tctrl
    WHERE ctrl_cias = p_Cias;
  --
  	r_ctrl				cur_control%rowtype;
  	v_fondo				number;
  	v_enti				number;
  	v_plan				number;
  	V_Dsctos			number;
  	v_cta					ge_tenti.enti_nrocta%type;
  	v_banc				ge_tenti.enti_banc%type;
  	v_saldo_disp  number := 0;
  	v_fuente			varchar2(1);
  	v_nro_oper		number;
  	v_inpg				number;
  	v_error       varchar2(500);  	
  	--
  BEGIN
  --
   	open cur_control;
    fetch cur_control into r_ctrl;
    close cur_control;
  --
    open c_orpv;
    fetch c_orpv into  V_Dsctos; 
    close c_orpv;
                                     
    if r_ctrl.ctrl_tras_soc = 'F' and r_ctrl.ctrl_fte_instr = 'N'  then
      --
      if r_ctrl.ctrl_fuente = 'C' then
    	  --
    	  v_fuente 			:= 'C';
  			v_enti				:= r_ctrl.ctrl_enti_auxi;
  			v_fondo				:= null;
  			v_plan				:= null;
  		
  			open c_cuenta;
  			fetch c_cuenta into v_cta, v_banc;
  			close c_cuenta;
    		--
  			v_saldo_disp := Bancos.Saldo_disponible(p_Cias, r_ctrl.ctrl_enti_auxi);
  			--
  			if V_Dsctos > v_saldo_disp then
  				--
  				raise_application_error( -20695, 'La cuenta '|| v_cta ||' del banco '||v_banc ||' parametrizada no tiene saldo' );
  				--
  			end if;
  			--  			
    	else
    		--
    		v_fuente 			:= 'P';	-- 1013896 dcgarces 27/04/2012
  			v_fondo				:= r_ctrl.ctrl_fond;
  			v_plan				:= r_ctrl.ctrl_plan;
  			v_enti				:= null; 		
  			-- 			
  			v_saldo_disp := sf_qplan.Saldo_disponible(r_ctrl.ctrl_fond, r_ctrl.ctrl_plan);
  			--
  			if V_Dsctos > v_saldo_disp  then
  				--
  				raise_application_error( -20696,'El encargo '|| r_ctrl.ctrl_plan||' del fondo '|| r_ctrl.ctrl_fond||' parametrizado no tiene saldo');
  				--
  			end if;
  			--
    end if;
    --
   
  begin
    --
    Fd_Qinstr_Pago.numera_instr_pago( p_cias, v_inpg );
    --
    exception
      when others then
        raise_application_error( -20697, 'Error generando n�mero para instrucciones de pago '|| sqlerrm);
    end;
    --
  	
    begin
      --						
      insert into cp_tinpg
  		( inpg_inpg,          inpg_Cias,          inpg_VigOrPa,      inpg_OrPa,             
  			inpg_FPag,          inpg_Fte_Rec,       inpg_VNeto,        inpg_sf_Fond,       
  			inpg_sf_Plan,       inpg_enti_Auxi,     inpg_enti_Auxi_Fn, inpg_Tipo_Pago,     
  			inpg_auxi_Benefi,   inpg_VDsctos,   		inpg_FecCre,		   inpg_Usua,					 
  			inpg_rec_reserv,    inpg_tras_soc,      inpg_stat)
  		values
  		  ( v_inpg,        	p_cias,         p_VigOrPa,        	 p_OrPa,   	
  		  	p_fpag,					v_fuente,     	p_VNeto,       			 v_Fondo,            
  		  	v_Plan,					v_enti,   			null,          			'I',
  		  	p_auxi, 				V_Dsctos,      	sysdate,		         p_usuario,			     
  		  	V_Dsctos,       r_ctrl.ctrl_tras_soc, 'AU');  
    	  --
      exception
      	when others then
      	  raise_application_error( -20698, 'Error creando Registro en CP_TINPG: ' || sqlerrm);
      end;
    --
    commit;
    --
  End if;
  --
  END Crea_Reserva;
  --
  --Fin COMO034 ymoreno
  ---------------------------------------------------------------------------------------------------------
  --
  --Ini soli_1044 pmp
  --
  PROCEDURE VALIDA_CUENTA_BANCO_DESTINO (p_Infa           varchar2,
                                         p_cias           integer,
                                         p_Periodo        integer,
                                         p_Numero         varchar2   ) is
    --
    --
	v_error               varchar2(100);
	v_estado              varchar2(100);
    v_QRegi               integer;
    --
    cursor ncuenta (pc_Infa varchar2, pc_cias integer, pc_periodo integer, pc_numero varchar2) is
    select distinct inar_campo1, inar_cuenta_destino, inar_banc_destino, inar_tercero
      from ge_tinarch
     where inar_infa   = pc_Infa
       and inar_cias   = pc_Cias
       and inar_fecmov = pc_Periodo
       and inar_numero = pc_numero
	   and exists (select 1 from ge_tinconceptos
				   where inco_inco    =    inar_Campo1
				   and   inco_descri  like '%EGRESO%'
	              )
	   ;
    --
	Cursor c_ctax (pc_nit number, pc_cta varchar2, pc_banc integer) is
	select ctax_stat
	  from ge_tctax
	 where ctax_auxi   = (select auxi_auxi from ge_tauxil where auxi_nit = pc_nit)
	   and ctax_cta    = pc_cta
	   and ctax_banc   = pc_banc
	   and ctax_stat   = 'A'
	   ;
    --
  BEGIN
    --
    for i in ncuenta(p_Infa, p_cias, p_periodo, p_numero) loop
		--
		v_QRegi := 0;
		v_error := null;
		if     i.inar_cuenta_destino is not null and i.inar_banc_destino is not null 
		   and i.inar_tercero is not null                                            then
			--
			open c_ctax(i.inar_tercero, i.inar_cuenta_destino, i.inar_banc_destino);
			fetch c_ctax into v_estado;
			if c_ctax%NotFound then
				--
				v_error := ' Cuenta No Asociada al Tercero o No Activa o Banco Diferente.';
				--
			else
				--
				v_QRegi := 1;
				--
			end if;
			--
			close c_ctax;
			--
		else
			--
			null;
			--
		end if;
		--
		if ( v_QRegi = 0 ) then
			--
			update ge_tinarch
			set    inar_estado  = inar_estado||v_error||' Cuenta_Destino('||nvl(i.inar_cuenta_destino,'nula')||') Banc_Destino('||nvl(to_char(i.inar_banc_destino),'nulo')||') NIT('||i.inar_tercero||')'
			where  inar_infa    = p_Infa
			and    inar_cias    = p_Cias
			and    inar_fecmov  = p_Periodo
			and    inar_numero  = p_Numero
			and    inar_campo1  = i.inar_campo1
			and    inar_tercero = i.inar_tercero
			;
			--
		end if;
		--
    end loop;
    --
    commit;
    --
  END VALIDA_CUENTA_BANCO_DESTINO;
  --
  --Fin soli_1044 pmp
  --
  --***********************************
  --* Ultimo Codigo de Error : -20701 *
  --***********************************
  --
  --
  -- Ini. versi�n 1045 lmesa@cidenet.com.co
  --
  PROCEDURE Valida_Archivo_Teso ( p_Numarch     NUMBER
                                 ,p_Numreq      INTEGER
                                 ,p_Fecmov      INTEGER
                                 ,p_Fecdoc      DATE
                                 ,p_Fond        VARCHAR2
                                 ,p_Fec_Carg    DATE
                                 ,p_Cias        VARCHAR2
                                 ,p_Usuario     VARCHAR2
                                 ,p_lgtr        NUMBER
                                 ,p_Opcion  OUT VARCHAR2
                                 ,p_Msg     OUT VARCHAR2
                                 ) IS
      --
      CURSOR c_Ult_Accion IS
          --
          SELECT inad_ult_accion
            FROM ge_tinad
           WHERE inad_infa   = 'TESO'
             AND inad_numero = p_Numarch;
          --
      --
      CURSOR c_Error_Tinarch IS
          --
          SELECT DISTINCT inar_estado
           FROM ge_tinarch
          WHERE inar_numero = p_Numarch
            AND inar_estado <> 'B';
          --
      --
      p_ty_hecg iw_qhecg.ty_hecg;
      v_Ult_Accion ge_tinad.inad_ult_accion%TYPE;
      v_Inhs ge_qinhs.ty_inhs;
      v_Error_Tinarch ge_tinarch.inar_estado%TYPE;
      --
      v_Accion  VARCHAR2(2) := 'VA';
      v_Sqlcode VARCHAR2(2000);
      v_Sqlerrm VARCHAR2(2000);
      --
  BEGIN
      --
      GE_QINFA.Actualiza_INAD_Ini(p_Numarch);
      --
      GE_QINFA.Validar( 'TESO', p_Numreq, p_Fecmov, p_Numarch, p_Opcion, p_Msg );
      --
      IF (p_Opcion <> 'OK') THEN
          --
          GE_QINFA.Actualiza_INAD_Fin( p_Fecmov, p_Numarch, 'VE', p_Fecdoc, p_Usuario);
          --
          FOR e IN c_Error_Tinarch LOOP
              --
              v_Error_Tinarch := v_Error_Tinarch || ' ' || e.inar_estado;
              --
          END LOOP;
          --
          raise_application_error(-20753, p_Msg || '('||v_Error_Tinarch||')');
          --
      ELSE
          --
          GE_QINFA.Actualiza_INAD_Fin( p_Fecmov, p_Numarch, v_Accion, p_Fecdoc, p_Usuario);
          --
      END IF;
      --
       OPEN c_Ult_Accion;
      FETCH c_Ult_Accion INTO v_Ult_Accion;
      CLOSE c_Ult_Accion;
      --
      v_Inhs.inhs_numero := p_Numarch;
      v_Inhs.inhs_accion := v_Ult_Accion;
      v_Inhs.inhs_usua   := p_Usuario;
      v_Inhs.inhs_infa   := 'TESO';
      --
      GE_QINHS.insertar_ge_tinhs( v_Inhs, p_Msg, p_Opcion);
      --
      IF (p_Opcion <> 'OK')  THEN
          --
          raise_application_error(-20753, p_Msg);
          --
      END IF;
      --
  EXCEPTION
      --
      WHEN OTHERS THEN
          --
          --
          GE_QINFA.Actualiza_INAD_Fin( p_Fecmov, p_Numarch, 'VE', p_Fecdoc, p_Usuario);
          --
          p_ty_hecg.fond := null;
          p_ty_hecg.cias := To_Number(p_Cias);
          p_ty_hecg.fech_carg := p_Fec_Carg;
          p_ty_hecg.mensaje := sqlerrm;
          --
          iw_qhecg.registrar_error(p_ty_hecg, p_lgtr, p_Numarch, v_Sqlcode, v_Sqlerrm, 'N');
          --
          p_Opcion := 'ERROR';
          p_Msg    := 'Validacion Errada';
          --
          Raise_application_error(sqlcode, sqlerrm);
          --
      --
  END Valida_Archivo_Teso;
  --
  PROCEDURE Procesa_Archivo_Teso ( p_Numarch    NUMBER
                                 ,p_Numreq      INTEGER
                                 ,p_Fecmov      INTEGER
                                 ,p_Fecdoc      DATE
                                 ,p_Fond        VARCHAR2
                                 ,p_Fec_Carg    DATE
                                 ,p_Cias        VARCHAR2
                                 ,p_Usuario     VARCHAR2
                                 ,p_lgtr        NUMBER
                                 ,p_Opcion  OUT VARCHAR2
                                 ,p_Msg     OUT VARCHAR2
                                 ) IS
      --
      CURSOR c_Ult_Accion IS
          --
          SELECT inad_ult_accion
            FROM ge_tinad
           WHERE inad_infa   = 'TESO'
             AND inad_numero = p_Numarch;
          --
      --
      CURSOR c_Infa_Agr_Cxp IS
          --
          SELECT DISTINCT  nvl(infa_agr_cxp,'S')
            FROM    ge_tinpa, ge_tinfases
           WHERE   infa_infa = inpa_infa
             AND     inpa_inrq = p_Numreq
             AND     inpa_infa = 'TESO';
          --
      --
      p_ty_hecg iw_qhecg.ty_hecg;
      v_Infa_Agr_Cxp ge_tinfases.infa_agr_cxp%TYPE;
      v_Ult_Accion ge_tinad.inad_ult_accion%TYPE;
      v_Inhs ge_qinhs.ty_inhs;
      --
      v_Accion varchar2(2) := 'TO';
      v_Sqlcode VARCHAR2(2000);
      v_Sqlerrm VARCHAR2(2000);
      --
  BEGIN
      --
      GE_QINFA.Verifica_Errados( 'TESO', p_Fecmov, p_Numarch, p_Opcion, p_Msg );
      --
      IF (p_Opcion <> 'OK')  THEN
          --
          raise_application_error(-20754, p_Msg);
          --
      END IF;
      --
      GE_QINFA.Actualiza_Inar( 'TESO', p_Numreq, p_Fecmov, p_Numarch );
      --
      GE_QINFA.Verifica_Cierres( 'TESO', p_Numreq, p_Fecmov, p_Numarch, p_Fecdoc, p_Opcion, p_Msg );
      --
      IF (p_Opcion <> 'OK')  THEN
          --
          GE_QINFA.Actualiza_INAD_Ini(p_Numarch);
          GE_QINFA.Actualiza_INAD_Fin( p_Fecmov, p_Numarch, 'PE', p_Fecdoc, p_Usuario);
          raise_application_error(-20754, p_Msg);
          --
      END IF;
      --
      GE_QINFA.Actualiza_INAD_Ini(p_Numarch);
      --
       OPEN c_Infa_Agr_Cxp;
      FETCH c_Infa_Agr_Cxp INTO v_Infa_Agr_Cxp;
      CLOSE c_Infa_Agr_Cxp;
      --
      GE_QINFA.Procesa_INFA( 'TESO', p_Numreq,p_Fecmov, p_Numarch, p_Fecdoc, p_Usuario, v_Infa_Agr_Cxp, v_Accion, NULL, NULL, NULL);
      --
      GE_QINFA.Actualiza_INAD_Fin( p_Fecmov, p_Numarch, v_Accion, p_Fecdoc, p_Usuario);
      --
       OPEN c_Ult_Accion;
      FETCH c_Ult_Accion INTO v_Ult_Accion;
      CLOSE c_Ult_Accion;
      --
      v_Inhs.inhs_numero := p_Numarch;
      v_Inhs.inhs_accion := v_Ult_Accion;
      v_Inhs.inhs_usua   := p_Usuario;
      v_Inhs.inhs_infa   := 'TESO';
      --
      GE_QINHS.insertar_ge_tinhs( v_Inhs, p_Msg, p_Opcion);
      --
      IF (p_Opcion <> 'OK')  THEN
          --
          raise_application_error(-20754, p_Msg);
          --
      END IF;
      --
  EXCEPTION
      --
      WHEN OTHERS THEN
          --
          GE_QINFA.Actualiza_INAD_Fin( p_Fecmov, p_Numarch, 'PE', p_Fecdoc, p_Usuario);
          --
          p_ty_hecg.fond := null;
          p_ty_hecg.cias := To_Number(p_Cias);
          p_ty_hecg.fech_carg := p_Fec_Carg;
          p_ty_hecg.mensaje := sqlerrm;
          --
          iw_qhecg.registrar_error(p_ty_hecg, p_lgtr, p_Numarch, v_Sqlcode, v_Sqlerrm, 'N');
          --
          p_Opcion := 'ERROR';
          p_Msg    := 'Procesamiento Errado';
          --
          Raise_application_error(sqlcode, sqlerrm);
          --
      --
  END Procesa_Archivo_Teso;
  --
  PROCEDURE Procesos_PosCargue_Teso( nro_Cargue       NUMBER
                                     ,p_lgtr          NUMBER
                                     ,p_Usuario       VARCHAR2
                                     ,p_Opcion    OUT VARCHAR2
                                     ,p_cod_rspta OUT VARCHAR2
                                     ,p_rspta     OUT VARCHAR2
                                    ) IS
      --
      CURSOR c_Res_Cargue IS
          --
          SELECT inar_campo1 inar_fond
                ,inar_cias
                ,inar_infa
                ,inar_fecmov
                ,inar_fecha
                ,sysdate fech_carg
                ,inrq_inrq
            FROM ge_tinarch, ge_vinrq
           WHERE to_number(LTRIM(RTRIM(inar_numero))) = nro_Cargue
             AND inar_cias = inrq_cias
           GROUP BY inar_campo1
                    ,inar_cias
                    ,inar_infa
                    ,inar_fecmov
                    ,inar_fecha
                    ,inrq_inrq
          ;
          --
      --
      v_Opcion VARCHAR2(30);
      v_Msg    VARCHAR2(500);
      v_rspta  VARCHAR2(2048);
      --
  BEGIN
      --
      p_cod_rspta := 'OK';
      p_rspta := 'Operaci�n Exitosa';
      --
      FOR i IN c_Res_Cargue LOOP
          --
          GE_QINFA.Valida_Archivo_Teso( nro_Cargue
                                       ,i.inrq_inrq
                                       ,i.inar_FecMov
                                       ,to_date(i.inar_Fecha,'dd/MM/yyyy')
                                       ,i.inar_cias
                                       ,i.fech_carg
                                       ,i.inar_cias
                                       ,p_Usuario
                                       ,p_lgtr
                                       ,v_Opcion
                                       ,v_Msg)
          ;
          --
      END LOOP;
      --
      FOR i IN c_Res_Cargue LOOP
          --
          GE_QINFA.Procesa_Archivo_Teso( nro_Cargue
                                        ,i.inrq_inrq
                                        ,i.inar_FecMov
                                        ,to_date(i.inar_Fecha,'dd/MM/yyyy')
                                        ,i.inar_cias
                                        ,i.fech_carg
                                        ,i.inar_cias
                                        ,p_Usuario
                                        ,p_lgtr
                                        ,v_Opcion
                                        ,v_Msg)
          ;
          --
      END LOOP;
      --
  EXCEPTION
      --
      WHEN OTHERS THEN
          --
          p_cod_rspta := sqlcode;
          p_rspta     := sqlerrm;
          --
      --
  END Procesos_PosCargue_Teso;
  --
  FUNCTION Cias_Mayor RETURN NUMBER IS
      --
      CURSOR c_Cias_mayor IS
          --
          SELECT max(hecg_cias)
            FROM iw_vhecg;
          --
      --
      v_cias_mayor iw_vhecg.hecg_cias%TYPE;
      --
  BEGIN
      --
      OPEN  c_Cias_mayor;
      FETCH c_Cias_mayor INTO v_cias_mayor;
      CLOSE c_Cias_mayor;
      --
      RETURN v_cias_mayor;
      --
  END Cias_Mayor;
  --
  FUNCTION Cias_Menor RETURN NUMBER IS
      --
      CURSOR c_Cias_Menor IS
          --
          SELECT min(hecg_cias)
            FROM iw_vhecg;
          --
      --
      v_cias_Menor iw_vhecg.hecg_cias%TYPE;
      --
  BEGIN
      --
      OPEN  c_Cias_Menor;
      FETCH c_Cias_Menor INTO v_cias_Menor;
      CLOSE c_Cias_Menor;
      --
      RETURN v_cias_Menor;
      --
  END Cias_Menor;
  --
  -- Fin. versi�n 1045 lmesa@cidenet.com.co
  --
  -- ini 1046 lvgomez
  PROCEDURE Car_Mvif (p_Periodo INTEGER, p_Numero VARCHAR2, p_Cias INTEGER, p_Fecha DATE, p_Usua_Gene VARCHAR2) IS 
      --
      CURSOR c_mvte IS 
          --SELECT DISTINCT mvte_cias, mvte_tpco, mvte_nrocom, mvte_fecmov, mvte_tpmv, mvte_inar_numero, mvte_etct, fond_fond, mvte_valor  --Vs. 1047 aateheran
          SELECT mvte_cias, mvte_tpco, mvte_nrocom, mvte_fecmov, mvte_tpmv, mvte_inar_numero, mvte_etct, fond_fond, mvte_valor             --Vs. 1047 aateheran
            FROM te_tmvte, sf_tfond 
           WHERE mvte_cias = fond_cias
             AND mvte_cias = p_Cias
             AND mvte_inar_numero = p_Numero
             AND mvte_fecmov = p_Periodo;
      --
      CURSOR c_comcia(p_etct NUMBER, p_tpmv NUMBER) IS 
          SELECT comc_tpmv_siaf,comc_io_gsiaf
            FROM te_tcomcia
           WHERE comc_etct = p_etct
             AND comc_tpmv = p_tpmv;
      --
      v_tpmv_siaf te_tcomcia.comc_tpmv_siaf%TYPE;
      v_io_gsiaf  te_tcomcia.comc_io_gsiaf%TYPE;
      e_error EXCEPTION;
      v_cod_rpta VARCHAR2(100);
      v_msg_rpta VARCHAR2(500);
      --
  BEGIN
      --
      Sf_Pins_Error('lvgomez Car_Mvif begin -> : p_Periodo: '||p_Periodo||' p_Numero:'||p_Numero||' p_Cias:'||p_Cias||' p_Fecha:'||p_Fecha||'p_Usua_Gene:'||p_Usua_Gene);
      FOR v_indice IN c_mvte LOOP
          --
          Sf_Pins_Error('lvgomez Car_Mvif c_mvte -> : v_indice.mvte_etct: '||v_indice.mvte_etct||' v_indice.mvte_tpco:'||v_indice.mvte_tpco||' v_indice.mvte_tpmv:'||v_indice.mvte_tpmv);
          OPEN c_comcia(v_indice.mvte_etct,v_indice.mvte_tpmv);
          FETCH c_comcia INTO v_tpmv_siaf,v_io_gsiaf;
          --
          IF c_comcia%NOTFOUND THEN
              --
              CLOSE c_comcia;
              v_msg_rpta := 'No existe tipo de movimiento de fondos';
              RAISE e_error;
              --
          END IF;
          --
          CLOSE c_comcia;
          --
           Sf_Pins_Error('lvgomez Car_Mvif if -> : v_io_gsiaf: '||v_io_gsiaf);
          IF v_io_gsiaf = 'O' AND (sf_qcmto.Maneja_Compartimento(v_indice.fond_fond) = 'S' OR sf_qtppt.Maneja_tppt(v_indice.fond_fond)= 'S') THEN
              --
              Sf_Pins_Error('lvgomez Car_Mvif if -> : v_io_gsiaf: '||v_io_gsiaf);
              Genera_Mvif( p_Cias
                          ,v_indice.mvte_tpco
                          ,p_Periodo
                          ,v_indice.mvte_nrocom
                          ,p_Fecha
                          ,v_indice.fond_fond
                          ,abs(v_indice.mvte_valor)
                          ,v_tpmv_siaf
                          ,p_Numero
                          ,p_Usua_Gene
                          ,v_cod_rpta
                          ,v_msg_rpta );
              --
              IF ( v_cod_rpta <> 'OK' ) THEN
                  --
                  Sf_Pins_Error('lvgomez Car_Mvif if -> : v_cod_rpta: '||v_cod_rpta);
                  RAISE e_error;
                  --
              END IF;
              --
          END IF;
          --
       END LOOP;
       --
  EXCEPTION
      --
      WHEN e_error THEN
          --
          Raise_application_error(-20001,v_msg_rpta);
          --
      WHEN OTHERS THEN
          --
          Raise_application_error(-20002,substr('GE_QINFA.Car_Mvif: '||SQLERRM,1,1000));
          --
      --
  END Car_Mvif;
  --
  PROCEDURE Genera_Mvif ( p_cias           INTEGER,
                          p_tpco           INTEGER,
                          p_periodo        INTEGER,
                          p_nrocom         NUMBER,
                          p_fecha          DATE,
                          p_fond           INTEGER,
                          p_valor          NUMBER,
                          p_sf_tpmv        INTEGER,
                          p_numero         INTEGER,
                          p_usuario        VARCHAR2,
                          p_cod_rpta  out  VARCHAR2,  
                          p_msg_rpta  out  VARCHAR2 
                        ) is 
   --
   CURSOR c_tinci ( pc_fond INTEGER ) IS
     SELECT NVL( SUM( inci_vlrcie ), 0 ), COUNT(*)
       FROM sf_tinci, sf_tfond
      WHERE inci_fond = fond_fond
        AND inci_fond = pc_fond
        AND inci_feccie = p_fecha-1
        AND inci_vlrcie <> 0
        AND inci_opin <> nvl(fond_opin_gen,-1);
   --
   CURSOR c_inci ( pc_fond INTEGER) IS
     SELECT inci_vlrcie, inci_opin
       FROM sf_tinci, sf_tfond
      WHERE inci_fond = fond_fond
        AND inci_fond = pc_fond
        AND inci_feccie = p_fecha-1
        AND inci_vlrcie <> 0
        AND inci_opin <> NVL(fond_opin_gen,-1);
   --
   v_TVrfondo  NUMBER;
   v_TNofondo  NUMBER;
   v_valor     NUMBER;
   v_nroInci   INTEGER;
   v_valorAcum NUMBER;
   v_totComp   INTEGER;
   v_sf_nromov INTEGER;
   v_fecha_ant DATE;   
   --
  BEGIN 
  	BEGIN
      v_fecha_ant := p_fecha-1; 
      --  Se ingresa y relaciona el comprobante con opciones espec�ficas proporcionalmente
      OPEN  c_tinci ( p_fond);
      FETCH c_tinci INTO v_TVrfondo, v_TNofondo;
      --
      IF (v_TNofondo <= 0 )THEN
          --
          p_Cod_Rpta := 'NO';
          p_Msg_Rpta := 'Error SC_QMVCO.Gen_Cier_Mvif No existe informaci�n del cierre del d�a ' ||v_fecha_ant||' del fondo '||p_fond||' para distribuir rendimientos. ';
          --
      END IF;
      --
      CLOSE c_tinci;
      --
      IF ( v_TNofondo > 0 ) THEN
          --
          v_valor := 0;
          v_nroInci  := 0;
          v_valorAcum := 0;
          --
          FOR j IN c_inci ( p_fond ) LOOP
              --
              v_nroInci := v_nroInci + 1;
              --
              IF ( v_nroInci = v_TNofondo ) THEN
                  --
                  v_valor := p_valor-v_valorAcum;
                  --
              ELSE
                  --
                  v_valor := ROUND( j.inci_vlrcie*p_valor / v_TVrfondo, 2 );
                  --
              END IF;
              --
              sf_pins_error('Gen_Cier_Mvif Seq: '||v_nroInci|| ' Opin: '||j.inci_opin||' Vlr Inci: '||j.inci_vlrcie||' Tot Fond: '||v_TVrfondo||' Valor Distrib: '||p_valor||' Total: '||v_valor||' NroTotREg: '||v_TVrfondo);
              --
              v_valorAcum := v_valorAcum + v_valor;
              --
              --  Distribuci�n por Opci�n
              --
              DECLARE
                  --
                  v_mvif_movefe VARCHAR2(1);
                  v_mvif_valefe NUMBER;
                  v_mvif_valcan NUMBER;
                  v_mvif_fecefe DATE;
                  v_Consec      INTEGER;
                  --
                  CURSOR c_mvif IS
                      --
                      SELECT sf_smvif.NEXTVAL
                        FROM dual;
                      --
              BEGIN
                  --
  	              v_mvif_movefe := 'S';
  	              v_mvif_valefe := v_valor;
  	              v_mvif_valcan := NULL;
  	              v_mvif_fecefe := NULL;
  	              --
  	              OPEN  c_mvif;
  	              FETCH c_mvif INTO v_Consec;
  	              CLOSE c_mvif;
  	              --
                  -- N�mero de Movimiento de Fondos
                  --
                  Sf_Qmovimiento.Numera_Mov ( p_fond, v_sf_nromov );
                  --
                   sf_pins_error('angtes de INSERT INTO sf_tmvif - p_fond: '||p_fond|| 'v_sf_nromov:'||v_sf_nromov||' v_consec:'||v_consec);
                  INSERT INTO sf_tmvif
                  ( mvif_Fond,     mvif_movefe,     mvif_valefe,
                    mvif_valor,    mvif_nromov,     mvif_tpmv,
                    mvif_fecmov,   mvif_usua,       mvif_valcan,
                    mvif_fecefe,   mvif_feccre,     mvif_consec,
                    mvif_OpIn )
                  VALUES
                  ( p_fond,        v_mvif_movefe, v_mvif_valefe,
                    v_valor,       v_sf_nromov,   p_sf_tpmv,
                    p_Fecha,       p_usuario,     v_mvif_valcan,
                    v_mvif_fecefe, SYSDATE,       v_consec,
                    j.inci_opin );
                  --
                  sf_pins_error('angtes de INSERT INTO ge_tmtif');
  	              INSERT INTO ge_tmtif
  	               ( mtif_infa
                    ,mtif_cias  
                    ,mtif_nrocom
                    ,mtif_fecmov
                    ,mtif_tpco  
                    ,mtif_mvif_nromov  
                    ,mtif_user  
                    ,mtif_feccre
                   )
  	              VALUES
  	               ( p_numero     
                    ,p_cias      
                    ,p_nrocom
  	                ,p_periodo     
                    ,p_tpco     
                    ,v_sf_nromov
                    ,p_usuario         
                    ,sysdate           
                   );
  	              --
                  sf_pins_error('despues de INSERT INTO ge_tmtif');
              EXCEPTION
                  --
                  WHEN OTHERS THEN
                      --
                      p_Cod_Rpta := 'NO';
                      p_Msg_Rpta := 'Error SC_QMVCO.Gen_Cier_Mvif : '||SQLERRM;
                      Sf_Pins_Error('lvgomez Car_Mvif if -> : SQLERRM: '||SQLERRM);
                      RETURN;
              END;
              --
          END LOOP c_inci;
          --
      END IF;
      --
    END;
  --
  EXCEPTION
      --
      WHEN sf_qerror.ex_sifi_general THEN
          --
          RAISE;
          --
      WHEN sf_qerror.ex_procedimiento THEN
          --
          raise_application_error(sf_qerror.CODIGO_EX_SIFI, sf_qerror.Print_Error);
          --
      WHEN OTHERS THEN
          --
          IF (sf_qerror.hace_raise(SQLCODE)) THEN
              --
              RAISE;
              --
          ELSE
              --
              raise_application_error(sf_qerror.CODIGO_EX_SIFI, sf_qerror.Print_Error);
              --
          END IF;
      --
  END  Genera_Mvif;
  --
    PROCEDURE Valida_tpmv ( p_Infa    VARCHAR2
                         ,p_Cias    INTEGER
                         ,p_Periodo INTEGER
                         ,p_Numero  VARCHAR2
                         ,p_EtCt    INTEGER ) IS
    --
    CURSOR c_tinarch IS
      SELECT inar_campo1, cias_etct
        FROM ge_tinarch, ge_tcias
       WHERE inar_cias   = cias_cias
         AND inar_infa   = p_Infa
         AND inar_fecmov = p_Periodo
         AND inar_numero = p_Numero
         AND inar_cias   = p_Cias;
    --
    CURSOR c_tcomcia (p_tpmv ge_tinarch.inar_campo1%TYPE, p_etct ge_tcias.cias_etct%TYPE) IS
        SELECT comc_tpmv_siaf,comc_io_gsiaf
          FROM te_tcomcia
         WHERE comc_tpmv = p_tpmv
           AND comc_etct = p_etct;
    --
     CURSOR c_tpmv_sf (p_tpmv_sf te_tcomcia.comc_tpmv_siaf%TYPE) IS
        SELECT tpmv_natu 
          FROM sf_ttpmv
         WHERE tpmv_tpmv = p_tpmv_sf;
    --
    CURSOR c_tpmv_te (p_tpmv_te ge_tinarch.inar_campo1%TYPE) IS 
        SELECT tpmv_tporan,tpmv_tpco_siaf,tpco_clase
          FROM te_ttpmv ,ge_ttpco
         WHERE tpmv_tpmv = p_tpmv_te
           AND tpco_tpco= tpmv_tpco_siaf;
    --
    v_tpmv          ge_tinarch.inar_campo1%TYPE;
    v_etct          ge_tcias.cias_etct%TYPE;
    v_tpmv_siaf     te_tcomcia.comc_tpmv_siaf%TYPE;
    v_gsiaf         te_tcomcia.comc_io_gsiaf%TYPE;
    v_natu_sf       sf_ttpmv.tpmv_natu%TYPE;
    v_tporan        te_ttpmv.tpmv_tporan%TYPE;
    v_tpco_siaf     te_ttpmv.tpmv_tpco_siaf%TYPE;
    v_tpco_clase    ge_ttpco.tpco_clase%TYPE;
    v_mensaje_error VARCHAR2(50);
    v_estado        VARCHAR2(1);
    --
  BEGIN
    --
    FOR v_indice IN c_tinarch LOOP
        --
        sf_pins_error('lvgomez Valida_tpmv -> v_indice.inar_campo1:'||v_indice.inar_campo1||' v_indice.cias_etct:'||v_indice.cias_etct);
        OPEN  c_tcomcia (v_indice.inar_campo1, v_indice.cias_etct);
        FETCH c_tcomcia INTO v_tpmv_siaf, v_gsiaf;
        CLOSE c_tcomcia;
        --
        IF v_gsiaf = 'O' THEN
            --
            IF v_tpmv_siaf IS NOT NULL THEN
                --
                OPEN  c_tpmv_sf(v_tpmv_siaf);
                FETCH c_tpmv_sf INTO v_natu_sf;
                CLOSE c_tpmv_sf;
                --
                OPEN  c_tpmv_te(v_indice.inar_campo1);
                FETCH c_tpmv_te INTO v_tporan,v_tpco_siaf,v_tpco_clase;
                CLOSE c_tpmv_te;
                --
                IF v_natu_sf != v_tporan THEN
                    --
                    v_estado := 'E';
                    v_mensaje_error := 'La naturaleza no son iguales';
                    --
                END IF;
                --
            END IF;
            --
        END IF;
        --
        IF  v_estado = 'E' THEN
            --
            UPDATE ge_tinarch
               SET inar_estado = v_estado||'(TPMV)= ' || inar_campo1 ||v_mensaje_error
             WHERE inar_infa   = p_Infa
               AND inar_fecmov = p_Periodo
               AND inar_numero = p_Numero
               AND inar_cias   = p_Cias
               AND inar_campo1 = v_indice.inar_campo1;
            --
            COMMIT;
            --
        END IF;
        --
        v_estado := NULL;
        v_mensaje_error := NULL;
        --
    END LOOP;
    --
  END Valida_tpmv;
  -- fin 1046 lvgomez
end GE_QINFA;
/
